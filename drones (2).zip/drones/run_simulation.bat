@echo off
setlocal enabledelayedexpansion
title Tarot 650 UAV Fault-Tolerant 3D Simulator (MuJoCo)

cd /d "%~dp0"

:: ----------------------------------------------------------------------
:: DETECT PYTHON ENVIRONMENT
:: ----------------------------------------------------------------------
set "PYTHON_EXE="

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    goto :PYTHON_FOUND
)

for /f "delims=" %%I in ('where python 2^>nul') do (
    "%%~fI" --version >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_EXE=%%~fI"
        goto :PYTHON_FOUND
    )
)

if exist "%~dp0.venv\Scripts\python.exe" (
    set "PYTHON_EXE=%~dp0.venv\Scripts\python.exe"
    goto :PYTHON_FOUND
)

if exist "%ProgramFiles%\Python311\python.exe" (
    set "PYTHON_EXE=%ProgramFiles%\Python311\python.exe"
    goto :PYTHON_FOUND
)

:PYTHON_FOUND
if "%PYTHON_EXE%"=="" (
    echo [ERROR] Python 3.11 executable not found on system.
    echo Please ensure Python 3.11 is installed.
    pause
    exit /b 1
)

:MENU
cls
echo ========================================================================
echo   TAROT 650 FAULT-TOLERANT QUADROTOR UAV 3D SIMULATOR (MuJoCo)
echo   Based on: Hamadi et al., ISA Transactions 129 (2022)
echo ========================================================================
echo.
echo   Using Python: %PYTHON_EXE%
echo.
echo   [1] Situation 1: GPS Hardware Sensor Fault (+5m at t=7.0s) ^& Recovery
echo   [2] Situation 2: Lidar Hardware Sensor Fault (-1m at t=17.8s) ^& Recovery
echo   [3] Situation 3: Software Altitude Covariance Fault (P_z = -0.1) ^& Recovery
echo   [4] Situation 4: Software Position Covariance Fault (P_xy = -0.01) ^& Recovery
echo.
echo   [5] Generate All 12 Research Paper Figures ^& Analysis Plots (plots/)
echo   [6] Generate PowerPoint Presentation (.pptx)
echo.
echo   [0] Exit
echo ========================================================================
echo.
set /p CHOICE="Select an option [1-6, or 0 to Exit]: "

if "%CHOICE%"=="1" goto :SIT1
if "%CHOICE%"=="2" goto :SIT2
if "%CHOICE%"=="3" goto :SIT3
if "%CHOICE%"=="4" goto :SIT4
if "%CHOICE%"=="5" goto :PLOTS
if "%CHOICE%"=="6" goto :PPTX
if "%CHOICE%"=="0" exit /b 0

echo Invalid choice. Please try again.
timeout /t 2 >nul
goto :MENU

:SIT1
echo.
echo [START] Launching 3D Simulation for Situation 1...
"%PYTHON_EXE%" simulation_3d.py --situation 1
echo.
pause
goto :MENU

:SIT2
echo.
echo [START] Launching 3D Simulation for Situation 2...
"%PYTHON_EXE%" simulation_3d.py --situation 2
echo.
pause
goto :MENU

:SIT3
echo.
echo [START] Launching 3D Simulation for Situation 3...
"%PYTHON_EXE%" simulation_3d.py --situation 3
echo.
pause
goto :MENU

:SIT4
echo.
echo [START] Launching 3D Simulation for Situation 4...
"%PYTHON_EXE%" simulation_3d.py --situation 4
echo.
pause
goto :MENU

:PLOTS
echo.
echo [START] Generating paper replication plots in plots/...
"%PYTHON_EXE%" drone_core.py --plots
echo.
pause
goto :MENU

:PPTX
echo.
echo [START] Generating PowerPoint presentation...
"%PYTHON_EXE%" generate_presentation.py
echo.
pause
goto :MENU
