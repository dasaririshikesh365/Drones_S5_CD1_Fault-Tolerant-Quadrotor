"""
generate_presentation.py
========================
Generates a structured, professional 16:9 widescreen PowerPoint presentation (.pptx)
featuring dedicated, visual architectural diagrams for BOTH the Full Pipeline and Full Methodology.

Slide Structure:
  1. Title
  2. Introduction
  3. Problem Statement
  4. Objective
  5. Full Pipeline (Complete End-to-End Multi-Layer System Architecture)
  6. Full Methodology (Mathematical, Estimator & FDI Algorithmic Architecture)
  7. Simulation Part (Part 1: Real-World 3D MuJoCo Airfield, Wind & Rain)
  8. Simulation Part (Part 2: 4 Experimental Scenarios & Paper Figures)
  9. Future Work
  10. Conclusion
"""

import os
import pptx
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

# ── Colors ──────────────────────────────────────────────────────────────────
BG_DARK      = RGBColor(15, 23, 42)      # Slate 900
CARD_BG      = RGBColor(30, 41, 59)      # Slate 800
CARD_BORDER  = RGBColor(51, 65, 85)      # Slate 700
LAYER_BG1    = RGBColor(23, 37, 84)      # Dark Blue Layer
LAYER_BG2    = RGBColor(19, 78, 74)      # Dark Teal Layer
LAYER_BG3    = RGBColor(67, 20, 7)      # Dark Amber Layer
LAYER_BG4    = RGBColor(49, 46, 129)     # Dark Indigo Layer

CYAN_ACCENT  = RGBColor(6, 182, 212)     # Cyan 500
BLUE_ACCENT  = RGBColor(59, 130, 246)    # Blue 500
EMERALD_ACC  = RGBColor(16, 185, 129)    # Emerald 500
AMBER_ACC    = RGBColor(245, 158, 11)    # Amber 500
ROSE_ACC     = RGBColor(244, 63, 94)     # Rose 500
TEXT_WHITE   = RGBColor(248, 250, 252)   # White
TEXT_MUTED   = RGBColor(148, 163, 184)   # Slate 400

PLOTS_DIR = os.path.join(os.path.dirname(__file__), 'plots')


def create_base_slide(prs, title_text: str, category_text: str):
    """Create a standard dark-themed slide with header."""
    blank_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank_layout)

    # Background
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
    bg.fill.solid(); bg.fill.fore_color.rgb = BG_DARK; bg.line.fill.background()

    # Category Tag
    cat_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.35), Inches(11.7), Inches(0.3))
    tf_cat = cat_box.text_frame; tf_cat.word_wrap = True
    p_cat = tf_cat.paragraphs[0]
    p_cat.text = category_text.upper()
    p_cat.font.size = Pt(10); p_cat.font.bold = True; p_cat.font.color.rgb = CYAN_ACCENT

    # Title
    title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.65), Inches(11.7), Inches(0.55))
    tf_title = title_box.text_frame; tf_title.word_wrap = True
    p_title = tf_title.paragraphs[0]
    p_title.text = title_text
    p_title.font.size = Pt(21); p_title.font.bold = True; p_title.font.color.rgb = TEXT_WHITE

    # Divider
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.25), Inches(11.733), Inches(0.02))
    line.fill.solid(); line.fill.fore_color.rgb = CARD_BORDER; line.line.fill.background()

    return slide


def add_arch_box(slide, left, top, width, height, title, subtitle="", bg_color=CARD_BG, border_color=CARD_BORDER, title_color=TEXT_WHITE):
    """Add an architectural block with title and subtitle description."""
    box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    box.fill.solid(); box.fill.fore_color.rgb = bg_color
    box.line.color.rgb = border_color; box.line.width = Pt(1.2)

    tb = slide.shapes.add_textbox(left + Inches(0.08), top + Inches(0.05), width - Inches(0.16), height - Inches(0.1))
    tf = tb.text_frame; tf.word_wrap = True
    p0 = tf.paragraphs[0]
    p0.text = title
    p0.font.size = Pt(10.5); p0.font.bold = True; p0.font.color.rgb = title_color
    p0.alignment = PP_ALIGN.CENTER

    if subtitle:
        p1 = tf.add_paragraph()
        p1.text = subtitle
        p1.font.size = Pt(8.5); p1.font.color.rgb = TEXT_MUTED
        p1.alignment = PP_ALIGN.CENTER
        p1.space_before = Pt(2)

    return box


def add_flow_arrow(slide, left, top, width, height, color=CYAN_ACCENT):
    """Add a flow connector arrow."""
    arrow = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, left, top, width, height)
    arrow.fill.solid(); arrow.fill.fore_color.rgb = color
    arrow.line.fill.background()
    return arrow


def add_card(slide, left, top, width, height, title="", border_color=CARD_BORDER):
    """Add standard card container."""
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    card.fill.solid(); card.fill.fore_color.rgb = CARD_BG
    card.line.color.rgb = border_color; card.line.width = Pt(1.2)

    if title:
        tb = slide.shapes.add_textbox(left + Inches(0.2), top + Inches(0.15), width - Inches(0.4), Inches(0.4))
        p = tb.text_frame.paragraphs[0]
        p.text = title
        p.font.size = Pt(12.5); p.font.bold = True; p.font.color.rgb = CYAN_ACCENT

    return card


def build_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    img_render = os.path.join(PLOTS_DIR, 'real_world_rain_render.png')

    # ═════════════════════════════════════════════════════════════════════════
    # 1. TITLE SLIDE
    # ═════════════════════════════════════════════════════════════════════════
    s1 = prs.slides.add_slide(prs.slide_layouts[6])
    bg1 = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
    bg1.fill.solid(); bg1.fill.fore_color.rgb = BG_DARK; bg1.line.fill.background()

    if os.path.exists(img_render):
        s1.shapes.add_picture(img_render, Inches(6.8), Inches(1.2), Inches(5.8), Inches(5.1))

    t_box = s1.shapes.add_textbox(Inches(0.8), Inches(1.4), Inches(5.7), Inches(5.0))
    tf1 = t_box.text_frame; tf1.word_wrap = True

    p = tf1.paragraphs[0]
    p.text = "AUTONOMOUS AERIAL ROBOTICS PROJECT"
    p.font.size = Pt(11); p.font.bold = True; p.font.color.rgb = CYAN_ACCENT

    p = tf1.add_paragraph()
    p.text = "Data Fusion Fault Tolerant Strategy for a Quadrotor UAV"
    p.font.size = Pt(26); p.font.bold = True; p.font.color.rgb = TEXT_WHITE
    p.space_before = Pt(8)

    p = tf1.add_paragraph()
    p.text = "Robust Navigation under Sensors & Internal Software Faults in 3D MuJoCo Simulation"
    p.font.size = Pt(13); p.font.color.rgb = BLUE_ACCENT
    p.space_before = Pt(6)

    p = tf1.add_paragraph()
    p.text = (
        "• Base Paper: Hamadi et al., ISA Transactions 129 (2022), pp. 520–539\n"
        "• Platform: Tarot 650 Quadrotor UAV (1.70 kg Carbon Frame)\n"
        "• Key Innovation: Dual EKF + Analytical Dynamic Model + Software Covariance FDI\n"
        "• Environment: Real-World Airfield with Dynamic Wind & Rain in MuJoCo 3D"
    )
    p.font.size = Pt(11); p.font.color.rgb = TEXT_MUTED
    p.space_before = Pt(16)

    # ═════════════════════════════════════════════════════════════════════════
    # 2. INTRODUCTION
    # ═════════════════════════════════════════════════════════════════════════
    s2 = create_base_slide(prs, "Introduction: UAV Autonomy & Critical Failure Modes", "01 / INTRODUCTION")

    add_card(s2, Inches(0.8), Inches(1.5), Inches(3.6), Inches(5.3), "UAV AUTONOMY & APPLICATION")
    tb = s2.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(3.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• High Criticality:\n"
        "  UAVs perform safety-critical missions in urban delivery, surveillance, search & rescue, and industrial inspection.\n\n"
        "• Underactuated Dynamics:\n"
        "  Quadrotors control 6 degrees of freedom (DOF) using only 4 motor thrusts. Loss of reliable state estimation leads to immediate uncontrolled crashes.\n\n"
        "• Operating Environment:\n"
        "  Drones operate under severe atmospheric turbulence, wind gusts, and precipitation."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s2, Inches(4.7), Inches(1.5), Inches(3.6), Inches(5.3), "STANDARD AVIONICS SUITE")
    tb = s2.shapes.add_textbox(Inches(4.9), Inches(2.1), Inches(3.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Primary Sensors:\n"
        "  - GPS: Horizontal global positioning (X, Y)\n"
        "  - Lidar / Barometer: Vertical altitude (Z)\n"
        "  - IMU (Acc + Gyro): Acceleration & rates\n"
        "  - Magnetometer: Yaw heading orientation\n\n"
        "• Vulnerabilities:\n"
        "  Hardware suffers from GPS satellite multi-path shifts (+5m), laser reflectivity loss, and IMU temperature drift."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s2, Inches(8.6), Inches(1.5), Inches(3.9), Inches(5.3), "THE DUAL-FAULT CHALLENGE")
    tb = s2.shapes.add_textbox(Inches(8.8), Inches(2.1), Inches(3.5), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Beyond Hardware Redundancy:\n"
        "  Traditional systems duplicate sensors but rely on a single central filter.\n\n"
        "• Software Estimator Corruption:\n"
        "  Internal numerical errors, overflow, or covariance collapse (P_ii < 0) cause the filter to diverge even when physical sensors are 100% healthy!\n\n"
        "• Objective:\n"
        "  A dual-fault tolerant architecture surviving physical outages AND software bugs."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    # ═════════════════════════════════════════════════════════════════════════
    # 3. PROBLEM STATEMENT
    # ═════════════════════════════════════════════════════════════════════════
    s3 = create_base_slide(prs, "Problem Statement: Sensor Hardware Outages vs Software Bugs", "02 / PROBLEM STATEMENT")

    add_card(s3, Inches(0.8), Inches(1.5), Inches(5.6), Inches(5.3), "PHYSICAL SENSOR HARDWARE FAILURES")
    tb = s3.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(5.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• GPS Additive Jumps (+5.0m Offset):\n"
        "  Instantaneous position shift causes the controller to command excessive tilt, leading to high-speed drift and collisions.\n\n"
        "• Lidar Ground Reflection Dropout (-1.0m Bias):\n"
        "  Laser sensor bias induces altitude underestimation, forcing the drone to drop altitude and crash into the ground.\n\n"
        "• Accelerometer / Gyro Noise:\n"
        "  Motor vibrations inject severe noise, corrupting state propagation."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s3, Inches(6.8), Inches(1.5), Inches(5.7), Inches(5.3), "THE HIDDEN THREAT: SOFTWARE ESTIMATOR COLLAPSE")
    tb = s3.shapes.add_textbox(Inches(7.0), Inches(2.1), Inches(5.3), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Covariance Matrix Non-Positive Definiteness:\n"
        "  In embedded code, numerical truncation can cause diagonal covariance elements to become negative (e.g. P_z = -0.1 or P_xy = -0.01).\n\n"
        "• Blindness of Standard Hardware Voters:\n"
        "  Because physical sensors (GPS1 & GPS2) agree, hardware-only voting concludes 'Everything is Nominal' while the software estimator diverges to infinity!\n\n"
        "• Environmental Disturbance Overlap:\n"
        "  Dynamic wind turbulence (4.0–6.5 m/s) and rain drag mask fault signatures."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    # ═════════════════════════════════════════════════════════════════════════
    # 4. OBJECTIVES
    # ═════════════════════════════════════════════════════════════════════════
    s4 = create_base_slide(prs, "Project Objectives & Key Technical Requirements", "03 / OBJECTIVES")

    add_card(s4, Inches(0.8), Inches(1.5), Inches(5.6), Inches(5.3), "RESEARCH & ALGORITHMIC GOALS")
    tb = s4.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(5.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "1. Complete Paper Replication (Hamadi et al., 2022):\n"
        "   Recreate all 12 experimental validation figures (Figs. 4, 6, 10, 16–24) with mathematical exactness.\n\n"
        "2. Multi-Branch Parallel Estimation Architecture:\n"
        "   Design 4 Sensor Blocks, Dual EKF estimators (KF1 & KF2), and an Analytical Dynamic Model (DM).\n\n"
        "3. Weighted Average Voting Consensus:\n"
        "   Formulate dynamic agreement-weighted fusion (Eqs. 22–24) to eliminate single-estimator failure.\n\n"
        "4. Software vs Hardware FDI Engine:\n"
        "   Develop discrimination logic to detect negative covariance (min(diag(P)) < 0) and physical sensor biases."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s4, Inches(6.8), Inches(1.5), Inches(5.7), Inches(5.3), "SIMULATION & ENGINEERING GOALS")
    tb = s4.shapes.add_textbox(Inches(7.0), Inches(2.1), Inches(5.3), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "5. High-Fidelity 3D Physics Simulation (MuJoCo):\n"
        "   Build a real-world airfield (60m runway, helipad, hangars, control tower, wind gusts, and 3D animated rain).\n\n"
        "6. Active Autonomous Flight Control:\n"
        "   Cascaded PD position-attitude controller with the Tarot 650 X-Mixer matrix to fly rightwards down the runway and complete airfield circuits.\n\n"
        "7. Real-Time HUD Telemetry & Diagnostics:\n"
        "   Corner diagnostic cards displaying live sensor residuals and software health without obscuring the drone.\n\n"
        "8. Clean 2-File Modular Architecture:\n"
        "   Consolidate codebase into simulation_3d.py and drone_core.py."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    # ═════════════════════════════════════════════════════════════════════════
    # 5. FULL PIPELINE (MULTI-LAYER ARCHITECTURE DIAGRAM)
    # ═════════════════════════════════════════════════════════════════════════
    s5 = create_base_slide(prs, "Full Pipeline: End-to-End Multi-Layer System Architecture", "04 / FULL PIPELINE")

    # Layer 1: Sensors & Feedback
    add_arch_box(s5, Inches(0.8), Inches(1.5), Inches(2.1), Inches(1.15), "SENSOR BLOCKS 1 & 2", "IMU1, GPS1, Lidar1, Mag1\n[Physical Branch 1]", LAYER_BG1, BLUE_ACCENT, TEXT_WHITE)
    add_arch_box(s5, Inches(0.8), Inches(2.8), Inches(2.1), Inches(1.15), "SENSOR BLOCKS 3 & 4", "IMU2, GPS2, Lidar2, Mag2\n[Physical Branch 2]", LAYER_BG1, BLUE_ACCENT, TEXT_WHITE)
    add_arch_box(s5, Inches(0.8), Inches(4.1), Inches(2.1), Inches(1.15), "ESC MOTOR FEEDBACK", "PWM Commands & Voltages\n[Analytical Input]", LAYER_BG1, BLUE_ACCENT, TEXT_WHITE)

    add_flow_arrow(s5, Inches(2.98), Inches(1.95), Inches(0.28), Inches(0.2), CYAN_ACCENT)
    add_flow_arrow(s5, Inches(2.98), Inches(3.25), Inches(0.28), Inches(0.2), CYAN_ACCENT)
    add_flow_arrow(s5, Inches(2.98), Inches(4.55), Inches(0.28), Inches(0.2), CYAN_ACCENT)

    # Layer 2: Multi-Branch Estimators
    add_arch_box(s5, Inches(3.3), Inches(1.5), Inches(2.3), Inches(1.15), "BRANCH B1 (PRIMARY EKF)", "9-State Extended Kalman Filter\n[Joseph-Form Updates]", LAYER_BG4, CYAN_ACCENT, TEXT_WHITE)
    add_arch_box(s5, Inches(3.3), Inches(2.8), Inches(2.3), Inches(1.15), "BRANCH B2 (REDUNDANT EKF)", "9-State Extended Kalman Filter\n[Independent Process/Meas]", LAYER_BG4, CYAN_ACCENT, TEXT_WHITE)
    add_arch_box(s5, Inches(3.3), Inches(4.1), Inches(2.3), Inches(1.15), "BRANCH B3 (DYNAMIC MODEL)", "RK4 Quadrotor Newton-Euler\n[0% Sensor Dependence]", LAYER_BG4, CYAN_ACCENT, TEXT_WHITE)

    add_flow_arrow(s5, Inches(5.68), Inches(1.95), Inches(0.28), Inches(0.2), CYAN_ACCENT)
    add_flow_arrow(s5, Inches(5.68), Inches(3.25), Inches(0.28), Inches(0.2), CYAN_ACCENT)
    add_flow_arrow(s5, Inches(5.68), Inches(4.55), Inches(0.28), Inches(0.2), CYAN_ACCENT)

    # Layer 3: Weighted Average Voter
    add_arch_box(s5, Inches(6.0), Inches(1.5), Inches(2.3), Inches(3.75), "WEIGHTED AVERAGE VOTER", "Pairwise Distance d_ij\nAgreement s_ij = 1/(1+(d/a)^n)\nDynamic Weights w_i\nConsensus y_voted = ∑ w_i y_i", LAYER_BG2, EMERALD_ACC, TEXT_WHITE)

    add_flow_arrow(s5, Inches(8.38), Inches(3.25), Inches(0.28), Inches(0.2), EMERALD_ACC)

    # Layer 4: FDI & Recovery
    add_arch_box(s5, Inches(8.7), Inches(1.5), Inches(2.1), Inches(3.75), "FDI & FAULT RECOVERY", "Physical Residuals:\nΔGPS, ΔLidar, ΔIMU\nSoftware Covariance Monitor:\nmin(diag(P)) < 0\nRecovery Solution 3:\nKF3 = avg(KF2, DM)", LAYER_BG3, AMBER_ACC, TEXT_WHITE)

    add_flow_arrow(s5, Inches(10.88), Inches(3.25), Inches(0.28), Inches(0.2), AMBER_ACC)

    # Layer 5: Flight Control & Plant
    add_arch_box(s5, Inches(11.2), Inches(1.5), Inches(1.8), Inches(3.75), "CONTROL & PLANT", "Cascaded PD Controller\nTarot 650 X-Mixer Matrix\n4 BLDC Motor Forces\nMuJoCo 3D Airfield\nDynamic Wind & Rain", LAYER_BG1, ROSE_ACC, TEXT_WHITE)

    # Bottom Pipeline Summary Banner
    add_card(s5, Inches(0.8), Inches(5.45), Inches(12.2), Inches(1.35), "PIPELINE HIGHLIGHTS")
    tb = s5.shapes.add_textbox(Inches(1.0), Inches(5.85), Inches(11.8), Inches(0.85))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Full Closed-Loop Resilience: State estimation dynamically switches between healthy physical EKF and analytical model branches.\n"
        "• Dual-Fault Protection: Detects physical sensor hardware biases AND internal estimation software bugs with 0.02s response latency.\n"
        "• Autonomous Runway Flight: Autopilot maintains stable trajectory down the 60m runway under turbulent aerodynamic drag forces."
    )
    tf.paragraphs[0].font.size = Pt(9.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    # ═════════════════════════════════════════════════════════════════════════
    # 6. FULL METHODOLOGY (MATHEMATICAL & ALGORITHMIC ARCHITECTURE)
    # ═════════════════════════════════════════════════════════════════════════
    s6 = create_base_slide(prs, "Full Methodology: Mathematical Models, EKF & FDI Architecture", "05 / METHODOLOGY ARCHITECTURE")

    # Block A: Motor Characterisation
    add_arch_box(s6, Inches(0.8), Inches(1.5), Inches(3.7), Inches(2.6), "1. MOTOR POLYNOMIALS (Eqs. 9 & 10)", "f_i = -1.4736 u³ + 11.0691 u² - 16.7074 u + 7.3007 [N]\nτ_i = -0.0905 u³ + 0.4771 u² - 0.6790 u + 0.3045 [N·m]\nNormalised Input: u = PWM / 1000 ∈ [1.0, 2.0]\nHover: PWM 1500–1600 (4.25 N/motor, 17 N total)", LAYER_BG1, BLUE_ACCENT, TEXT_WHITE)

    # Block B: Dynamic Model RK4
    add_arch_box(s6, Inches(0.8), Inches(4.25), Inches(3.7), Inches(2.6), "2. ANALYTICAL DYNAMIC MODEL (RK4)", "m ẍ = R [0, 0, ∑ f_i]^T - [0, 0, mg]^T + F_drag(v_rel)\nI ω̇ = τ_moments - ω × (I ω)\nDrag: F_drag = 0.5 ρ C_d A ||v_rel|| v_rel\nIntegrated via 4th-Order Runge-Kutta at 200 Hz", LAYER_BG1, BLUE_ACCENT, TEXT_WHITE)

    # Block C: EKF State & Joseph Updates
    add_arch_box(s6, Inches(4.7), Inches(1.5), Inches(4.0), Inches(2.6), "3. EKF ESTIMATION WITH JOSEPH UPDATES", "9-State Vector: x = [x, y, z, v_x, v_y, v_z, ϕ, θ, ψ]^T\nPrediction: x_{k|k-1} = f(x_{k-1}, a_IMU),  P_{k|k-1} = F P F^T + Q\nJoseph Update: P_k = (I - KH) P_{k|k-1} (I - KH)^T + K R K^T\nGuarantees numerical symmetry and positive semi-definiteness", LAYER_BG4, CYAN_ACCENT, TEXT_WHITE)

    # Block D: Weighted Voter Consensus
    add_arch_box(s6, Inches(4.7), Inches(4.25), Inches(4.0), Inches(2.6), "4. WEIGHTED AVERAGE VOTING CONSENSUS", "Agreement: s_ij = 1 / (1 + (d_ij / a)^n)\nParameters: a_xy = 0.5m, n_xy = 6 | a_z = 0.5m, n_z = 2\nWeights: w_i = (∑_{j≠i} s_ij) / (∑_k ∑_{j≠k} s_kj)\nConsensus Output: y_voted = w_1 y_1 + w_2 y_2 + w_3 y_3", LAYER_BG2, EMERALD_ACC, TEXT_WHITE)

    # Block E: FDI Engine & Recovery Solutions
    add_arch_box(s6, Inches(8.9), Inches(1.5), Inches(3.6), Inches(5.35), "5. FDI DISCRIMINATOR & RECOVERY", "Fault Thresholds (Table 2):\n• ΔGPS > 2.0m ==> GPS Hardware Fault\n• ΔLidar > 1.0m ==> Lidar Hardware Fault\n• ΔIMU > 0.05 m/s² ==> IMU Fault\n\nSoftware Covariance Bug Check:\n• min(diag(P_KF1)) < 0 ==> Software Corruption!\n\n3 Recovery Solutions (Section 5.4):\n• Sol 1: Sensor Substitution (reroute healthy sensor)\n• Sol 2: State Re-initialization (x_KF1 = x_voter)\n• Sol 3: Analytical Failover (KF3 = avg(KF2, DM))", LAYER_BG3, AMBER_ACC, TEXT_WHITE)

    # ═════════════════════════════════════════════════════════════════════════
    # 7. SIMULATION PART (PART 1: REAL-WORLD 3D MUJOCO AIRFIELD)
    # ═════════════════════════════════════════════════════════════════════════
    s7 = create_base_slide(prs, "Simulation Part (Part 1: Real-World 3D MuJoCo Environment)", "06 / 3D SIMULATION")

    add_card(s7, Inches(0.8), Inches(1.5), Inches(5.6), Inches(5.3), "REAL-WORLD AIRFIELD & WEATHER PHYSICS")
    tb = s7.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(5.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Airfield Terrain (tarot650_3d.xml):\n"
        "  - 60m paved asphalt runway with white centerline markings\n"
        "  - Concrete helipad with red & yellow safety rings and 'H' emblem\n"
        "  - Dual flight hangars, Air Traffic Control tower with radar dome, perimeter floodlights, and runway trees.\n\n"
        "• Authentic Tarot 650 Quadrotor Airframe:\n"
        "  - Diagonal carbon arms (l = 0.23m), spinning dual-blade propellers\n"
        "  - Pixhawk avionics stack with LED status, GPS mast, Lidar, FPV camera\n"
        "  - Zero visual clutter: cyan line scribbles eliminated.\n\n"
        "• Dynamic Wind & Rain Simulation:\n"
        "  - Turbulent wind gusts (4.0–6.5 m/s) with sinusoidal surges\n"
        "  - 3D animated falling rain particle streaks drifting with wind velocity."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    if os.path.exists(img_render):
        s7.shapes.add_picture(img_render, Inches(6.8), Inches(1.5), Inches(5.7), Inches(5.3))

    # ═════════════════════════════════════════════════════════════════════════
    # 8. SIMULATION PART (PART 2: EXPERIMENTAL SCENARIOS & RESULTS)
    # ═════════════════════════════════════════════════════════════════════════
    s8 = create_base_slide(prs, "Simulation Part (Part 2: 4 Failure Scenarios & Paper Validation Plots)", "06 / 3D SIMULATION")

    add_card(s8, Inches(0.8), Inches(1.5), Inches(3.6), Inches(5.3), "4 VALIDATION SCENARIOS")
    tb = s8.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(3.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Situation 1: GPS Fault (+5m):\n"
        "  Injected at t=7.0s. Detected in 0.02s. KF1 isolated, drone flies rightwards down runway safely.\n\n"
        "• Situation 2: Lidar Fault (-1m):\n"
        "  Injected at t=17.8s. Altitude held steady at 3.0m without dipping.\n\n"
        "• Situation 3: SW Alt Fault (P_z=-0.1):\n"
        "  Instant covariance check catches negative variance. KF1 disconnected, zero altitude loss.\n\n"
        "• Situation 4: SW Pos Fault (P_xy=-0.01):\n"
        "  Airfield circuit completed safely via KF3=avg(KF2,DM)."
    )
    tf.paragraphs[0].font.size = Pt(10); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    img16 = os.path.join(PLOTS_DIR, 'fig16_gps_fault_xy_positions.png')
    img23 = os.path.join(PLOTS_DIR, 'fig23_software_altitude_fault.png')
    if os.path.exists(img16): s8.shapes.add_picture(img16, Inches(4.7), Inches(1.5), Inches(4.0), Inches(5.3))
    if os.path.exists(img23): s8.shapes.add_picture(img23, Inches(8.9), Inches(1.5), Inches(3.6), Inches(5.3))

    # ═════════════════════════════════════════════════════════════════════════
    # 9. FUTURE WORK
    # ═════════════════════════════════════════════════════════════════════════
    s9 = create_base_slide(prs, "Future Work & Research Extensions", "07 / FUTURE PERSPECTIVES")

    add_card(s9, Inches(0.8), Inches(1.5), Inches(3.6), Inches(5.3), "HARDWARE-IN-THE-LOOP (HIL)")
    tb = s9.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(3.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Pixhawk / PX4 Embedded Porting:\n"
        "  Port drone_core.py algorithms to C++ uORB modules on STM32 / Pixhawk 6X autopilot hardware.\n\n"
        "• Dual CAN-Bus Verification:\n"
        "  Benchmark real-time execution across redundant sensor buses at 200 Hz update rates.\n\n"
        "• Physical Outdoor Flight Tests:\n"
        "  Validate sensor fault recovery in outdoor airfield under natural atmospheric wind gusts."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s9, Inches(4.7), Inches(1.5), Inches(3.6), Inches(5.3), "AI & NONLINEAR CONTROL")
    tb = s9.shapes.add_textbox(Inches(4.9), Inches(2.1), Inches(3.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Deep Learning Residual Prediction:\n"
        "  Implement LSTM / Transformer networks to predict sensor degradation before hard threshold crossings.\n\n"
        "• Nonlinear Model Predictive Control (NMPC):\n"
        "  Replace cascaded PD with adaptive NMPC to actively reject dynamic wind drag forces in real-time.\n\n"
        "• Rotor Failure Accommodation:\n"
        "  Extend mixer matrix to handle complete single-motor failure (hexacopter failover)."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s9, Inches(8.6), Inches(1.5), Inches(3.9), Inches(5.3), "MULTI-UAV SWARM RESILIENCE")
    tb = s9.shapes.add_textbox(Inches(8.8), Inches(2.1), Inches(3.5), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• Cooperative Swarm State Voting:\n"
        "  Extend weighted voter to inter-drone communication links for consensus localization in GPS-denied zones.\n\n"
        "• Peer-to-Peer Sensor Sharing:\n"
        "  Allow healthy drones in a formation to broadcast reference GPS/Lidar anchors to impaired drones.\n\n"
        "• Swarm Fault-Tolerance Standards:\n"
        "  Establish certifiable software fault detection protocols for commercial drone delivery fleets."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    # ═════════════════════════════════════════════════════════════════════════
    # 10. CONCLUSION
    # ═════════════════════════════════════════════════════════════════════════
    s10 = create_base_slide(prs, "Conclusion & Project Summary", "08 / CONCLUSION")

    add_card(s10, Inches(0.8), Inches(1.5), Inches(5.6), Inches(5.3), "SUMMARY OF ACHIEVEMENTS")
    tb = s10.shapes.add_textbox(Inches(1.0), Inches(2.1), Inches(5.2), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "✓ 100% Replication of Hamadi et al. (ISA Trans. 2022):\n"
        "  Faithfully reproduced all 12 validation figures, motor polynomials, and 4 failure scenarios.\n\n"
        "✓ Solved the Software Fault Vulnerability:\n"
        "  Designed an FDI engine capable of distinguishing physical sensor offsets from internal software covariance bugs (P_ii < 0).\n\n"
        "✓ Sub-Second Fault Recovery (Solution 3):\n"
        "  Synthesizes KF3 = avg(KF2, DM) with zero navigation delay.\n\n"
        "✓ High-Fidelity 3D Simulation with Wind & Rain:\n"
        "  Real-world airfield environment with active flight down runway and clean corner HUD diagnostics."
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    add_card(s10, Inches(6.8), Inches(1.5), Inches(5.7), Inches(5.3), "CLEAN 2-FILE ARCHITECTURE & RUN GUIDE")
    tb = s10.shapes.add_textbox(Inches(7.0), Inches(2.1), Inches(5.3), Inches(4.5))
    tf = tb.text_frame; tf.word_wrap = True
    tf.paragraphs[0].text = (
        "• File 1: simulation_3d.py\n"
        "  Unified 3D real-world flight simulation, weather physics, and interactive viewer.\n\n"
        "• File 2: drone_core.py\n"
        "  All core algorithms, state estimators, voters, controller, and paper figure generators.\n\n"
        "• Execution Commands:\n"
        "  python simulation_3d.py --situation 1   # Run 3D Flight\n"
        "  python drone_core.py --plots           # Generate Paper Plots\n\n"
        "• Presentation File: Tarot650_Fault_Tolerant_UAV_Presentation.pptx\n"
        "  Ready for direct Canva import and high-impact presentation!"
    )
    tf.paragraphs[0].font.size = Pt(10.5); tf.paragraphs[0].font.color.rgb = TEXT_MUTED

    # Save to all target paths
    out1 = os.path.join(os.path.dirname(__file__), 'Tarot650_Fault_Tolerant_UAV_Presentation.pptx')
    prs.save(out1)
    saved_paths = [out1]

    user_dl = os.path.join(os.path.expanduser('~'), 'Downloads')
    if os.path.exists(user_dl):
        out2 = os.path.join(user_dl, 'Tarot650_Fault_Tolerant_UAV_Presentation.pptx')
        try:
            prs.save(out2)
            saved_paths.append(out2)
        except Exception:
            pass

    print(f"  [Presentation Updated with Architecture Diagrams] Saved to:")
    for p in saved_paths:
        print(f"    - {p}")


if __name__ == '__main__':
    build_presentation()
