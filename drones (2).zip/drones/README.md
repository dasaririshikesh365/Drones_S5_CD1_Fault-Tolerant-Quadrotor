# Tarot 650 Quadrotor UAV Fault-Tolerant 3D Flight Simulation

Implementation of the research paper:  
**"Sensor & Software Fault-Tolerant Control for Quadrotor UAVs"** (Hamadi et al., *ISA Transactions* 129 (2022), pp. 520–539).

---

## 1. Quick Launch (One-Click)

* Double-click **`run_simulation.bat`** inside this folder (or **`run_drone_simulation.bat`** in Downloads).
* An interactive menu will appear allowing you to select any of the 4 fault situations or generate plots/presentations.

Alternatively, via terminal / command prompt:
```bash
# Interactive selection menu
python simulation_3d.py

# Or launch a specific situation directly:
python simulation_3d.py --situation 1   # GPS Hardware Fault (+5m at t=7s)
python simulation_3d.py --situation 2   # Lidar Hardware Fault (-1m at t=17.8s)
python simulation_3d.py --situation 3   # Software Altitude Fault (KF1 P_z = -0.1)
python simulation_3d.py --situation 4   # Software Position Fault (KF1 P_xy = -0.01)

# Generate paper figures
python drone_core.py --plots

# Generate PowerPoint presentation
python generate_presentation.py
```

---

## 2. Interactive 3D Viewer Controls

When the 3D MuJoCo window opens:
* **Left Mouse Click + Drag**: Orbit 360° around the drone.
* **Right Mouse Click + Drag**: Pan camera across the airfield.
* **Mouse Scroll Wheel**: Zoom in and out.
* **Spacebar**: Pause / Resume flight.
* **Esc**: Exit simulation window.

---

## 3. Flight Situations & Fault Scenarios

| Situation | Description | Injected Fault | Recovery Mechanism |
| :--- | :--- | :--- | :--- |
| **Situation 1** | GPS Hardware Fault | +5m step bias injected into GPS1 at $t=7.0$s | Weighted voter detects divergence ($s_{12} < 0.1$), isolates GPS1, switches to redundant GPS2 |
| **Situation 2** | Lidar Hardware Fault | -1m altitude bias injected into Lidar1 at $t=17.8$s | Voter isolates corrupted Lidar1, switches altitude estimation to redundant sensor |
| **Situation 3** | Software Altitude Fault | KF1 altitude error covariance corrupted ($P_z = -0.1$) | Software discriminator detects covariance corruption ($P_{ii} < 0$), isolates KF1, synthesizes $KF_3 = \text{avg}(KF_2, DM)$ |
| **Situation 4** | Software Position Fault | KF1 position error covariance corrupted ($P_{xy} = -0.01$) | Software discriminator detects corruption ($P_{ii} < 0$), switches flight controller to nominal $KF_2$ and Dynamic Model |

---

## 4. Key Files

* `simulation_3d.py`: Real-time 3D MuJoCo flight simulator with dynamic wind, rain particle system, HUD telemetry cards, and multi-branch recovery.
* `drone_core.py`: Mathematical models (motor polynomials, EKF with Joseph-form updates, analytical dynamic model branch, weighted average voters).
* `tarot650_3d.xml`: High-fidelity 3D MuJoCo model of the Tarot 650 quadrotor, runway, airfield, hangars, and control tower.
* `generate_presentation.py`: Generates the complete PowerPoint presentation slides.
* `run_simulation.bat`: One-click startup script.
