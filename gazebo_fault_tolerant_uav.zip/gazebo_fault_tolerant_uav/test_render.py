
import matplotlib.pyplot as plt

plt.rcParams['mathtext.fontset'] = 'cm'
fig, ax = plt.subplots(figsize=(7, 1.4), dpi=300)
fig.patch.set_alpha(0.0)
ax.patch.set_alpha(0.0)
ax.axis('off')

eq = r'{ij} = \frac{1}{1 + \left(\frac{d_{ij}}{a}\right)^n}, \quad w_i = \frac{\sum_{j \neq i} s_{ij}}{\sum_{k} \sum_{j \neq k} s_{kj}}$'
ax.text(0.5, 0.5, eq, fontsize=18, color='#38bdf8', ha='center', va='center')

plt.savefig('test_eq2.png', transparent=True, bbox_inches='tight', pad_inches=0.08)
print('Done!')
