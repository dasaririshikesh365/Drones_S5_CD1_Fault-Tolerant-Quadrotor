"""
Automated Experiment Suite Runner.
Runs all scenarios (A through I) for both Baseline and Fault-Tolerant architectures,
logs all CSV time-histories, calculates quantitative metrics, and generates a comparative summary table.
"""

import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.fault_injector import FaultProfile, ScenarioType
from uav_fault_tolerance.simulation_engine import SimulationRunner


def run_experiment(scenario_type: ScenarioType, enable_ft: bool, duration: float = 30.0) -> dict:
    """Run one single experiment condition and compute summary metrics."""
    traj_mode = "hover" if scenario_type in (
        ScenarioType.SCENARIO_C_ALTITUDE_FAULT,
        ScenarioType.SCENARIO_F_SOFTWARE_EKF1,
        ScenarioType.SCENARIO_G_SOFTWARE_EKF2
    ) else "u_path"

    # Specific timing matching paper
    if scenario_type == ScenarioType.SCENARIO_C_ALTITUDE_FAULT:
        t_start, t_end = 17.8, 30.0
        mag = 1.0
    elif scenario_type in (ScenarioType.SCENARIO_F_SOFTWARE_EKF1, ScenarioType.SCENARIO_G_SOFTWARE_EKF2):
        t_start, t_end = 0.0, 30.0
        mag = 0.1
    else:
        t_start, t_end = 7.0, 15.8
        mag = 5.0

    profile = FaultProfile(
        scenario=scenario_type,
        t_start=t_start,
        t_end=t_end,
        magnitude=mag,
        target_branch=1 if scenario_type != ScenarioType.SCENARIO_G_SOFTWARE_EKF2 else 2,
        secondary_t_start=20.0,
        secondary_t_end=28.0
    )

    runner = SimulationRunner(
        fault_profile=profile,
        enable_fault_tolerance=enable_ft,
        trajectory_mode=traj_mode,
        duration=duration
    )

    df = runner.run()

    # Save CSV log
    arch_str = "fault_tolerant" if enable_ft else "baseline"
    os.makedirs("logs", exist_ok=True)
    csv_file = os.path.join("logs", f"{scenario_type.value}_{arch_str}.csv")
    df.to_csv(csv_file, index=False)

    # Metrics computation
    pos_err = np.sqrt((df["gt_x"] - df["fused_x"])**2 + (df["gt_y"] - df["fused_y"])**2 + (df["gt_z"] - df["fused_z"])**2)
    pos_rmse = float(np.sqrt(np.mean(pos_err**2)))
    alt_rmse = float(np.sqrt(np.mean((df["gt_z"] - df["fused_z"])**2)))
    max_pos_err = float(np.max(pos_err))
    track_rmse = float(np.sqrt(np.mean((df["gt_x"] - df["ref_x"])**2 + (df["gt_y"] - df["ref_y"])**2 + (df["gt_z"] - df["ref_z"])**2)))
    att_rmse = float(np.sqrt(np.mean(df["attitude_error_deg"]**2)))

    # Fault timing
    det_steps = df[df["fault_detected"] == 1]
    rec_steps = df[df["recovery_active"] == 1]

    t_det = float(det_steps["time"].iloc[0]) if len(det_steps) > 0 else np.nan
    t_rec = float(rec_steps["time"].iloc[0]) if len(rec_steps) > 0 else np.nan

    det_delay = (t_det - t_start) if (not np.isnan(t_det) and t_det >= t_start) else np.nan
    rec_delay = (t_rec - t_det) if (not np.isnan(t_rec) and not np.isnan(t_det)) else np.nan

    # Identify if recovered and stable
    recovered = bool(len(rec_steps) > 0) or (scenario_type == ScenarioType.SCENARIO_A_HEALTHY)
    stable = bool(max_pos_err < 10.0)

    return {
        "Scenario": scenario_type.value,
        "Architecture": "Proposed FT" if enable_ft else "Baseline",
        "Traj_Mode": traj_mode,
        "Fault_Start_s": t_start if scenario_type != ScenarioType.SCENARIO_A_HEALTHY else np.nan,
        "Fault_End_s": t_end if scenario_type != ScenarioType.SCENARIO_A_HEALTHY else np.nan,
        "Detection_Time_s": round(t_det, 3) if not np.isnan(t_det) else None,
        "Detection_Delay_s": round(det_delay, 3) if not np.isnan(det_delay) else None,
        "Recovery_Time_s": round(t_rec, 3) if not np.isnan(t_rec) else None,
        "Recovery_Delay_s": round(rec_delay, 3) if not np.isnan(rec_delay) else None,
        "Pos_RMSE_m": round(pos_rmse, 4),
        "Alt_RMSE_m": round(alt_rmse, 4),
        "Max_Pos_Dev_m": round(max_pos_err, 4),
        "Tracking_RMSE_m": round(track_rmse, 4),
        "Attitude_RMSE_deg": round(att_rmse, 3),
        "Recovered": recovered,
        "Stable": stable
    }


def main():
    print("=" * 80)
    print("STARTING FULL EXPERIMENTAL SUITE (SCENARIOS A THROUGH I)")
    print("Comparing Proposed Fault-Tolerant Architecture vs Baseline Across All Scenarios")
    print("=" * 80)

    scenarios = [
        ScenarioType.SCENARIO_A_HEALTHY,
        ScenarioType.SCENARIO_B_GPS_BIAS,
        ScenarioType.SCENARIO_C_ALTITUDE_FAULT,
        ScenarioType.SCENARIO_D_IMU_FREEZE,
        ScenarioType.SCENARIO_E_IMU_NOISE_DRIFT,
        ScenarioType.SCENARIO_F_SOFTWARE_EKF1,
        ScenarioType.SCENARIO_G_SOFTWARE_EKF2,
        ScenarioType.SCENARIO_H_RECOVERY_TEST,
        ScenarioType.SCENARIO_I_SEQUENTIAL_FAULTS
    ]

    results = []

    for scen in scenarios:
        print(f"\n---> Running Scenario: {scen.value} [Proposed Fault-Tolerant]...")
        res_ft = run_experiment(scen, enable_ft=True, duration=30.0)
        results.append(res_ft)
        print(f"     FT Pos RMSE: {res_ft['Pos_RMSE_m']} m, Det Delay: {res_ft['Detection_Delay_s']} s, Stable: {res_ft['Stable']}")

        print(f"---> Running Scenario: {scen.value} [Baseline Unprotected]...")
        res_base = run_experiment(scen, enable_ft=False, duration=30.0)
        results.append(res_base)
        print(f"     Baseline Pos RMSE: {res_base['Pos_RMSE_m']} m, Max Dev: {res_base['Max_Pos_Dev_m']} m, Stable: {res_base['Stable']}")

    summary_df = pd.DataFrame(results)
    summary_csv = os.path.join("logs", "experiment_summary_metrics.csv")
    summary_df.to_csv(summary_csv, index=False)
    print("\n" + "=" * 80)
    print(f"ALL EXPERIMENTS COMPLETE! Master summary saved to: {summary_csv}")
    print("=" * 80)
    print(summary_df[["Scenario", "Architecture", "Pos_RMSE_m", "Max_Pos_Dev_m", "Detection_Delay_s", "Stable"]].to_string(index=False))


if __name__ == "__main__":
    main()
