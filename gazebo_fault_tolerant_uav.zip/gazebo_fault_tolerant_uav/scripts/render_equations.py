"""
render_equations.py
===================
Renders all mathematical equations from Hamadi et al. (ISA Trans. 2022) into
crisp, publication-quality transparent PNGs using matplotlib's mathtext with
Computer Modern typography.
"""

import os
import matplotlib
import matplotlib.pyplot as plt

plt.rcParams['mathtext.fontset'] = 'cm'
plt.rcParams['font.family'] = 'serif'

OUTPUT_DIR = r"E:\projects\s5 projects\drones\gazebo_fault_tolerant_uav\docs\equation_renders"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Format: (filename, latex_code, figsize, fontsize, text_color)
EQUATIONS = [
    # 1. Newton Euler Dynamics
    (
        "eq01_newton_euler.png",
        r"$m \ddot{\mathbf{p}} = \mathbf{R} \left[ 0, \; 0, \; \sum_{i=1}^4 F_i \right]^T - \left[ 0, \; 0, \; mg \right]^T - \mathbf{F}_{\mathrm{drag}}, \quad \mathbf{J} \dot{\boldsymbol{\omega}} = \boldsymbol{\tau} - \boldsymbol{\omega} \times (\mathbf{J} \boldsymbol{\omega})$",
        (11.5, 1.2),
        16,
        "#38bdf8"
    ),
    # 2. Motor Polynomials
    (
        "eq02_motor_polynomials.png",
        r"$F_i(u) = -1.4736 u^3 + 11.0691 u^2 - 16.7074 u + 7.3007 \; [\mathrm{N}], \quad \tau_i(u) = -0.0905 u^3 + 0.4771 u^2 - 0.6790 u + 0.3045 \; [\mathrm{N}\cdot\mathrm{m}]$",
        (12.0, 1.2),
        15,
        "#38bdf8"
    ),
    # 3. Control Mixer Allocation (4 Channel Equations)
    (
        "eq03_control_mixer.png",
        r"$U_1 = \sum_{i=1}^4 F_i, \quad U_2 = \frac{l}{\sqrt{2}}(-F_1 - F_2 + F_3 + F_4), \quad U_3 = \frac{l}{\sqrt{2}}(F_1 - F_2 - F_3 + F_4), \quad U_4 = c(-F_1 + F_2 - F_3 + F_4)$",
        (12.5, 1.3),
        14,
        "#34d399"
    ),
    # 4. State Vector & Propagation
    (
        "eq04_state_propagation.png",
        r"$\mathbf{x} = \left[ x, \; y, \; z, \; \dot{x}, \; \dot{y}, \; \dot{z}, \; \phi, \; \theta, \; \psi \right]^T \in \mathbb{R}^9, \quad \hat{\mathbf{x}}_{k|k-1} = \mathbf{f}(\hat{\mathbf{x}}_{k-1}, \mathbf{u}_{k-1}), \quad \mathbf{P}_{k|k-1} = \mathbf{F}_k \mathbf{P}_{k-1} \mathbf{F}_k^T + \mathbf{Q}_k$",
        (12.5, 1.2),
        14,
        "#38bdf8"
    ),
    # 5. Joseph Form Covariance Update
    (
        "eq05_joseph_update.png",
        r"$\mathbf{P}_k = (\mathbf{I} - \mathbf{K}_k \mathbf{H}_k) \mathbf{P}_{k|k-1} (\mathbf{I} - \mathbf{K}_k \mathbf{H}_k)^T + \mathbf{K}_k \mathbf{R}_k \mathbf{K}_k^T$",
        (8.5, 1.2),
        17,
        "#fbbf24"
    ),
    # 6. Pairwise Agreement Indicator
    (
        "eq06_agreement_indicator.png",
        r"$s_{ij} = \frac{1}{1 + \left(\frac{d_{ij}}{a}\right)^n}, \quad d_{ij} = \|\mathbf{y}_i - \mathbf{y}_j\|, \quad a_{xy}=0.5\,\mathrm{m}, \; n_{xy}=6, \quad a_z=0.5\,\mathrm{m}, \; n_z=2$",
        (11.0, 1.3),
        15,
        "#34d399"
    ),
    # 7. Voter Weights and Consensus
    (
        "eq07_voter_consensus.png",
        r"$w_i = \frac{\sum_{j \neq i} s_{ij}}{\sum_{k} \sum_{j \neq k} s_{kj}}, \quad \mathbf{y}_v = \sum_{i=1}^m w_i \mathbf{y}_i = w_1 \mathbf{y}_1 + w_2 \mathbf{y}_2 + w_3 \mathbf{y}_3$",
        (9.5, 1.5),
        17,
        "#38bdf8"
    ),
    # 8. Hardware Fault Thresholds
    (
        "eq08_fdi_thresholds.png",
        r"$\Delta_{\mathrm{GPS}} = \|\mathbf{p}_{\mathrm{GPS1}} - \mathbf{p}_{\mathrm{GPS2}}\| > 2.0\,\mathrm{m}, \quad \Delta_{\mathrm{Lidar}} = |z_{\mathrm{L1}} - z_{\mathrm{L2}}| > 1.0\,\mathrm{m}, \quad \Delta_{\mathrm{IMU}} > 0.05\,\mathrm{m/s}^2$",
        (11.0, 1.2),
        15,
        "#f87171"
    ),
    # 9. Software Covariance Fault Detector
    (
        "eq09_software_fault.png",
        r"$\min_{i} \left( \mathbf{P}_{ii}^{\mathrm{KF1}} \right) < 0 \quad \Rightarrow \quad \mathrm{Internal \; Software \; Failure \; (Covariance \; Collapse)}$",
        (10.5, 1.2),
        15,
        "#f43f5e"
    ),
    # 10. Solution 3 Failover Recovery
    (
        "eq10_solution3_recovery.png",
        r"$\hat{\mathbf{x}}_{\mathrm{KF3}} = \frac{1}{2} \left( \hat{\mathbf{x}}_{\mathrm{KF2}} + \hat{\mathbf{x}}_{\mathrm{DM}} \right), \quad \mathbf{y}_{\mathrm{voted}} \leftarrow \hat{\mathbf{x}}_{\mathrm{KF3}}$",
        (8.5, 1.3),
        17,
        "#34d399"
    ),
    # 11. Aerodynamic Drag & Wind
    (
        "eq11_aerodynamic_drag.png",
        r"$\mathbf{F}_{\mathrm{drag}} = \frac{1}{2} \rho C_d A \|\mathbf{v}_{\mathrm{rel}}\| \mathbf{v}_{\mathrm{rel}}, \quad \mathbf{v}_{\mathrm{rel}} = \mathbf{v}_{\mathrm{uav}} - \mathbf{v}_{\mathrm{wind}}(t)$",
        (8.5, 1.2),
        16,
        "#60a5fa"
    )
]

def render_all():
    print(f"Rendering {len(EQUATIONS)} publication-quality LaTeX equations...")
    for filename, latex_str, (w, h), fsize, color in EQUATIONS:
        fig, ax = plt.subplots(figsize=(w, h), dpi=300)
        fig.patch.set_alpha(0.0)
        ax.patch.set_alpha(0.0)
        ax.axis('off')
        
        ax.text(0.5, 0.5, latex_str, fontsize=fsize, color=color, ha='center', va='center')
        
        out_path = os.path.join(OUTPUT_DIR, filename)
        plt.savefig(out_path, transparent=True, bbox_inches='tight', pad_inches=0.06)
        plt.close(fig)
        print(f"  [OK] Rendered {filename} -> {os.path.getsize(out_path)} bytes")

if __name__ == '__main__':
    render_all()
