"""
Launch the Real-Time 3D Interactive Flight Simulator in the default browser.
Supports real-time keyboard piloting, 3D obstacle avoidance, dynamic wind,
live oscilloscope graphs, and on-demand fault injection.

Usage:
    python scripts/launch_flight_simulator.py
"""

import os
import webbrowser

def main():
    html_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "visualization", "interactive_flight_simulator.html"))
    url = f"file:///{html_path.replace(os.sep, '/')}"
    print("=" * 70)
    print("LAUNCHING REAL-TIME 3D FAULT-TOLERANT DRONE SIMULATOR")
    print("Controls:")
    print("  [W] / [S]        : Pitch Forward / Backward")
    print("  [A] / [D]        : Roll Left / Right")
    print("  [Space] / [Shift]: Throttle Up / Down (Climb / Descend)")
    print("  [Q] / [E]        : Yaw Rotation (Left / Right)")
    print("  Camera Buttons   : Switch between Chase, FPV Cockpit, and Orbit")
    print("  Wind Buttons     : Toggle Calm, 5 m/s, 10 m/s, or Storm")
    print("  Fault Injection  : Click GPS Jump, Lidar Drop, or SW Bug to test FT")
    print("=" * 70)
    print(f"Opening: {url}")
    webbrowser.open(url)

if __name__ == "__main__":
    main()
