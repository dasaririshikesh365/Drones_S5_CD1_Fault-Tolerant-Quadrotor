"""
Run Single Simulation Scenario Script.
Usage:
    python scripts/run_single_scenario.py --scenario SCENARIO_B_GPS_BIAS --fault-tolerant
    python scripts/run_single_scenario.py --scenario SCENARIO_B_GPS_BIAS --baseline
"""

import argparse
import sys
import os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.fault_injector import FaultProfile, ScenarioType
from uav_fault_tolerance.simulation_engine import SimulationRunner


def main():
    parser = argparse.ArgumentParser(description="Run UAV Fault-Tolerant Simulation Scenario")
    parser.add_argument("--scenario", type=str, default="SCENARIO_B_GPS_BIAS",
                        choices=[s.value for s in ScenarioType],
                        help="Scenario to simulate")
    parser.add_argument("--fault-tolerant", dest="enable_ft", action="store_true", default=True,
                        help="Enable fault-tolerant multi-branch voting and recovery")
    parser.add_argument("--baseline", dest="enable_ft", action="store_false",
                        help="Run unprotected baseline architecture (single EKF without voting/recovery)")
    parser.add_argument("--duration", type=float, default=40.0, help="Simulation duration (s)")
    parser.add_argument("--output-csv", type=str, default=None, help="Path to save output CSV log")
    args = parser.parse_args()

    scen_type = ScenarioType(args.scenario)
    traj_mode = "hover" if scen_type in (ScenarioType.SCENARIO_C_ALTITUDE_FAULT, ScenarioType.SCENARIO_F_SOFTWARE_EKF1) else "u_path"

    # Configure fault profile
    t_start = 7.0 if scen_type != ScenarioType.SCENARIO_C_ALTITUDE_FAULT else 17.8
    t_end = 15.8 if scen_type != ScenarioType.SCENARIO_C_ALTITUDE_FAULT else 35.0
    magnitude = 5.0 if scen_type in (ScenarioType.SCENARIO_B_GPS_BIAS, ScenarioType.SCENARIO_H_RECOVERY_TEST) else 1.0

    profile = FaultProfile(
        scenario=scen_type,
        t_start=t_start,
        t_end=t_end,
        magnitude=magnitude,
        target_branch=1,
        secondary_t_start=22.0,
        secondary_t_end=32.0
    )

    print(f"\n=======================================================")
    print(f"Executing UAV Simulation: {args.scenario}")
    print(f"Architecture: {'PROPOSED FAULT-TOLERANT (Dual-EKF + DM + Voter)' if args.enable_ft else 'BASELINE UNPROTECTED (Single EKF)'}")
    print(f"Trajectory Mode: {traj_mode}, Duration: {args.duration} s")
    print(f"Fault Active: {profile.t_start}s to {profile.t_end}s (Magnitude: {profile.magnitude})")
    print(f"=======================================================\n")

    runner = SimulationRunner(
        fault_profile=profile,
        enable_fault_tolerance=args.enable_ft,
        trajectory_mode=traj_mode,
        duration=args.duration
    )

    df = runner.run()

    # Determine default CSV output name if not provided
    mode_str = "fault_tolerant" if args.enable_ft else "baseline"
    if args.output_csv is None:
        os.makedirs("logs", exist_ok=True)
        csv_path = os.path.join("logs", f"{args.scenario}_{mode_str}.csv")
    else:
        csv_path = args.output_csv
        os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)

    df.to_csv(csv_path, index=False)
    print(f"Simulation completed! Saved {len(df)} records to {csv_path}")

    # Compute quantitative performance metrics
    pos_rmse = np.sqrt(np.mean((df["gt_x"] - df["fused_x"])**2 + (df["gt_y"] - df["fused_y"])**2 + (df["gt_z"] - df["fused_z"])**2))
    alt_rmse = np.sqrt(np.mean((df["gt_z"] - df["fused_z"])**2))
    max_pos_dev = np.max(np.sqrt((df["gt_x"] - df["fused_x"])**2 + (df["gt_y"] - df["fused_y"])**2 + (df["gt_z"] - df["fused_z"])**2))
    track_rmse = np.sqrt(np.mean((df["gt_x"] - df["ref_x"])**2 + (df["gt_y"] - df["ref_y"])**2 + (df["gt_z"] - df["ref_z"])**2))
    att_rmse = np.sqrt(np.mean(df["attitude_error_deg"]**2))

    # Fault detection and recovery timing
    det_steps = df[df["fault_detected"] == 1]
    rec_steps = df[df["recovery_active"] == 1]

    t_det = det_steps["time"].iloc[0] if len(det_steps) > 0 else None
    t_rec = rec_steps["time"].iloc[0] if len(rec_steps) > 0 else None

    det_delay = (t_det - profile.t_start) if (t_det is not None and t_det >= profile.t_start) else None
    rec_delay = (t_rec - t_det) if (t_rec is not None and t_det is not None) else None

    print(f"\n--- PERFORMANCE METRICS ---")
    print(f"Position Estimation RMSE: {pos_rmse:.4f} m")
    print(f"Altitude Estimation RMSE: {alt_rmse:.4f} m")
    print(f"Maximum Position Deviation: {max_pos_dev:.4f} m")
    print(f"Trajectory Tracking RMSE: {track_rmse:.4f} m")
    print(f"Attitude Error RMSE: {att_rmse:.4f} deg")

    if t_det is not None and det_delay is not None:
        print(f"Fault Injected: {profile.t_start:.2f} s")
        print(f"Fault Detected: {t_det:.2f} s (Delay: {det_delay:.3f} s)")
        if t_rec is not None and rec_delay is not None:
            print(f"Recovery Activated: {t_rec:.2f} s (Delay: {rec_delay:.3f} s)")
    else:
        print("No faults detected or baseline mode active.")

    # Flight stability check
    max_alt = df["gt_z"].max()
    final_alt = df["gt_z"].iloc[-1]
    is_stable = (max_pos_dev < 15.0) and not np.isnan(final_alt)
    print(f"Flight Stability Status: {'STABLE' if is_stable else 'UNSTABLE / CRASHED'}")
    print(f"---------------------------\n")


if __name__ == "__main__":
    main()
