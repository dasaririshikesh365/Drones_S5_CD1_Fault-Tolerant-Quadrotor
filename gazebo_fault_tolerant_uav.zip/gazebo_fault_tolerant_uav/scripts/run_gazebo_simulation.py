#!/usr/bin/env python3
"""
Gazebo Simulation Bringup and Orchestration Script.
Launches Gazebo Sim (Harmonic) with the Tarot 650 quadrotor model,
environmental wind effects system, and redundant sensor bridge,
alongside the real-time 3D telemetry and oscilloscope dashboard.

Reference:
    Hamadi et al., "Data fusion fault tolerant strategy for a quadrotor UAV
    under sensors and software faults", ISA Transactions 129 (2022) 520-539.

Usage:
    python scripts/run_gazebo_simulation.py
    python scripts/run_gazebo_simulation.py --gui
    python scripts/run_gazebo_simulation.py --headless --iterations 1000
"""

import os
import sys
import argparse
import subprocess
import webbrowser
import platform
import time


def get_project_root() -> str:
    """Return the absolute path to the project root directory."""
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def check_wsl_available() -> bool:
    """Check if WSL2 is installed and reachable on Windows."""
    if platform.system().lower() != "windows":
        return False
    try:
        res = subprocess.run(["wsl.exe", "-l", "-q"], capture_output=True, text=True, timeout=5)
        return res.returncode == 0
    except Exception:
        return False


def build_wsl_path(windows_path: str) -> str:
    """Convert Windows path (e.g. E:\\projects\\...) to WSL /mnt/e/projects/... path."""
    clean = os.path.abspath(windows_path).replace("\\", "/")
    if len(clean) > 1 and clean[1] == ":":
        drive = clean[0].lower()
        return f"/mnt/{drive}{clean[2:]}"
    return clean


def main():
    parser = argparse.ArgumentParser(description="Launch Fault-Tolerant UAV Simulation in Gazebo Sim")
    parser.add_argument("--gui", action="store_true", help="Launch Gazebo with full 3D GUI (requires X11/WSLg)")
    parser.add_argument("--headless", "-s", action="store_true", default=False, help="Run Gazebo in headless server mode")
    parser.add_argument("--world", default="uav_fault_tolerance_world.sdf", help="World file name in gazebo/worlds")
    parser.add_argument("--iterations", type=int, default=0, help="Number of physics iterations (0 for continuous)")
    parser.add_argument("--no-browser", action="store_true", help="Do not automatically launch 3D live graph dashboard")
    args = parser.parse_args()

    project_root = get_project_root()
    world_rel_path = os.path.join("gazebo", "worlds", args.world)
    world_abs_path = os.path.join(project_root, world_rel_path)
    models_dir = os.path.join(project_root, "gazebo", "models")
    html_dashboard = os.path.join(project_root, "visualization", "interactive_flight_simulator.html")

    print("=" * 75)
    print("   GAZEBO FAULT-TOLERANT QUADROTOR UAV SIMULATION")
    print("   Hamadi et al., ISA Transactions 129 (2022) 520-539")
    print("=" * 75)
    print(f"[*] Project Root    : {project_root}")
    print(f"[*] Gazebo World    : {world_rel_path}")
    print(f"[*] Quadrotor Model : Tarot 650 (Redundant Dual-IMU, Dual-GPS, Dual-Lidar)")
    print(f"[*] Wind Simulation : Dynamic gz-sim-wind-effects-system (Eq. 2, 3)")
    print(f"[*] Fault Tolerance : Triple-Branch Duplication/Comparison + Dynamic Model")
    print("-" * 75)

    # 1. Optionally open browser 3D visualization and live real-time graphs
    if not args.no_browser and os.path.exists(html_dashboard):
        dash_url = f"file:///{html_dashboard.replace(os.sep, '/')}"
        print(f"[+] Opening Real-Time 3D Telemetry & Oscilloscope Dashboard:")
        print(f"    {dash_url}")
        webbrowser.open(dash_url)

    # 2. Determine execution environment (Native Linux vs Windows WSL)
    is_windows = (platform.system().lower() == "windows")
    
    if is_windows:
        if not check_wsl_available():
            print("[!] WSL2 is not detected. Please install WSL2 Ubuntu or run on Linux.")
            print("[!] You can still use the 3D Interactive WebGL Simulator in your browser.")
            return

        wsl_proj_dir = build_wsl_path(project_root)
        wsl_world_path = f"{wsl_proj_dir}/gazebo/worlds/{args.world}"
        wsl_models_dir = f"{wsl_proj_dir}/gazebo/models"

        # Build Gazebo invocation
        gz_flags = "-r"
        if args.headless and not args.gui:
            gz_flags = "-s -r"
        elif not args.gui:
            # Default to GUI if supported, fallback to server
            gz_flags = "-r"

        iter_flag = f"--iterations {args.iterations}" if args.iterations > 0 else ""

        bash_cmd = (
            f"export GZ_SIM_RESOURCE_PATH='{wsl_models_dir}'; "
            f"export SDF_PATH='{wsl_models_dir}'; "
            f"cd '{wsl_proj_dir}/gazebo/worlds' && "
            f"gz sim {gz_flags} -v 2 {iter_flag} '{wsl_world_path}'"
        )

        cmd = ["wsl.exe", "-d", "Ubuntu", "-e", "bash", "-c", bash_cmd]
        print(f"[+] Launching Gazebo Sim in Ubuntu WSL...")
        print(f"    Command: gz sim {gz_flags} {args.world}")
        print("=" * 75)
        print("Simulation is running! Press Ctrl+C in this terminal to stop.")
        print("=" * 75)

        try:
            p = subprocess.Popen(cmd)
            p.wait()
        except KeyboardInterrupt:
            print("\n[+] Gracefully terminating Gazebo simulation...")
            subprocess.run(["wsl.exe", "-d", "Ubuntu", "-e", "bash", "-c", "pkill -f 'gz sim' 2>/dev/null || true"])
            print("[+] Gazebo simulation stopped.")

    else:
        # Native Linux environment
        env = os.environ.copy()
        env["GZ_SIM_RESOURCE_PATH"] = f"{models_dir}:{env.get('GZ_SIM_RESOURCE_PATH', '')}"
        env["SDF_PATH"] = f"{models_dir}:{env.get('SDF_PATH', '')}"

        gz_flags = ["-r"]
        if args.headless and not args.gui:
            gz_flags = ["-s", "-r"]

        cmd = ["gz", "sim"] + gz_flags + ["-v", "2"]
        if args.iterations > 0:
            cmd += ["--iterations", str(args.iterations)]
        cmd.append(world_abs_path)

        print(f"[+] Launching Gazebo Sim natively: {' '.join(cmd)}")
        try:
            p = subprocess.Popen(cmd, env=env, cwd=os.path.join(project_root, "gazebo", "worlds"))
            p.wait()
        except KeyboardInterrupt:
            print("\n[+] Stopping Gazebo...")
            p.terminate()


if __name__ == "__main__":
    main()
