import os
import shutil

BASE_DIR = r"E:\projects\s5 projects\drones\gazebo_fault_tolerant_uav"
DOCS_DIR = os.path.join(BASE_DIR, "docs")
SRC_PLOTS = os.path.join(BASE_DIR, "plots", "paper_figures")
DST_PLOTS_1 = os.path.join(DOCS_DIR, "plots", "paper_figures")
DST_PLOTS_2 = os.path.join(DOCS_DIR, "paper_figures")
ARTIFACT_DIR = r"C:\Users\sathv\.gemini\antigravity\brain\d2487ae7-ef6e-4bfc-94de-3c64a103c862"

os.makedirs(DST_PLOTS_1, exist_ok=True)
os.makedirs(DST_PLOTS_2, exist_ok=True)

for f in os.listdir(SRC_PLOTS):
    src = os.path.join(SRC_PLOTS, f)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(DST_PLOTS_1, f))
        shutil.copy2(src, os.path.join(DST_PLOTS_2, f))

# Also copy equation renders to artifact directory so browser can view if needed
src_eq = os.path.join(DOCS_DIR, "equation_renders")
dst_eq = os.path.join(ARTIFACT_DIR, "equation_renders")
os.makedirs(dst_eq, exist_ok=True)
for f in os.listdir(src_eq):
    src = os.path.join(src_eq, f)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(dst_eq, f))

print("[OK] All presentation assets synchronized successfully!")
