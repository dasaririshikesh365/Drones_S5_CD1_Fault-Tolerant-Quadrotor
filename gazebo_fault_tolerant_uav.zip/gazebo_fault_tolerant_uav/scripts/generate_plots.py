"""
Plotting and Visualization Module.
Generates publication-quality figures matching the figures from Hamadi et al. (2022):
- Fig 16 / 3D trajectory tracking and estimates
- Fig 17 / Agreement indicators s12, s13, s23
- Fig 18-19 / Sensor measurements and residuals vs thresholds
- Fig 21 / Lidar fault altitude estimates and indicators
- Fig 23 / Software fault behavior
- Comparative bar charts comparing Proposed FT vs Baseline
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Styling
plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 10,
    "axes.labelsize": 11,
    "axes.titlesize": 12,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.titlesize": 13,
    "lines.linewidth": 1.5
})


def plot_scenario_b_gps(csv_path: str, output_dir: str = "plots"):
    """Recreates Fig. 16, 17, 18, 19 from the paper for Scenario B (GPS Additive Fault)."""
    df = pd.read_csv(csv_path)
    os.makedirs(output_dir, exist_ok=True)

    # 1. 2D & 3D Trajectory (Paper Fig. 16)
    fig = plt.figure(figsize=(10, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    ax1.plot(df["gt_x"], df["gt_y"], 'k-', label="Ground Truth (RTK)", linewidth=2.0)
    ax1.plot(df["ekf1_x"], df["ekf1_y"], 'r--', label="Branch 1 (KF1, Faulty)", alpha=0.8)
    ax1.plot(df["ekf2_x"], df["ekf2_y"], 'g-.', label="Branch 2 (KF2, Healthy)")
    ax1.plot(df["dm_x"], df["dm_y"], 'b:', label="Branch 3 (Dynamic Model)")
    ax1.plot(df["fused_x"], df["fused_y"], 'm-', label="Voter Output (Recovered)", linewidth=1.8)
    ax1.set_xlabel("x (m)")
    ax1.set_ylabel("y (m)")
    ax1.set_title("UAV Trajectory Tracking (Paper Fig. 16)")
    ax1.legend(loc="best")
    ax1.grid(True)

    ax2 = fig.add_subplot(1, 2, 2, projection='3d')
    ax2.plot(df["gt_x"], df["gt_y"], df["gt_z"], 'k-', label="Ground Truth", linewidth=2.0)
    ax2.plot(df["ekf1_x"], df["ekf1_y"], df["ekf1_z"], 'r--', label="KF1 (Faulty)", alpha=0.7)
    ax2.plot(df["fused_x"], df["fused_y"], df["fused_z"], 'm-', label="Voter Output", linewidth=1.8)
    ax2.set_xlabel("X (m)")
    ax2.set_ylabel("Y (m)")
    ax2.set_zlabel("Z (m)")
    ax2.set_title("3D Flight Path")
    ax2.legend(loc="best")

    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "scenario_b_gps_trajectory_fig16.png"), dpi=300)
    plt.close(fig)

    # 2. Agreement Indicators (Paper Fig. 17)
    fig, axes = plt.subplots(3, 1, figsize=(9, 7), sharex=True)
    axes[0].plot(df["time"], df["s12_pos"], 'b-', label=r"$s_{12}$ (KF1 - KF2)")
    axes[0].axvline(7.0, color='r', linestyle='--', label=r"Fault Injection ($t_{inj}=7.0s$)")
    axes[0].set_ylabel(r"$s_{12}$")
    axes[0].set_ylim([-0.1, 1.1])
    axes[0].legend(loc="upper right")
    axes[0].grid(True)
    axes[0].set_title("Voter Agreement Indicators (Paper Fig. 17)")

    axes[1].plot(df["time"], df["s13_pos"], 'r-', label=r"$s_{13}$ (KF1 - Model)")
    axes[1].axvline(7.0, color='r', linestyle='--')
    axes[1].set_ylabel(r"$s_{13}$")
    axes[1].set_ylim([-0.1, 1.1])
    axes[1].legend(loc="upper right")
    axes[1].grid(True)

    axes[2].plot(df["time"], df["s23_pos"], 'g-', label=r"$s_{23}$ (KF2 - Model)")
    axes[2].axvline(7.0, color='r', linestyle='--')
    axes[2].set_ylabel(r"$s_{23}$")
    axes[2].set_ylim([-0.1, 1.1])
    axes[2].set_xlabel("t (s)")
    axes[2].legend(loc="upper right")
    axes[2].grid(True)

    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "scenario_b_agreement_indicators_fig17.png"), dpi=300)
    plt.close(fig)

    # 3. GPS Raw Measurements & Residuals (Paper Fig. 18 & 19)
    fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    axes[0].plot(df["time"], df["gps1_x"], 'r-', label="GPS1 X (Faulty)", alpha=0.8)
    axes[0].plot(df["time"], df["gps2_x"], 'g-', label="GPS2 X (Healthy)", alpha=0.8)
    axes[0].plot(df["time"], df["gt_x"], 'k--', label="Ground Truth X")
    axes[0].set_ylabel("Position X (m)")
    axes[0].legend(loc="best")
    axes[0].grid(True)
    axes[0].set_title("GPS Measurements and Residuals (Paper Fig. 18-19)")

    axes[1].plot(df["time"], df["res_gps"], 'b-', label=r"$\Delta_{GPS}$ residual ($\|GPS1 - GPS2\|$)")
    axes[1].axhline(2.0, color='r', linestyle='--', label=r"Threshold $Th_{GPS} = 2.0m$ (Table 3)")
    axes[1].axvline(7.0, color='m', linestyle=':', label=r"Fault Injected ($t=7s$)")
    axes[1].set_xlabel("t (s)")
    axes[1].set_ylabel(r"Residual (m)")
    axes[1].set_ylim([0, 10.0])
    axes[1].legend(loc="upper right")
    axes[1].grid(True)

    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "scenario_b_gps_residuals_fig19.png"), dpi=300)
    plt.close(fig)


def plot_scenario_c_lidar(csv_path: str, output_dir: str = "plots"):
    """Recreates Fig. 21 & 22 from the paper for Scenario C (Lidar Fault)."""
    df = pd.read_csv(csv_path)
    os.makedirs(output_dir, exist_ok=True)

    fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    axes[0].plot(df["time"], df["gt_z"], 'k-', label="Ground Truth Altitude", linewidth=2.0)
    axes[0].plot(df["time"], df["ekf1_z"], 'r--', label="KF1 Altitude (Faulty Lidar)", alpha=0.8)
    axes[0].plot(df["time"], df["ekf2_z"], 'g-.', label="KF2 Altitude (Healthy)")
    axes[0].plot(df["time"], df["dm_z"], 'b:', label="DM Altitude")
    axes[0].plot(df["time"], df["fused_z"], 'm-', label="Voter Output (Recovered)", linewidth=1.8)
    axes[0].axvline(17.8, color='r', linestyle='--', label=r"Fault Injected ($t_{inj}=17.8s$)")
    axes[0].set_ylabel("Altitude z (m)")
    axes[0].set_title("Lidar Fault Altitude Estimates (Paper Fig. 21a)")
    axes[0].legend(loc="best")
    axes[0].grid(True)

    axes[1].plot(df["time"], df["res_lidar"], 'b-', label=r"Residual $|Lidar1 - Lidar2|$")
    axes[1].axhline(1.0, color='r', linestyle='--', label=r"Threshold $Th_{Lidar} = 1.0m$ (Table 3)")
    axes[1].axvline(17.8, color='r', linestyle='--')
    axes[1].set_ylabel("Lidar Residual (m)")
    axes[1].set_xlabel("t (s)")
    axes[1].legend(loc="upper right")
    axes[1].grid(True)

    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "scenario_c_lidar_altitude_fig21.png"), dpi=300)
    plt.close(fig)


def plot_scenario_f_software(csv_path: str, output_dir: str = "plots"):
    """Recreates Fig. 23 from the paper for Scenario F (Software Covariance Fault)."""
    df = pd.read_csv(csv_path)
    os.makedirs(output_dir, exist_ok=True)

    fig, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    axes[0].plot(df["time"], df["gt_z"], 'k-', label="Ground Truth Altitude", linewidth=2.0)
    axes[0].plot(df["time"], df["ekf1_z"], 'r--', label="KF1 Altitude (Software Bug $P_z < 0$)", alpha=0.8)
    axes[0].plot(df["time"], df["ekf2_z"], 'g-.', label="KF2 Altitude (Healthy)")
    axes[0].plot(df["time"], df["dm_z"], 'b:', label="DM Altitude")
    axes[0].plot(df["time"], df["fused_z"], 'm-', label="Voter Output", linewidth=1.8)
    axes[0].set_ylabel("Altitude z (m)")
    axes[0].set_title("Software Fault in KF1 During Hover (Paper Fig. 23a)")
    axes[0].legend(loc="best")
    axes[0].grid(True)

    axes[1].plot(df["time"], df["res_lidar"], 'g-', label="Physical Lidar Residual (Healthy)")
    axes[1].axhline(1.0, color='r', linestyle='--', label="Threshold (1.0 m)")
    axes[1].plot(df["time"], df["s12_z"], 'b-', label=r"Voter Agreement $s_{12}$")
    axes[1].set_ylabel("Residual / Indicator")
    axes[1].set_xlabel("t (s)")
    axes[1].legend(loc="best")
    axes[1].grid(True)

    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "scenario_f_software_fault_fig23.png"), dpi=300)
    plt.close(fig)


def plot_comparative_summary(summary_csv: str = "logs/experiment_summary_metrics.csv", output_dir: str = "plots"):
    """Generates comparison bar chart between Proposed FT and Baseline across all scenarios."""
    if not os.path.exists(summary_csv):
        return

    df = pd.read_csv(summary_csv)
    os.makedirs(output_dir, exist_ok=True)

    scenarios = df["Scenario"].unique()
    ft_rows = df[df["Architecture"] == "Proposed FT"].set_index("Scenario")
    base_rows = df[df["Architecture"] == "Baseline"].set_index("Scenario")

    x = np.arange(len(scenarios))
    width = 0.35

    ft_rmse = [ft_rows.loc[s, "Pos_RMSE_m"] if s in ft_rows.index else 0.0 for s in scenarios]
    base_rmse = [base_rows.loc[s, "Pos_RMSE_m"] if s in base_rows.index else 0.0 for s in scenarios]

    clean_labels = [s.replace("SCENARIO_", "").replace("_", " ") for s in scenarios]

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.bar(x - width/2, ft_rmse, width, label='Proposed Fault-Tolerant System', color='#2ecc71', edgecolor='black')
    ax.bar(x + width/2, base_rmse, width, label='Baseline Unprotected System', color='#e74c3c', edgecolor='black')

    ax.set_ylabel('Position Estimation RMSE (m)')
    ax.set_title('Quantitative Comparison: Proposed Fault-Tolerant Architecture vs Baseline')
    ax.set_xticks(x)
    ax.set_xticklabels(clean_labels, rotation=35, ha='right')
    ax.legend(loc="upper left")
    ax.grid(True, axis='y', linestyle='--', alpha=0.7)

    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "comparative_rmse_summary.png"), dpi=300)
    plt.close(fig)
    print(f"Generated comparison plot: {os.path.join(output_dir, 'comparative_rmse_summary.png')}")


def main():
    print("Generating publication-grade visualization plots...")
    logs_dir = "logs"
    plots_dir = "plots"

    if os.path.exists(os.path.join(logs_dir, "SCENARIO_B_GPS_BIAS_fault_tolerant.csv")):
        plot_scenario_b_gps(os.path.join(logs_dir, "SCENARIO_B_GPS_BIAS_fault_tolerant.csv"), plots_dir)

    if os.path.exists(os.path.join(logs_dir, "SCENARIO_C_ALTITUDE_FAULT_fault_tolerant.csv")):
        plot_scenario_c_lidar(os.path.join(logs_dir, "SCENARIO_C_ALTITUDE_FAULT_fault_tolerant.csv"), plots_dir)

    if os.path.exists(os.path.join(logs_dir, "SCENARIO_F_SOFTWARE_EKF1_fault_tolerant.csv")):
        plot_scenario_f_software(os.path.join(logs_dir, "SCENARIO_F_SOFTWARE_EKF1_fault_tolerant.csv"), plots_dir)

    if os.path.exists(os.path.join(logs_dir, "experiment_summary_metrics.csv")):
        plot_comparative_summary(os.path.join(logs_dir, "experiment_summary_metrics.csv"), plots_dir)

    print("All plots generated successfully!")


if __name__ == "__main__":
    main()
