#!/usr/bin/env bash
SCENARIO=${1:-SCENARIO_B_GPS_BIAS}
TELEOP=${2:-false}
echo "=========================================================="
echo " Launching Fault-Tolerant UAV Architecture (Hamadi et al.)"
echo " Scenario: $SCENARIO"
echo " Keyboard Teleoperation: $TELEOP"
echo "=========================================================="
source /opt/ros/jazzy/setup.bash
cd "/mnt/e/projects/s5 projects/drones/gazebo_fault_tolerant_uav"
source install/setup.bash
ros2 launch uav_fault_tolerance fault_tolerant_system.launch.py scenario:=$SCENARIO teleop:=$TELEOP
