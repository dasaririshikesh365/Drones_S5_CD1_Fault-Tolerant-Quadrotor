"""
Launch 3D Web Flight Simulation in default browser.
Usage:
    python scripts/launch_visualization.py
"""

import os
import webbrowser

def main():
    html_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "visualization", "drone_3d_simulation.html"))
    print(f"Opening 3D Flight Simulation Viewer in default web browser...")
    print(f"File: {html_path}")
    webbrowser.open(f"file:///{html_path.replace(os.sep, '/')}")

if __name__ == "__main__":
    main()
