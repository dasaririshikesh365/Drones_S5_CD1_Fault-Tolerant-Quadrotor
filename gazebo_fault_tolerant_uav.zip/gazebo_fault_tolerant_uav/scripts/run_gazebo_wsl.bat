@echo off
echo ====================================================================
echo Launching Gazebo Harmonic Simulator inside WSL2 (Drive E:)
echo ====================================================================
wsl -d Ubuntu -- bash -c "chmod +x '/mnt/e/projects/s5 projects/drones/gazebo_fault_tolerant_uav/scripts/'*.sh && cd '/mnt/e/projects/s5 projects/drones/gazebo_fault_tolerant_uav' && ./scripts/launch_gazebo.sh obstacle_course"
pause
