#!/usr/bin/env bash
WORLD=${1:-obstacle_course}
echo "=========================================================="
echo " Launching Gazebo Harmonic Simulator"
echo " World: $WORLD"
echo " Available worlds: open_arena | obstacle_course | narrow_corridor | fault_tolerance"
echo "=========================================================="
source /opt/ros/jazzy/setup.bash
cd "/mnt/e/projects/s5 projects/drones/gazebo_fault_tolerant_uav"
source install/setup.bash
export GZ_SIM_RESOURCE_PATH=$PWD/gazebo/models:$GZ_SIM_RESOURCE_PATH
ros2 launch uav_fault_tolerance simulation.launch.py world:=$WORLD
