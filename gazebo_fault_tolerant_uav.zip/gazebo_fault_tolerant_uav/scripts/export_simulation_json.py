"""Export CSV flight logs to downsampled JSON format for Web 3D visualization."""
import os
import json
import pandas as pd

scenarios = [
    "SCENARIO_B_GPS_BIAS",
    "SCENARIO_C_ALTITUDE_FAULT",
    "SCENARIO_F_SOFTWARE_EKF1"
]

all_data = {}

for scen in scenarios:
    csv_file = os.path.join("logs", f"{scen}_fault_tolerant.csv")
    if not os.path.exists(csv_file):
        continue
    df = pd.read_csv(csv_file)
    # Downsample from 100 Hz to 10 Hz (every 10th row)
    sub = df.iloc[::10].copy()

    records = []
    for _, row in sub.iterrows():
        records.append({
            "t": round(float(row["time"]), 2),
            "gt": [round(float(row["gt_x"]), 3), round(float(row["gt_y"]), 3), round(float(row["gt_z"]), 3)],
            "att": [round(float(row["gt_roll"]), 1), round(float(row["gt_pitch"]), 1), round(float(row["gt_yaw"]), 1)],
            "ekf1": [round(float(row["ekf1_x"]), 3), round(float(row["ekf1_y"]), 3), round(float(row["ekf1_z"]), 3)],
            "ekf2": [round(float(row["ekf2_x"]), 3), round(float(row["ekf2_y"]), 3), round(float(row["ekf2_z"]), 3)],
            "fused": [round(float(row["fused_x"]), 3), round(float(row["fused_y"]), 3), round(float(row["fused_z"]), 3)],
            "s12": round(float(row["s12_pos"]), 3),
            "s13": round(float(row["s13_pos"]), 3),
            "s23": round(float(row["s23_pos"]), 3),
            "w": [round(float(row["w1"]), 3), round(float(row["w2"]), 3), round(float(row["w3"]), 3)],
            "res_gps": round(float(row["res_gps"]), 2),
            "res_lidar": round(float(row["res_lidar"]), 2),
            "fault_det": int(row["fault_detected"]),
            "rec_act": int(row["recovery_active"]),
            "fault_type": str(row["fault_type"])
        })
    all_data[scen] = records

out_js = os.path.join("visualization", "simulation_data.js")
with open(out_js, "w") as f:
    f.write(f"const SIMULATION_DATA = {json.dumps(all_data)};\n")

print(f"Exported simulation datasets to {out_js}")
