#!/usr/bin/env bash
# Launch Fault-Tolerant UAV Simulation in Gazebo Sim (Harmonic)

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "========================================================================"
echo "  Launching Fault-Tolerant Tarot 650 UAV Simulation in Gazebo Sim"
echo "  Hamadi et al., ISA Transactions 129 (2022) 520-539"
echo "========================================================================"

export GZ_SIM_RESOURCE_PATH="${PROJECT_ROOT}/gazebo/models:${GZ_SIM_RESOURCE_PATH}"
export SDF_PATH="${PROJECT_ROOT}/gazebo/models:${SDF_PATH}"

cd "${PROJECT_ROOT}/gazebo/worlds"

# Launch Gazebo with the wind-enabled fault tolerance world
gz sim -r uav_fault_tolerance_world.sdf "$@"
