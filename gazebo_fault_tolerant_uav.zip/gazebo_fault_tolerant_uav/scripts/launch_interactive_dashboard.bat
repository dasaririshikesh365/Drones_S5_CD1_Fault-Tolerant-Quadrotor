@echo off
echo ====================================================================
echo Starting Interactive 3D Drone Simulator & Live Telemetry Dashboard
echo Research Implementation: Hamadi et al., ISA Transactions (2022)
echo ====================================================================
start "" "E:\projects\s5 projects\drones\gazebo_fault_tolerant_uav\visualization\interactive_flight_simulator.html"
