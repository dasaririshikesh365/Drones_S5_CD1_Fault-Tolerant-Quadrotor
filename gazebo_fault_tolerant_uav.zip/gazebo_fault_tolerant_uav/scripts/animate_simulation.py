"""
Interactive 3D Flight Animation Player.
Visualizes the quadrotor 3D pose, attitude, spinning rotors, trajectory trails,
and real-time voter agreement indicators from actual simulation logs.

Usage:
    python scripts/animate_simulation.py
    python scripts/animate_simulation.py --scenario SCENARIO_B_GPS_BIAS
    python scripts/animate_simulation.py --scenario SCENARIO_F_SOFTWARE_EKF1
"""

import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from uav_fault_tolerance.quaternion_math import euler_to_quaternion, quaternion_to_rotation_matrix


def get_quadrotor_geometry(pos: np.ndarray, roll: float, pitch: float, yaw: float, arm_len: float = 0.23):
    """Compute 3D coordinates of quadrotor frame and 4 rotors oriented in space."""
    q = euler_to_quaternion(np.radians(roll), np.radians(pitch), np.radians(yaw))
    R = quaternion_to_rotation_matrix(q)

    # Cross arms in body frame (FLU / X-configuration)
    # Motor 1: Front-Right (+x, -y)
    # Motor 2: Back-Left (-x, +y)
    # Motor 3: Front-Left (+x, +y)
    # Motor 4: Back-Right (-x, -y)
    d = arm_len / np.sqrt(2.0)
    p1 = np.array([d, -d, 0.0])
    p2 = np.array([-d, d, 0.0])
    p3 = np.array([d, d, 0.0])
    p4 = np.array([-d, -d, 0.0])

    # Transform to world frame
    w1 = pos + R @ p1
    w2 = pos + R @ p2
    w3 = pos + R @ p3
    w4 = pos + R @ p4

    return w1, w2, w3, w4


def main():
    parser = argparse.ArgumentParser(description="Animate UAV Fault-Tolerant Flight Simulation")
    parser.add_argument("--scenario", type=str, default="SCENARIO_B_GPS_BIAS",
                        help="Scenario log to animate (e.g. SCENARIO_B_GPS_BIAS, SCENARIO_C_ALTITUDE_FAULT, SCENARIO_F_SOFTWARE_EKF1)")
    parser.add_argument("--speed", type=float, default=2.0, help="Playback speed multiplier")
    args = parser.parse_args()

    csv_path = os.path.join("logs", f"{args.scenario}_fault_tolerant.csv")
    if not os.path.exists(csv_path):
        print(f"Log file not found: {csv_path}. Running simulation first...")
        os.system(f"python scripts/run_single_scenario.py --scenario {args.scenario} --fault-tolerant")

    df = pd.read_csv(csv_path)
    total_steps = len(df)
    step_skip = max(1, int(4 * args.speed))  # Downsample for smooth animation

    # Setup Figure with 3D flight view and live telemetry panels
    fig = plt.figure(figsize=(14, 8))
    fig.canvas.manager.set_window_title(f"3D Flight Animation — {args.scenario}")

    ax_3d = fig.add_subplot(1, 2, 1, projection='3d')
    ax_s = fig.add_subplot(2, 2, 2)
    ax_alt = fig.add_subplot(2, 2, 4)

    # 3D View Limits
    x_min, x_max = min(df["gt_x"].min(), df["ref_x"].min()) - 1.0, max(df["gt_x"].max(), df["ref_x"].max()) + 1.5
    y_min, y_max = min(df["gt_y"].min(), df["ref_y"].min()) - 1.5, max(df["gt_y"].max(), df["ref_y"].max()) + 1.0
    z_max = max(df["gt_z"].max(), df["ref_z"].max()) + 1.0

    ax_3d.set_xlim([x_min, x_max])
    ax_3d.set_ylim([y_min, y_max])
    ax_3d.set_zlim([0, max(4.5, z_max)])
    ax_3d.set_xlabel("X (m)", fontweight='bold')
    ax_3d.set_ylabel("Y (m)", fontweight='bold')
    ax_3d.set_zlabel("Altitude Z (m)", fontweight='bold')
    ax_3d.set_title(f"3D Quadrotor Flight Simulation\n({args.scenario})", fontsize=11, fontweight='bold')

    # Draw Ground Plane and Takeoff Pad
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 5), np.linspace(y_min, y_max, 5))
    ax_3d.plot_surface(xx, yy, np.zeros_like(xx), alpha=0.15, color='gray')
    ax_3d.plot([0], [0], [0], 'yo', markersize=10, label="Takeoff Pad")

    # Reference Trajectory Path
    ax_3d.plot(df["ref_x"], df["ref_y"], df["ref_z"], 'k:', alpha=0.5, label="Planned Path")

    # Animated Trajectory Lines
    line_gt, = ax_3d.plot([], [], [], 'k-', linewidth=2.0, label="True Flight Path")
    line_ekf1, = ax_3d.plot([], [], [], 'r--', linewidth=1.5, alpha=0.7, label="Branch 1 (EKF1 Faulty)")
    line_voter, = ax_3d.plot([], [], [], 'm-', linewidth=2.2, label="Voter Output (Recovered)")

    # Drone Frame Elements
    arm12_line, = ax_3d.plot([], [], [], 'r-', linewidth=3.5)
    arm34_line, = ax_3d.plot([], [], [], 'b-', linewidth=3.5)
    rotors_scatter = ax_3d.scatter([], [], [], s=80, c='black', depthshade=False)
    cg_point, = ax_3d.plot([], [], [], 'ko', markersize=6)

    ax_3d.legend(loc="upper left", fontsize=8)
    ax_3d.view_init(elev=28, azim=-55)

    # 2D Agreement Indicators Plot
    ax_s.set_xlim([0, df["time"].max()])
    ax_s.set_ylim([-0.05, 1.05])
    ax_s.set_ylabel("Agreement Indicator", fontweight='bold')
    ax_s.set_title("Real-Time Voter Agreement & Error Detection", fontsize=10, fontweight='bold')
    ax_s.grid(True, linestyle='--', alpha=0.6)

    line_s12, = ax_s.plot([], [], 'b-', linewidth=1.8, label=r"$s_{12}$ (EKF1 - EKF2)")
    line_s13, = ax_s.plot([], [], 'r-', linewidth=1.4, label=r"$s_{13}$ (EKF1 - Model)")
    line_s23, = ax_s.plot([], [], 'g-', linewidth=1.4, label=r"$s_{23}$ (EKF2 - Model)")
    time_cursor_s = ax_s.axvline(0, color='gray', linestyle=':')
    ax_s.legend(loc="upper right", fontsize=8)

    # 2D Altitude & Status Plot
    ax_alt.set_xlim([0, df["time"].max()])
    ax_alt.set_ylim([0, max(4.0, z_max)])
    ax_alt.set_xlabel("Time (s)", fontweight='bold')
    ax_alt.set_ylabel("Altitude (m)", fontweight='bold')
    ax_alt.set_title("Altitude & Diagnostic Status", fontsize=10, fontweight='bold')
    ax_alt.grid(True, linestyle='--', alpha=0.6)

    line_alt_gt, = ax_alt.plot([], [], 'k-', linewidth=1.8, label="True Altitude")
    line_alt_fused, = ax_alt.plot([], [], 'm--', linewidth=1.8, label="Voter Altitude")
    time_cursor_alt = ax_alt.axvline(0, color='gray', linestyle=':')
    ax_alt.legend(loc="lower right", fontsize=8)

    status_text = fig.text(0.52, 0.02, "System Status: INITIALIZING...", fontsize=11, fontweight='bold',
                           bbox=dict(boxstyle="round,pad=0.4", facecolor="#2ecc71", alpha=0.3))

    frames = list(range(0, total_steps, step_skip))

    def update(frame_idx):
        row = df.iloc[frame_idx]
        t = row["time"]

        # 1. Update Trajectory Trails
        hist_df = df.iloc[:frame_idx+1]
        line_gt.set_data(hist_df["gt_x"], hist_df["gt_y"])
        line_gt.set_3d_properties(hist_df["gt_z"])

        line_ekf1.set_data(hist_df["ekf1_x"], hist_df["ekf1_y"])
        line_ekf1.set_3d_properties(hist_df["ekf1_z"])

        line_voter.set_data(hist_df["fused_x"], hist_df["fused_y"])
        line_voter.set_3d_properties(hist_df["fused_z"])

        # 2. Update Drone 3D Orientation Frame
        pos = np.array([row["gt_x"], row["gt_y"], row["gt_z"]])
        w1, w2, w3, w4 = get_quadrotor_geometry(pos, row["gt_roll"], row["gt_pitch"], row["gt_yaw"])

        arm12_line.set_data([w1[0], w2[0]], [w1[1], w2[1]])
        arm12_line.set_3d_properties([w1[2], w2[2]])

        arm34_line.set_data([w3[0], w4[0]], [w3[1], w4[1]])
        arm34_line.set_3d_properties([w3[2], w4[2]])

        rotors_scatter._offsets3d = ([w1[0], w2[0], w3[0], w4[0]],
                                     [w1[1], w2[1], w3[1], w4[1]],
                                     [w1[2], w2[2], w3[2], w4[2]])
        cg_point.set_data([pos[0]], [pos[1]])
        cg_point.set_3d_properties([pos[2]])

        # 3. Update Agreement Indicators
        line_s12.set_data(hist_df["time"], hist_df["s12_pos"])
        line_s13.set_data(hist_df["time"], hist_df["s13_pos"])
        line_s23.set_data(hist_df["time"], hist_df["s23_pos"])
        time_cursor_s.set_xdata([t, t])

        # 4. Update Altitude
        line_alt_gt.set_data(hist_df["time"], hist_df["gt_z"])
        line_alt_fused.set_data(hist_df["time"], hist_df["fused_z"])
        time_cursor_alt.set_xdata([t, t])

        # 5. Diagnostic Banner
        is_fault = int(row["fault_detected"]) == 1
        is_rec = int(row["recovery_active"]) == 1
        fault_type = str(row["fault_type"])

        if is_rec:
            status_text.set_text(f"Time: {t:05.2f}s | FAULT DETECTED: {fault_type} | RECOVERY ACTIVE (Solution 3)")
            status_text.set_bbox(dict(boxstyle="round,pad=0.4", facecolor="#e74c3c", alpha=0.35))
        elif is_fault:
            status_text.set_text(f"Time: {t:05.2f}s | INCONSISTENCY DETECTED (s12 < 0.05) | ISOLATING...")
            status_text.set_bbox(dict(boxstyle="round,pad=0.4", facecolor="#f39c12", alpha=0.35))
        else:
            status_text.set_text(f"Time: {t:05.2f}s | NOMINAL FLIGHT | All Branches Consistent (s12 = 1.0)")
            status_text.set_bbox(dict(boxstyle="round,pad=0.4", facecolor="#2ecc71", alpha=0.35))

        return line_gt, line_ekf1, line_voter, arm12_line, arm34_line, cg_point, line_s12, line_s13, line_s23, line_alt_gt, line_alt_fused, status_text

    print(f"\nLaunching 3D Flight Animation Player ({args.scenario})...")
    print("Close the animation window when finished.")
    anim = FuncAnimation(fig, update, frames=frames, interval=30, blit=False, repeat=True)
    plt.tight_layout(rect=[0, 0.05, 1, 0.96])
    plt.show()


if __name__ == "__main__":
    main()
