"""Unit tests for Flight Controller."""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.flight_controller import FlightController
from uav_fault_tolerance.quadrotor_dynamics import QuadrotorParameters, pwm_to_motor_thrust


def test_hover_pwm_equilibrium():
    params = QuadrotorParameters(mass=1.7, gravity=9.81)
    controller = FlightController(params)

    # Hover equilibrium state
    state = {
        "pos": np.array([0.0, 0.0, 3.0]),
        "vel": np.zeros(3),
        "euler": np.zeros(3),
        "omega": np.zeros(3)
    }

    pos_target = np.array([0.0, 0.0, 3.0])
    vel_target = np.zeros(3)

    pwms, uf, moments = controller.compute_control(state, pos_target, vel_target, 0.0, dt=0.01)

    # Total thrust should be near m * g = 1.7 * 9.81 = 16.677 N
    assert np.isclose(uf, 16.677, atol=0.5)

    # Moments should be zero at equilibrium
    assert np.allclose(moments, np.zeros(3), atol=1e-3)

    # Motor PWMs should be symmetric and in reasonable flight range [1600, 1800]
    assert np.allclose(pwms, pwms[0], atol=1e-2)
    assert 1600.0 <= pwms[0] <= 1800.0


if __name__ == "__main__":
    test_hover_pwm_equilibrium()
    print("All Flight Controller tests passed successfully!")
