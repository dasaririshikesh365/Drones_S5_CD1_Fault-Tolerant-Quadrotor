"""Unit tests for Fault Detection and Identification (Algorithm 1)."""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.fault_detector_identifier import (
    FaultDetectorIdentifier,
    FaultCategory,
    ResidualThresholds
)
from uav_fault_tolerance.weighted_voter import WeightedAverageVoter


def test_fdi_healthy():
    fdi = FaultDetectorIdentifier()
    voter = WeightedAverageVoter()
    b_healthy = {
        "pos": np.array([0.0, 0.0, 3.0]),
        "vel": np.zeros(3),
        "quaternion": np.array([1.0, 0.0, 0.0, 0.0]),
        "euler": np.zeros(3)
    }
    v_res = voter.vote_states([b_healthy, b_healthy, b_healthy])
    sens = {
        "branch1": {"acc": np.zeros(3), "gyro": np.zeros(3), "gps_pos": np.zeros(2), "lidar": 3.0, "mag": 0.0},
        "branch2": {"acc": np.zeros(3), "gyro": np.zeros(3), "gps_pos": np.zeros(2), "lidar": 3.0, "mag": 0.0}
    }
    diag = fdi.evaluate(1.0, v_res["info"], sens)
    assert not diag.is_fault_detected
    assert diag.fault_type == FaultCategory.NONE


def test_fdi_hardware_gps_fault():
    fdi = FaultDetectorIdentifier()
    voter = WeightedAverageVoter()
    # Branch 1 (KF1) biased by +5m due to GPS1 fault
    b1 = {"pos": np.array([5.0, 5.0, 3.0]), "vel": np.zeros(3), "quaternion": np.array([1.0, 0.0, 0.0, 0.0]), "euler": np.zeros(3)}
    b2 = {"pos": np.array([0.0, 0.0, 3.0]), "vel": np.zeros(3), "quaternion": np.array([1.0, 0.0, 0.0, 0.0]), "euler": np.zeros(3)}
    b3 = {"pos": np.array([0.05, 0.02, 3.0]), "vel": np.zeros(3), "quaternion": np.array([1.0, 0.0, 0.0, 0.0]), "euler": np.zeros(3)}

    v_res = voter.vote_states([b1, b2, b3])
    # Sensor residuals show GPS1 deviates from GPS2 by > 2m
    sens = {
        "branch1": {"acc": np.zeros(3), "gyro": np.zeros(3), "gps_pos": np.array([5.0, 5.0]), "lidar": 3.0, "mag": 0.0},
        "branch2": {"acc": np.zeros(3), "gyro": np.zeros(3), "gps_pos": np.zeros(2), "lidar": 3.0, "mag": 0.0}
    }
    diag = fdi.evaluate(7.5, v_res["info"], sens)
    assert diag.is_fault_detected
    assert diag.faulty_branch_id == 1
    assert diag.fault_type == FaultCategory.HARDWARE_SB2_GPS


def test_fdi_software_ekf1_fault():
    fdi = FaultDetectorIdentifier()
    voter = WeightedAverageVoter()
    # EKF1 deviates due to internal covariance bug, but raw sensors agree
    b1 = {"pos": np.array([0.0, 0.0, 4.5]), "vel": np.zeros(3), "quaternion": np.array([1.0, 0.0, 0.0, 0.0]), "euler": np.zeros(3)}
    b2 = {"pos": np.array([0.0, 0.0, 3.0]), "vel": np.zeros(3), "quaternion": np.array([1.0, 0.0, 0.0, 0.0]), "euler": np.zeros(3)}
    b3 = {"pos": np.array([0.0, 0.0, 3.02]), "vel": np.zeros(3), "quaternion": np.array([1.0, 0.0, 0.0, 0.0]), "euler": np.zeros(3)}

    v_res = voter.vote_states([b1, b2, b3])
    # Both raw sensor sets agree!
    sens = {
        "branch1": {"acc": np.zeros(3), "gyro": np.zeros(3), "gps_pos": np.zeros(2), "lidar": 3.0, "mag": 0.0},
        "branch2": {"acc": np.zeros(3), "gyro": np.zeros(3), "gps_pos": np.zeros(2), "lidar": 3.01, "mag": 0.0}
    }
    diag = fdi.evaluate(19.0, v_res["info"], sens)
    assert diag.is_fault_detected
    assert diag.faulty_branch_id == 1
    assert diag.fault_type == FaultCategory.SOFTWARE_KF1


if __name__ == "__main__":
    test_fdi_healthy()
    test_fdi_hardware_gps_fault()
    test_fdi_software_ekf1_fault()
    print("All FDI Logic tests passed successfully!")
