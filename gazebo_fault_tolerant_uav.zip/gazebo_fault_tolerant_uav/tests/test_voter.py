"""Unit tests for weighted-average voter module."""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.weighted_voter import WeightedAverageVoter, compute_soft_agreement


def test_soft_agreement_function():
    a = 0.5
    n = 6.0  # na = 3.0
    # Region 1: d <= a -> s = 1.0
    assert compute_soft_agreement(0.2, a, n) == 1.0
    assert compute_soft_agreement(0.5, a, n) == 1.0

    # Region 2: a < d < na -> linear transition (n/(n-1))*(1 - d/(na))
    s_mid = compute_soft_agreement(1.75, a, n)
    assert 0.0 < s_mid < 1.0

    # Region 3: d >= na -> s = 0.0
    assert compute_soft_agreement(3.0, a, n) == 0.0
    assert compute_soft_agreement(5.0, a, n) == 0.0


def test_voter_all_agree():
    voter = WeightedAverageVoter()
    # 3 branches agreeing closely: 10.0, 10.05, 9.95
    fused, weights, S = voter.vote_scalar([10.0, 10.05, 9.95], a=0.5, n=6.0)
    assert np.isclose(fused, 10.0, atol=0.05)
    # Weights should be almost equal ~ 1.0
    for w in weights:
        assert np.isclose(w, 1.0, atol=0.01)


def test_voter_one_branch_faulty():
    voter = WeightedAverageVoter()
    # Branch 1 faulty (+5m bias): 15.0 vs Branch 2: 10.0, Branch 3: 10.1
    fused, weights, S = voter.vote_scalar([15.0, 10.0, 10.1], a=0.5, n=6.0)
    # d12 = 5.0 > na(3.0) -> s12 = 0
    # d13 = 4.9 > na(3.0) -> s13 = 0
    # d23 = 0.1 <= a(0.5) -> s23 = 1.0
    assert S[0, 1] == 0.0
    assert S[0, 2] == 0.0
    assert S[1, 2] == 1.0

    # Weights: w1 = (s12 + s13)/2 = 0.0
    # w2 = (s12 + s23)/2 = 0.5
    # w3 = (s13 + s23)/2 = 0.5
    assert np.isclose(weights[0], 0.0, atol=1e-5)
    assert np.isclose(weights[1], 0.5, atol=1e-5)
    assert np.isclose(weights[2], 0.5, atol=1e-5)

    # Fused output must be strictly formed by the healthy branches (10.05)
    assert np.isclose(fused, 10.05, atol=0.01)


def test_voter_state_fusion():
    voter = WeightedAverageVoter()
    b1 = {
        "pos": np.array([5.0, 0.0, 3.0]),      # Deviating in X (+5m)
        "vel": np.array([0.0, 0.0, 0.0]),
        "quaternion": np.array([1.0, 0.0, 0.0, 0.0]),
        "euler": np.array([0.0, 0.0, 0.0])
    }
    b2 = {
        "pos": np.array([0.0, 0.0, 3.0]),      # Healthy
        "vel": np.array([0.0, 0.0, 0.0]),
        "quaternion": np.array([1.0, 0.0, 0.0, 0.0]),
        "euler": np.array([0.0, 0.0, 0.0])
    }
    b3 = {
        "pos": np.array([0.1, 0.0, 3.0]),      # DM Healthy
        "vel": np.array([0.0, 0.0, 0.0]),
        "quaternion": np.array([1.0, 0.0, 0.0, 0.0]),
        "euler": np.array([0.0, 0.0, 0.0])
    }

    res = voter.vote_states([b1, b2, b3])
    fused_pos = res["state"]["pos"]
    # Fused X position must be around 0.05 m, completely rejecting b1's 5.0 m!
    assert np.isclose(fused_pos[0], 0.05, atol=0.1)
    assert np.isclose(fused_pos[2], 3.0, atol=0.01)


if __name__ == "__main__":
    test_soft_agreement_function()
    test_voter_all_agree()
    test_voter_one_branch_faulty()
    test_voter_state_fusion()
    print("All Weighted Voter tests passed successfully!")
