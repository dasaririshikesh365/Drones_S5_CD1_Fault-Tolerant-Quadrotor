"""Unit tests for quaternion math module."""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.quaternion_math import (
    quaternion_normalize,
    quaternion_multiply,
    quaternion_to_rotation_matrix,
    euler_to_quaternion,
    quaternion_to_euler,
    quaternion_angular_distance,
    quaternion_propagate
)


def test_quaternion_normalization():
    q = np.array([2.0, 0.0, 0.0, 0.0])
    q_norm = quaternion_normalize(q)
    assert np.isclose(np.linalg.norm(q_norm), 1.0)
    assert np.allclose(q_norm, [1.0, 0.0, 0.0, 0.0])


def test_rotation_matrix_properties():
    q = euler_to_quaternion(0.2, -0.3, 0.5)
    R = quaternion_to_rotation_matrix(q)
    # Check orthogonality R * R^T = I
    assert np.allclose(R @ R.T, np.eye(3), atol=1e-6)
    # Check determinant = +1 (proper rotation)
    assert np.isclose(np.linalg.det(R), 1.0, atol=1e-6)


def test_euler_quaternion_roundtrip():
    roll_in, pitch_in, yaw_in = 0.15, -0.25, 1.2
    q = euler_to_quaternion(roll_in, pitch_in, yaw_in)
    roll_out, pitch_out, yaw_out = quaternion_to_euler(q)
    assert np.isclose(roll_in, roll_out, atol=1e-5)
    assert np.isclose(pitch_in, pitch_out, atol=1e-5)
    assert np.isclose(yaw_in, yaw_out, atol=1e-5)


def test_antipodal_symmetry():
    q = euler_to_quaternion(0.1, 0.2, 0.3)
    q_neg = -q
    # Geodesic distance must be 0 for antipodal representation of the same rotation
    dist = quaternion_angular_distance(q, q_neg)
    assert np.isclose(dist, 0.0, atol=1e-6)


def test_quaternion_propagation():
    q0 = np.array([1.0, 0.0, 0.0, 0.0])
    omega = np.array([0.0, 0.0, 1.0])  # 1 rad/s yaw
    dt = 0.1
    q1 = quaternion_propagate(q0, omega, dt)
    roll, pitch, yaw = quaternion_to_euler(q1)
    assert np.isclose(yaw, 0.1, atol=1e-3)
    assert np.isclose(roll, 0.0, atol=1e-5)
    assert np.isclose(pitch, 0.0, atol=1e-5)


if __name__ == "__main__":
    test_quaternion_normalization()
    test_rotation_matrix_properties()
    test_euler_quaternion_roundtrip()
    test_antipodal_symmetry()
    test_quaternion_propagation()
    print("All Quaternion Math tests passed successfully!")
