"""Unit tests for Extended Kalman Filter."""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from uav_fault_tolerance.ekf_estimator import UAVExtendedKalmanFilter, EKFConfig
from uav_fault_tolerance.quaternion_math import euler_to_quaternion


def test_ekf_prediction_and_update():
    ekf = UAVExtendedKalmanFilter(initial_pos=np.array([0.0, 0.0, 0.0]))
    dt = 0.01

    # Simulate hovering with specific force [0, 0, 9.81] (balancing gravity)
    acc = np.array([0.0, 0.0, 9.81])
    gyro = np.array([0.0, 0.0, 0.0])

    for _ in range(100):
        ekf.predict(acc, gyro, dt)

    # Position should remain close to 0
    state = ekf.get_state()
    assert np.allclose(state["pos"], [0.0, 0.0, 0.0], atol=0.01)

    # Now update with GPS at (2.0, 3.0) and Lidar at 3.0m
    for _ in range(60):
        ekf.predict(acc, gyro, dt)
        ekf.update(
            gps_pos=np.array([2.0, 3.0]),
            gps_vel=np.array([0.0, 0.0]),
            lidar_z=3.0,
            mag_yaw=0.0
        )

    state = ekf.get_state()
    assert np.isclose(state["pos"][0], 2.0, atol=0.1)
    assert np.isclose(state["pos"][1], 3.0, atol=0.1)
    assert np.isclose(state["pos"][2], 3.0, atol=0.1)


def test_ekf_software_fault_injection():
    ekf = UAVExtendedKalmanFilter()
    assert ekf.P[2, 2] > 0.0
    # Inject software fault forcing negative covariance
    ekf.inject_software_fault_covariance(axis="z", value=-0.1)
    assert ekf.P[2, 2] == -0.1
    assert ekf.software_fault_active


if __name__ == "__main__":
    test_ekf_prediction_and_update()
    test_ekf_software_fault_injection()
    print("All EKF tests passed successfully!")
