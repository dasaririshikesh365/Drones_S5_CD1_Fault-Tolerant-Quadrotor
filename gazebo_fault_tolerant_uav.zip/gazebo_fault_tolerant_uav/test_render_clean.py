import matplotlib
import matplotlib.pyplot as plt

plt.rcParams['mathtext.fontset'] = 'cm'
plt.rcParams['font.family'] = 'serif'

fig, ax = plt.subplots(figsize=(8, 1.5), dpi=300)
fig.patch.set_alpha(0.0)
ax.patch.set_alpha(0.0)
ax.axis('off')

eq = r"$s_{ij} = \frac{1}{1 + \left(\frac{d_{ij}}{a}\right)^n}, \quad w_i = \frac{\sum_{j \neq i} s_{ij}}{\sum_{k} \sum_{j \neq k} s_{kj}}, \quad \mathbf{y}_v = \sum_{i=1}^m w_i \mathbf{y}_i$"
ax.text(0.5, 0.5, eq, fontsize=20, color='#38bdf8', ha='center', va='center')

plt.savefig('test_eq_clean.png', transparent=True, bbox_inches='tight', pad_inches=0.08)
print("SUCCESSFULLY SAVED test_eq_clean.png")
