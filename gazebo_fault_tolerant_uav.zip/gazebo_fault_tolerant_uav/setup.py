from setuptools import setup, find_packages
import os
from glob import glob

package_name = 'uav_fault_tolerance'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(include=[package_name, f'{package_name}.*']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name] if os.path.exists('resource/' + package_name) else []),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'gazebo', 'worlds'), glob('gazebo/worlds/*.sdf')),
        (os.path.join('share', package_name, 'gazebo', 'models', 'tarot650_redundant'), glob('gazebo/models/tarot650_redundant/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Simulation Engineer',
    maintainer_email='researcher@uav.org',
    description='Fault Tolerant UAV Data Fusion System in Gazebo',
    license='BSD-3-Clause',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'sensor_bridge_node = uav_fault_tolerance.nodes.sensor_bridge_node:main',
            'ekf_node = uav_fault_tolerance.nodes.ekf_node:main',
            'dynamic_model_node = uav_fault_tolerance.nodes.dynamic_model_node:main',
            'voter_node = uav_fault_tolerance.nodes.voter_node:main',
            'diagnostics_recovery_node = uav_fault_tolerance.nodes.diagnostics_recovery_node:main',
            'flight_control_node = uav_fault_tolerance.nodes.flight_control_node:main',
            'logger_node = uav_fault_tolerance.nodes.logger_node:main',
            'manual_teleop_node = uav_fault_tolerance.nodes.manual_teleop_node:main',
        ],
    },
)
