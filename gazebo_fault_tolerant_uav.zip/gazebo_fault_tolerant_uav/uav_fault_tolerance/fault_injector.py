"""
Fault Injection Framework Module.
Supports configurable fault injection scenarios A through I as specified in the project requirements
and matching the experimental validation from Hamadi et al. (2022), Section 6.
"""

from dataclasses import dataclass
from enum import Enum
import numpy as np


class ScenarioType(Enum):
    SCENARIO_A_HEALTHY = "SCENARIO_A_HEALTHY"
    SCENARIO_B_GPS_BIAS = "SCENARIO_B_GPS_BIAS"
    SCENARIO_C_ALTITUDE_FAULT = "SCENARIO_C_ALTITUDE_FAULT"
    SCENARIO_D_IMU_FREEZE = "SCENARIO_D_IMU_FREEZE"
    SCENARIO_E_IMU_NOISE_DRIFT = "SCENARIO_E_IMU_NOISE_DRIFT"
    SCENARIO_F_SOFTWARE_EKF1 = "SCENARIO_F_SOFTWARE_EKF1"
    SCENARIO_G_SOFTWARE_EKF2 = "SCENARIO_G_SOFTWARE_EKF2"
    SCENARIO_H_RECOVERY_TEST = "SCENARIO_H_RECOVERY_TEST"
    SCENARIO_I_SEQUENTIAL_FAULTS = "SCENARIO_I_SEQUENTIAL_FAULTS"


@dataclass
class FaultProfile:
    scenario: ScenarioType
    t_start: float = 7.0
    t_end: float = 16.0
    magnitude: float = 5.0
    target_branch: int = 1         # 1 for Branch 1 (SB1/SB2/KF1), 2 for Branch 2 (SB3/SB4/KF2)
    secondary_t_start: float = 22.0 # For sequential faults (Scenario I)
    secondary_t_end: float = 32.0


class FaultInjector:
    """
    Applies configurable faults to simulated sensor streams and software estimator instances.
    """
    def __init__(self, profile: FaultProfile):
        self.profile = profile
        self.frozen_acc: np.ndarray | None = None
        self.frozen_gyro: np.ndarray | None = None

    def apply_sensor_faults(self, t: float, sensor_data: dict[str, dict[str, any]]) -> dict[str, dict[str, any]]:
        """
        Inject hardware sensor faults according to the scenario profile.
        """
        # Deep copy to avoid mutating underlying structures
        b1 = {k: np.copy(v) if isinstance(v, np.ndarray) else v for k, v in sensor_data["branch1"].items()}
        b2 = {k: np.copy(v) if isinstance(v, np.ndarray) else v for k, v in sensor_data["branch2"].items()}

        active_primary = (self.profile.t_start <= t <= self.profile.t_end)
        active_secondary = (self.profile.secondary_t_start <= t <= self.profile.secondary_t_end)

        scen = self.profile.scenario

        # Scenario B: GPS Position Bias (Paper Section 6.2, Eq. 27: +5m jump in x and y on GPS1)
        if scen in (ScenarioType.SCENARIO_B_GPS_BIAS, ScenarioType.SCENARIO_H_RECOVERY_TEST) and active_primary:
            if self.profile.target_branch == 1:
                b1["gps_pos"] = b1["gps_pos"] + np.array([self.profile.magnitude, self.profile.magnitude])
            else:
                b2["gps_pos"] = b2["gps_pos"] + np.array([self.profile.magnitude, self.profile.magnitude])

        # Scenario C: Altitude Sensor Fault (Paper Section 6.3: -1m on Lidar1 during hover)
        elif scen == ScenarioType.SCENARIO_C_ALTITUDE_FAULT and active_primary:
            if self.profile.target_branch == 1:
                b1["lidar"] = b1["lidar"] - abs(self.profile.magnitude if self.profile.magnitude != 5.0 else 1.0)
            else:
                b2["lidar"] = b2["lidar"] - abs(self.profile.magnitude if self.profile.magnitude != 5.0 else 1.0)

        # Scenario D: IMU Freeze
        elif scen == ScenarioType.SCENARIO_D_IMU_FREEZE and active_primary:
            if self.frozen_acc is None:
                self.frozen_acc = b1["acc"].copy() if self.profile.target_branch == 1 else b2["acc"].copy()
                self.frozen_gyro = b1["gyro"].copy() if self.profile.target_branch == 1 else b2["gyro"].copy()

            if self.profile.target_branch == 1:
                b1["acc"] = self.frozen_acc.copy()
                b1["gyro"] = self.frozen_gyro.copy()
            else:
                b2["acc"] = self.frozen_acc.copy()
                b2["gyro"] = self.frozen_gyro.copy()
        elif scen == ScenarioType.SCENARIO_D_IMU_FREEZE and not active_primary:
            self.frozen_acc = None
            self.frozen_gyro = None

        # Scenario E: IMU Noise or Drift
        elif scen == ScenarioType.SCENARIO_E_IMU_NOISE_DRIFT and active_primary:
            dt_fault = t - self.profile.t_start
            drift = np.array([0.05 * dt_fault, 0.05 * dt_fault, 0.0])
            noise_burst = np.random.normal(0.0, 0.2, 3)
            if self.profile.target_branch == 1:
                b1["acc"] = b1["acc"] + drift + noise_burst
            else:
                b2["acc"] = b2["acc"] + drift + noise_burst

        # Scenario I: Sequential Faults (Fault 1: GPS bias, then Fault 2: Lidar fault)
        elif scen == ScenarioType.SCENARIO_I_SEQUENTIAL_FAULTS:
            if active_primary:
                # Primary fault: GPS1 bias
                b1["gps_pos"] = b1["gps_pos"] + np.array([3.0, 3.0])
            if active_secondary:
                # Secondary fault: Lidar2 altitude fault (-1.5m)
                b2["lidar"] = b2["lidar"] - 1.5

        return {
            "branch1": b1,
            "branch2": b2,
            "ground_truth": sensor_data["ground_truth"]
        }

    def apply_software_faults(self, t: float, ekf1, ekf2) -> None:
        """
        Inject software faults into EKF instances (Paper Section 6.4, 6.5).
        """
        active_primary = (self.profile.t_start <= t <= self.profile.t_end)
        scen = self.profile.scenario

        if scen == ScenarioType.SCENARIO_F_SOFTWARE_EKF1 and active_primary:
            # Force negative altitude covariance Pz = -0.1 as in paper Section 6.4
            ekf1.inject_software_fault_covariance(axis="z", value=-0.1)
            # Add small divergence drift over time
            ekf1.inject_software_bias(np.array([0.0, 0.0, -0.05]))

        elif scen == ScenarioType.SCENARIO_G_SOFTWARE_EKF2 and active_primary:
            # Force negative covariance in EKF2
            ekf2.inject_software_fault_covariance(axis="z", value=-0.1)
            ekf2.inject_software_bias(np.array([0.0, 0.0, -0.05]))
