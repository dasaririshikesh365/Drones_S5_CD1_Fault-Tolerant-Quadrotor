"""
Quadrotor Dynamics and Actuator Identification Module.
Implements the 6-DOF nonlinear equations of motion and empirical motor polynomials
from Hamadi et al., ISA Transactions (2022), Section 3 & Section 6.
"""

from dataclasses import dataclass
import numpy as np
from .quaternion_math import (
    quaternion_normalize,
    quaternion_to_rotation_matrix,
    quaternion_to_euler,
    quaternion_propagate,
    euler_to_quaternion
)


@dataclass
class QuadrotorParameters:
    """Tarot 650 physical parameters from Table 1 of the paper."""
    mass: float = 1.7             # Mass of the vehicle in kg
    arm_length: float = 0.23      # Distance from center to motor in meters
    Ixx: float = 3.38e-2          # Moment of inertia about x-axis in kg*m^2
    Iyy: float = 3.38e-2          # Moment of inertia about y-axis in kg*m^2
    Izz: float = 2.25e-2          # Moment of inertia about z-axis in kg*m^2
    gravity: float = 9.81         # Acceleration due to gravity in m/s^2
    drag_linear: float = 0.1      # Aerodynamic translational drag coefficient
    drag_angular: float = 0.05    # Aerodynamic rotational drag coefficient


def pwm_to_motor_thrust(u_pwm: float | np.ndarray) -> float | np.ndarray:
    """
    Empirical thrust force generated per motor as a function of PWM input.
    Paper Equation (9) and (25):
    fi = (-1.4736*u^3 + 11.0691*u^2 - 16.7074*u + 7.3007) / 100 [N]
    where u is in thousands (i.e. u_pwm / 1000 in [1.0, 2.0]).
    """
    u = np.asarray(u_pwm) / 1000.0
    u_clamped = np.clip(u, 1.0, 2.0)
    force = (-1.4736 * (u_clamped**3) +
             11.0691 * (u_clamped**2) -
             16.7074 * u_clamped +
             7.3007)
    # In hovering mode (PWM ~ 1600-1750), force per motor is approx 3.0-4.5 N
    return np.maximum(force, 0.0)


def pwm_to_motor_torque(u_pwm: float | np.ndarray) -> float | np.ndarray:
    """
    Empirical reaction torque generated per motor as a function of PWM input.
    Paper Equation (10) and (26):
    tau_i = (-0.0905*u^3 + 0.4771*u^2 - 0.679*u + 0.3045) [N*m]
    where u is in thousands (u_pwm / 1000).
    """
    u = np.asarray(u_pwm) / 1000.0
    u_clamped = np.clip(u, 1.0, 2.0)
    torque = (-0.0905 * (u_clamped**3) +
              0.4771 * (u_clamped**2) -
              0.6790 * u_clamped +
              0.3045)
    return np.maximum(torque, 0.0)


def compute_virtual_inputs(f_motors: np.ndarray, tau_motors: np.ndarray, arm_length: float) -> tuple[float, np.ndarray]:
    """
    Compute total thrust uf and moments [tau_phi, tau_theta, tau_psi] from individual motor forces and torques.
    Paper Equation (7):
    uf = F1 + F2 + F3 + F4
    tau_phi = d * (F1 + F4 - F2 - F3)
    tau_theta = d * (F1 + F2 - F3 - F4)  # standard quad-x / plus geometry
    tau_psi = (tau2 + tau4) - (tau1 + tau3)
    """
    f1, f2, f3, f4 = f_motors
    t1, t2, t3, t4 = tau_motors
    d = arm_length

    # Total vertical thrust in body frame
    uf = float(f1 + f2 + f3 + f4)

    # Moments (roll, pitch, yaw)
    # Motors 1 and 4 on one side, 2 and 3 on the other side
    tau_phi = float(d * (f1 + f4 - f2 - f3) / np.sqrt(2.0))
    tau_theta = float(d * (f1 + f2 - f3 - f4) / np.sqrt(2.0))
    tau_psi = float((t2 + t4) - (t1 + t3))

    moments = np.array([tau_phi, tau_theta, tau_psi], dtype=float)
    return uf, moments


class QuadrotorDynamics:
    """
    Full 6-DOF nonlinear simulation of quadrotor dynamics.
    Integrates Newton-Euler equations of motion.
    """
    def __init__(self, params: QuadrotorParameters | None = None, initial_pos: np.ndarray | None = None):
        self.params = params if params is not None else QuadrotorParameters()
        
        # Position in Earth frame [x, y, z] (m)
        self.position = np.array(initial_pos if initial_pos is not None else [0.0, 0.0, 0.0], dtype=float)
        # Linear velocity in Earth frame [vx, vy, vz] (m/s)
        self.velocity = np.zeros(3, dtype=float)
        # Orientation quaternion [qw, qx, qy, qz]
        self.quaternion = np.array([1.0, 0.0, 0.0, 0.0], dtype=float)
        # Body angular velocity [p, q, r] (rad/s)
        self.angular_velocity = np.zeros(3, dtype=float)
        # Linear acceleration in Earth frame [ax, ay, az] (m/s^2)
        self.acceleration = np.zeros(3, dtype=float)

        self.inertia_diag = np.array([self.params.Ixx, self.params.Iyy, self.params.Izz], dtype=float)
        self.inv_inertia_diag = 1.0 / self.inertia_diag

    def step(self, pwm_inputs: np.ndarray, dt: float, wind_force: np.ndarray | None = None) -> None:
        """
        Advance dynamics by time step dt under given PWM inputs.
        pwm_inputs: 4-element array in range [1000, 2000].
        """
        if wind_force is None:
            wind_force = np.zeros(3, dtype=float)

        # 1. Compute actuator forces and torques from identified polynomials
        f_motors = pwm_to_motor_thrust(pwm_inputs)
        tau_motors = pwm_to_motor_torque(pwm_inputs)
        uf, moments = compute_virtual_inputs(f_motors, tau_motors, self.params.arm_length)

        # 2. Translational dynamics in Earth frame
        # mv_dot = R_B_to_E * [0, 0, uf]^T + F_w - [0, 0, m*g]^T
        R_B_to_E = quaternion_to_rotation_matrix(self.quaternion)
        thrust_body = np.array([0.0, 0.0, uf], dtype=float)
        thrust_earth = R_B_to_E @ thrust_body

        drag_force = -self.params.drag_linear * self.velocity
        gravity_force = np.array([0.0, 0.0, -self.params.mass * self.params.gravity], dtype=float)

        total_force_earth = thrust_earth + gravity_force + wind_force + drag_force
        self.acceleration = total_force_earth / self.params.mass

        # Ground contact model (drone cannot penetrate ground plane z=0)
        if self.position[2] <= 0.0 and self.acceleration[2] < 0.0:
            self.acceleration[2] = 0.0
            self.velocity[2] = max(0.0, self.velocity[2])
            self.position[2] = 0.0

        # RK4 or Euler integration for translational states
        self.velocity += self.acceleration * dt
        self.position += self.velocity * dt

        if self.position[2] < 0.0:
            self.position[2] = 0.0
            self.velocity[2] = 0.0

        # 3. Rotational dynamics (Euler equation: I*w_dot = -w x (I*w) + tau - drag)
        w = self.angular_velocity
        Iw = self.inertia_diag * w
        gyroscopic = -np.cross(w, Iw)
        rotational_drag = -self.params.drag_angular * w
        total_torque = moments + gyroscopic + rotational_drag
        w_dot = self.inv_inertia_diag * total_torque

        self.angular_velocity += w_dot * dt
        self.quaternion = quaternion_propagate(self.quaternion, self.angular_velocity, dt)

    def get_euler_angles(self) -> tuple[float, float, float]:
        """Return (roll, pitch, yaw) in radians."""
        return quaternion_to_euler(self.quaternion)

    def get_specific_force_body(self) -> np.ndarray:
        """
        Compute true specific force measured by an accelerometer in body frame:
        a_meas_body = R_E_to_B * (a_inertial + [0, 0, g]^T)
        """
        R_B_to_E = quaternion_to_rotation_matrix(self.quaternion)
        R_E_to_B = R_B_to_E.T
        acc_with_gravity = self.acceleration + np.array([0.0, 0.0, self.params.gravity])
        return R_E_to_B @ acc_with_gravity
