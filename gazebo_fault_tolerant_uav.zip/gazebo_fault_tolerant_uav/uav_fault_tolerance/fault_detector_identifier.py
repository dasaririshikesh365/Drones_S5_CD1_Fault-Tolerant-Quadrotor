"""
Fault Detection and Identification (FDI) Module.
Implements Algorithm 1 and Residual Generator from Hamadi et al. (2022), Section 5.3 & Table 3.
Distinguishes between Hardware Sensor Faults (SB1..SB4) and Software Estimator Faults (KF1, KF2, DM).
"""

from dataclasses import dataclass
from enum import Enum
import numpy as np


class FaultCategory(Enum):
    NONE = "NONE"
    HARDWARE_SB1_IMU = "HARDWARE_SB1_IMU"
    HARDWARE_SB2_GPS = "HARDWARE_SB2_GPS"
    HARDWARE_SB2_LIDAR = "HARDWARE_SB2_LIDAR"
    HARDWARE_SB2_MAG = "HARDWARE_SB2_MAG"
    HARDWARE_SB3_IMU = "HARDWARE_SB3_IMU"
    HARDWARE_SB4_GPS = "HARDWARE_SB4_GPS"
    HARDWARE_SB4_LIDAR = "HARDWARE_SB4_LIDAR"
    HARDWARE_SB4_MAG = "HARDWARE_SB4_MAG"
    SOFTWARE_KF1 = "SOFTWARE_KF1"
    SOFTWARE_KF2 = "SOFTWARE_KF2"
    MODEL_DIVERGENCE_DM = "MODEL_DIVERGENCE_DM"


@dataclass
class ResidualThresholds:
    """Residual Generator thresholds from Table 3 of the paper."""
    th_gps_dist: float = 2.0         # GPS distance threshold (m)
    th_lidar_z: float = 1.0          # Lidar altitude threshold (m)
    th_mag_yaw: float = np.radians(6.0) # Magnetometer heading (rad) ~ 6 deg
    th_imu_acc: float = 0.01         # Accelerometer residual threshold (m/s^2)
    th_imu_gyro: float = np.radians(0.1) # Gyroscope residual threshold (rad/s) ~ 0.1 deg/s
    epsilon: float = 0.1             # Agreement difference threshold eps for branch isolation


@dataclass
class DiagnosticResult:
    is_fault_detected: bool
    fault_type: FaultCategory
    faulty_branch_id: int | None     # 1 for KF1/B1, 2 for KF2/B2, 3 for DM
    detection_timestamp: float | None
    residuals: dict[str, float]
    agreement_indicators: dict[str, float]
    detail: str


class FaultDetectorIdentifier:
    """
    Fault Detection and Identification Engine implementing Algorithm 1.
    """
    def __init__(self, thresholds: ResidualThresholds | None = None):
        self.th = thresholds if thresholds is not None else ResidualThresholds()
        self.active_fault: FaultCategory = FaultCategory.NONE
        self.faulty_branch: int | None = None
        self.first_detection_time: float | None = None
        self.isolation_confirmed: bool = False

    def evaluate(self, current_time: float,
                 voter_info: dict[str, any],
                 sensor_data: dict[str, dict[str, any]]) -> DiagnosticResult:
        """
        Execute Algorithm 1: Fault detection and identification.
        voter_info: output from WeightedAverageVoter.vote_states
        sensor_data: dict with 'branch1' (SB1/SB2) and 'branch2' (SB3/SB4)
        """
        # 1. Extract pairwise agreement indicators
        # In voter_info, branches are 0: KF1, 1: KF2, 2: DM (if 3 branches active)
        S_xy = voter_info.get("S_xy")
        S_z = voter_info.get("S_z")

        # Composite agreement for detection (position + altitude)
        s12_pos = S_xy[0, 1] if S_xy.shape[0] >= 2 else 1.0
        s13_pos = S_xy[0, 2] if S_xy.shape[0] >= 3 else 1.0
        s23_pos = S_xy[1, 2] if S_xy.shape[0] >= 3 else 1.0

        s12_z = S_z[0, 1] if S_z.shape[0] >= 2 else 1.0
        s13_z = S_z[0, 2] if S_z.shape[0] >= 3 else 1.0
        s23_z = S_z[1, 2] if S_z.shape[0] >= 3 else 1.0

        # Overall indicators
        s12 = min(s12_pos, s12_z)
        s13 = min(s13_pos, s13_z)
        s23 = min(s23_pos, s23_z)

        # 2. Compute redundant sensor residuals (Residuals Generator block, Table 3)
        b1 = sensor_data["branch1"]
        b2 = sensor_data["branch2"]

        # Accelerometer and Gyro residuals (SB1 vs SB3)
        res_acc = float(np.linalg.norm(b1["acc"][:2] - b2["acc"][:2]))
        res_gyro = float(np.linalg.norm(b1["gyro"][:2] - b2["gyro"][:2]))

        # GPS horizontal position distance residual (SB2 vs SB4)
        res_gps = float(np.linalg.norm(b1["gps_pos"] - b2["gps_pos"]))

        # Lidar altitude residual (SB2 vs SB4)
        res_lidar = float(abs(b1["lidar"] - b2["lidar"]))

        # Magnetometer heading residual (SB2 vs SB4)
        res_mag = float(abs((b1["mag"] - b2["mag"] + np.pi) % (2.0 * np.pi) - np.pi))

        residuals = {
            "res_acc": res_acc,
            "res_gyro": res_gyro,
            "res_gps": res_gps,
            "res_lidar": res_lidar,
            "res_mag": res_mag
        }

        indicators = {
            "s12": s12,
            "s13": s13,
            "s23": s23,
            "s12_pos": s12_pos,
            "s13_pos": s13_pos,
            "s23_pos": s23_pos,
            "s12_z": s12_z,
            "s13_z": s13_z,
            "s23_z": s23_z
        }

        # 3. Check for Analytical Model Divergence (Paper Section 5.3):
        # "In case where indicators s13 and s23 go to zero with s12 = 1, this implies error in DM"
        if s12 > 0.8 and s13 < 0.2 and s23 < 0.2:
            return DiagnosticResult(
                is_fault_detected=True,
                fault_type=FaultCategory.MODEL_DIVERGENCE_DM,
                faulty_branch_id=3,
                detection_timestamp=current_time,
                residuals=residuals,
                agreement_indicators=indicators,
                detail="Analytical Dynamic Model (Branch 3) diverged while KF1 and KF2 agree"
            )

        # 4. Check for Primary System Inconsistency (s12 == 0)
        # In numerical simulation, we consider s12 < 0.05 or 0.0 as detection condition
        if s12 < 0.05:
            if self.first_detection_time is None:
                self.first_detection_time = current_time

            # Branch Isolation via Analytical Redundancy DM: compare |s13 - s23| > epsilon
            diff_s = abs(s13 - s23)
            if diff_s > self.th.epsilon:
                if s13 < s23:
                    candidate_branch = 1  # Branch 1 (KF1 / SB1 / SB2) has lower agreement with DM
                else:
                    candidate_branch = 2  # Branch 2 (KF2 / SB3 / SB4) has lower agreement with DM

                self.faulty_branch = candidate_branch

                # Software vs Hardware Error Identification via Sensor Residuals:
                if res_gps > self.th.th_gps_dist:
                    fault = FaultCategory.HARDWARE_SB2_GPS if candidate_branch == 1 else FaultCategory.HARDWARE_SB4_GPS
                    detail = f"Hardware GPS fault detected on Branch {candidate_branch} (res_gps = {res_gps:.2f}m > {self.th.th_gps_dist}m)"
                elif res_lidar > self.th.th_lidar_z:
                    fault = FaultCategory.HARDWARE_SB2_LIDAR if candidate_branch == 1 else FaultCategory.HARDWARE_SB4_LIDAR
                    detail = f"Hardware Lidar fault detected on Branch {candidate_branch} (res_lidar = {res_lidar:.2f}m > {self.th.th_lidar_z}m)"
                elif res_acc > self.th.th_imu_acc or res_gyro > self.th.th_imu_gyro:
                    fault = FaultCategory.HARDWARE_SB1_IMU if candidate_branch == 1 else FaultCategory.HARDWARE_SB3_IMU
                    detail = f"Hardware IMU fault detected on Branch {candidate_branch}"
                elif res_mag > self.th.th_mag_yaw:
                    fault = FaultCategory.HARDWARE_SB2_MAG if candidate_branch == 1 else FaultCategory.HARDWARE_SB4_MAG
                    detail = f"Hardware Magnetometer fault detected on Branch {candidate_branch}"
                else:
                    # All sensor residuals below threshold -> Software Fault in EKF!
                    fault = FaultCategory.SOFTWARE_KF1 if candidate_branch == 1 else FaultCategory.SOFTWARE_KF2
                    detail = f"Software fault detected in KF{candidate_branch} (all sensor residuals healthy)"

                self.active_fault = fault
                self.isolation_confirmed = True

                return DiagnosticResult(
                    is_fault_detected=True,
                    fault_type=fault,
                    faulty_branch_id=candidate_branch,
                    detection_timestamp=self.first_detection_time,
                    residuals=residuals,
                    agreement_indicators=indicators,
                    detail=detail
                )
            else:
                # Cannot yet isolate branch reliably (|s13 - s23| <= epsilon)
                return DiagnosticResult(
                    is_fault_detected=True,
                    fault_type=FaultCategory.NONE,
                    faulty_branch_id=None,
                    detection_timestamp=self.first_detection_time,
                    residuals=residuals,
                    agreement_indicators=indicators,
                    detail=f"Error detected (s12={s12:.2f}), but branch agreement difference |s13-s23|={diff_s:.3f} <= eps. Continuing observation."
                )

        # System healthy
        return DiagnosticResult(
            is_fault_detected=False,
            fault_type=FaultCategory.NONE,
            faulty_branch_id=None,
            detection_timestamp=None,
            residuals=residuals,
            agreement_indicators=indicators,
            detail="System healthy, all branches consistent"
        )

    def reset(self) -> None:
        """Reset diagnostics state."""
        self.active_fault = FaultCategory.NONE
        self.faulty_branch = None
        self.first_detection_time = None
        self.isolation_confirmed = False
