"""
UAV Fault-Tolerant Simulation Package.
Based on "Data Fusion Fault Tolerant Strategy for a Quadrotor UAV Under Sensors and Software Faults",
ISA Transactions (2022).
"""

from .quaternion_math import (
    quaternion_normalize,
    quaternion_multiply,
    quaternion_to_rotation_matrix,
    euler_to_quaternion,
    quaternion_to_euler,
    quaternion_angular_distance,
    quaternion_propagate
)
from .quadrotor_dynamics import QuadrotorDynamics, QuadrotorParameters
from .sensor_models import SensorBlockGroup, SensorNoiseParameters
from .ekf_estimator import UAVExtendedKalmanFilter, EKFConfig
from .dynamic_model_estimator import DynamicModelEstimator
from .weighted_voter import WeightedAverageVoter, VoterThresholds
from .fault_detector_identifier import FaultDetectorIdentifier, ResidualThresholds, FaultCategory
from .recovery_manager import RecoveryManager, RecoveryMode
from .flight_controller import FlightController, ControllerGains
from .fault_injector import FaultInjector, FaultProfile, ScenarioType
from .simulation_engine import SimulationRunner, TrajectoryGenerator

__all__ = [
    "quaternion_normalize",
    "quaternion_multiply",
    "quaternion_to_rotation_matrix",
    "euler_to_quaternion",
    "quaternion_to_euler",
    "quaternion_angular_distance",
    "quaternion_propagate",
    "QuadrotorDynamics",
    "QuadrotorParameters",
    "SensorBlockGroup",
    "SensorNoiseParameters",
    "UAVExtendedKalmanFilter",
    "EKFConfig",
    "DynamicModelEstimator",
    "WeightedAverageVoter",
    "VoterThresholds",
    "FaultDetectorIdentifier",
    "ResidualThresholds",
    "FaultCategory",
    "RecoveryManager",
    "RecoveryMode",
    "FlightController",
    "ControllerGains",
    "FaultInjector",
    "FaultProfile",
    "ScenarioType",
    "SimulationRunner",
    "TrajectoryGenerator"
]
