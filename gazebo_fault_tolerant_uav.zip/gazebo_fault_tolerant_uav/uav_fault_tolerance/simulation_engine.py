"""
Simulation Engine and Trajectory Pipeline Module.
Executes closed-loop simulation runs comparing Baseline (unprotected) vs Fault-Tolerant architectures,
logging high-resolution time series for quantitative evaluation and plotting.
"""

from dataclasses import dataclass
import numpy as np
import pandas as pd
from .quadrotor_dynamics import QuadrotorDynamics, QuadrotorParameters
from .sensor_models import SensorBlockGroup, SensorNoiseParameters
from .ekf_estimator import UAVExtendedKalmanFilter, EKFConfig
from .dynamic_model_estimator import DynamicModelEstimator
from .weighted_voter import WeightedAverageVoter, VoterThresholds
from .fault_detector_identifier import FaultDetectorIdentifier, ResidualThresholds, FaultCategory
from .recovery_manager import RecoveryManager, RecoveryMode
from .flight_controller import FlightController, ControllerGains
from .fault_injector import FaultInjector, FaultProfile, ScenarioType
from .quaternion_math import quaternion_to_euler, quaternion_angular_distance, quaternion_normalize


class TrajectoryGenerator:
    """
    Generates reference flight paths matching the research paper:
    - Takeoff to 3 m altitude
    - Hover at 3 m altitude
    - U-path trajectory (Paper Section 6.2 & 6.5)
    - Controlled landing
    """
    def __init__(self, mode: str = "u_path", target_alt: float = 3.0):
        self.mode = mode
        self.target_alt = target_alt

    def get_reference(self, t: float) -> tuple[np.ndarray, np.ndarray, float]:
        """
        Compute desired position [x, y, z], velocity [vx, vy, vz], and yaw angle at time t.
        """
        # Phase 1: Takeoff (0 <= t < 4s)
        if t < 4.0:
            frac = t / 4.0
            z = self.target_alt * (3.0 * frac**2 - 2.0 * frac**3)
            vz = (self.target_alt / 4.0) * (6.0 * frac - 6.0 * frac**2)
            return np.array([0.0, 0.0, z]), np.array([0.0, 0.0, vz]), 0.0

        # Phase 2: Hover (4s <= t < 7s)
        elif t < 7.0:
            return np.array([0.0, 0.0, self.target_alt]), np.zeros(3), 0.0

        # Phase 3: Trajectory Execution (7s <= t < 35s)
        elif t < 35.0:
            t_traj = t - 7.0
            if self.mode == "hover":
                # Pure hover test (Paper Section 6.3 & 6.4)
                return np.array([0.0, 0.0, self.target_alt]), np.zeros(3), 0.0
            else:
                # U-path trajectory (Paper Section 6.2: (0,0) -> (4, -3) U-turn)
                # Waypoint sequence smooth spline:
                # 0 to 8s: straight along +X to (4, 0)
                # 8 to 16s: arc / turn around to (4, -3)
                # 16 to 24s: return along -X to (0, -3)
                if t_traj < 8.0:
                    s = t_traj / 8.0
                    x = 4.0 * s
                    y = 0.0
                    vx = 4.0 / 8.0
                    vy = 0.0
                    yaw = 0.0
                elif t_traj < 16.0:
                    s = (t_traj - 8.0) / 8.0
                    # Half circle arc in Y-direction
                    theta = s * np.pi
                    x = 4.0 + 1.5 * np.sin(theta)
                    y = -1.5 * (1.0 - np.cos(theta))
                    vx = (1.5 * np.pi / 8.0) * np.cos(theta)
                    vy = -(1.5 * np.pi / 8.0) * np.sin(theta)
                    yaw = -theta
                else:
                    s = min(1.0, (t_traj - 16.0) / 10.0)
                    x = 4.0 * (1.0 - s)
                    y = -3.0
                    vx = -4.0 / 10.0
                    vy = 0.0
                    yaw = -np.pi

                return np.array([x, y, self.target_alt]), np.array([vx, vy, 0.0]), yaw

        # Phase 4: Controlled Landing (t >= 35s)
        else:
            t_land = t - 35.0
            z = max(0.0, self.target_alt - 0.5 * t_land)
            vz = -0.5 if z > 0.0 else 0.0
            return np.array([0.0, -3.0, z]), np.array([0.0, 0.0, vz]), 0.0


class SimulationRunner:
    """
    Simulates a complete quadrotor mission with sensor acquisition, state estimation,
    voting, fault detection/isolation/recovery, and flight control.
    """
    def __init__(self, fault_profile: FaultProfile, enable_fault_tolerance: bool = True,
                 trajectory_mode: str = "u_path", dt: float = 0.01, duration: float = 40.0,
                 wind_speed: float = 4.0, wind_heading: float = np.pi / 4.0):
        self.profile = fault_profile
        self.enable_ft = enable_fault_tolerance
        self.dt = dt
        self.duration = duration
        self.traj_gen = TrajectoryGenerator(mode=trajectory_mode, target_alt=3.0)
        self.wind_speed = wind_speed
        self.wind_heading = wind_heading

        # Core components
        self.uav = QuadrotorDynamics()
        self.sensors = SensorBlockGroup(seed=42)
        self.ekf1 = UAVExtendedKalmanFilter(name="EKF1")
        self.ekf2 = UAVExtendedKalmanFilter(name="EKF2")
        self.dm = DynamicModelEstimator()
        self.voter = WeightedAverageVoter()
        self.fdi = FaultDetectorIdentifier()
        self.recovery = RecoveryManager(preferred_solution=3)
        self.controller = FlightController()
        self.injector = FaultInjector(fault_profile)

        # Actuator state
        self.last_pwm = np.full(4, 1740.0)

    def run(self) -> pd.DataFrame:
        """
        Execute full mission time-history and return detailed Pandas DataFrame.
        """
        records = []
        n_steps = int(self.duration / self.dt)

        for step in range(n_steps):
            t = step * self.dt

            # 1. Trajectory Reference
            pos_ref, vel_ref, yaw_ref = self.traj_gen.get_reference(t)

            # 2. Acquire True Physical State
            gt = {
                "pos": self.uav.position.copy(),
                "vel": self.uav.velocity.copy(),
                "quaternion": self.uav.quaternion.copy(),
                "euler": np.array(self.uav.get_euler_angles()),
                "omega": self.uav.angular_velocity.copy(),
                "acc": self.uav.get_specific_force_body()
            }

            # 3. Sample Redundant Sensor Streams
            raw_sensors = self.sensors.sample_sensors(self.uav)

            # 4. Fault Injection (Sensors and Software)
            sens_with_faults = self.injector.apply_sensor_faults(t, raw_sensors)
            self.injector.apply_software_faults(t, self.ekf1, self.ekf2)

            # 5. Estimator Prediction Steps
            # Branch A: EKF1 uses SB1 (IMU1)
            b1 = sens_with_faults["branch1"]
            self.ekf1.predict(b1["acc"], b1["gyro"], self.dt)

            # Branch B: EKF2 uses SB3 (IMU2)
            b2 = sens_with_faults["branch2"]
            self.ekf2.predict(b2["acc"], b2["gyro"], self.dt)

            # Branch C: DM integrates using previous PWM commands
            self.dm.step(self.last_pwm, self.dt)

            # 6. Estimator Update Steps
            # Periodic GPS/Lidar updates (e.g. at 20 Hz, every 5 steps)
            if step % 2 == 0:
                self.ekf1.update(b1["gps_pos"], b1["gps_vel"], b1["lidar"], b1["mag"])
                self.ekf2.update(b2["gps_pos"], b2["gps_vel"], b2["lidar"], b2["mag"])

            # Extract branch states
            s_ekf1 = self.ekf1.get_state()
            s_ekf2 = self.ekf2.get_state()
            s_dm = self.dm.get_state()

            # 7. Fault-Tolerant Voting & Diagnostics (or Baseline)
            if self.enable_ft:
                # Reconfigure inputs based on active recovery mode
                active_branch_states = self.recovery.reconfigure_active_states(s_ekf1, s_ekf2, s_dm)

                # Vote across active branches
                voter_res = self.voter.vote_states(active_branch_states)
                fused_state = voter_res["state"]
                v_info = voter_res["info"]

                # Run Fault Detection & Identification (Algorithm 1)
                diag = self.fdi.evaluate(t, v_info, sens_with_faults)

                if diag.fault_type == FaultCategory.MODEL_DIVERGENCE_DM:
                    # Section 5.3: Reset DM state to the average of healthy KF1 and KF2
                    avg_p = 0.5 * (s_ekf1["pos"] + s_ekf2["pos"])
                    avg_v = 0.5 * (s_ekf1["vel"] + s_ekf2["vel"])
                    avg_q = quaternion_normalize(0.5 * (s_ekf1["quaternion"] + s_ekf2["quaternion"]))
                    self.dm.reset_to_state(avg_p, avg_v, avg_q)

                # Pass diagnostics to Recovery Manager
                self.recovery.process_diagnostics(t, diag)

                # Control feedback uses the Fault-Tolerant fused state
                control_feedback_state = fused_state

                # Soft consensus discipline for DM if both EKFs agree and are healthy
                if not self.recovery.recovery_active and v_info["S_xy"][0, 1] > 0.8:
                    avg_gyro = 0.5 * (b1["gyro"] + b2["gyro"])
                    self.dm.soft_reset_from_consensus(
                        fused_state["pos"], fused_state["vel"], fused_state["quaternion"],
                        consensus_omega=avg_gyro, alpha=0.05
                    )

            else:
                # Baseline mode: No voting, no FDI, direct use of EKF1 (standard drone architecture)
                control_feedback_state = s_ekf1
                fused_state = s_ekf1
                # Dummy voter info for baseline logging
                v_info = {
                    "weights_pos": [1.0, 0.0, 0.0],
                    "weights_x": [1.0, 0.0, 0.0],
                    "weights_y": [1.0, 0.0, 0.0],
                    "weights_z": [1.0, 0.0, 0.0],
                    "weights_q": [1.0, 0.0, 0.0],
                    "S_xy": np.eye(3),
                    "S_z": np.eye(3),
                    "S_q": np.eye(3)
                }
                diag = self.fdi.evaluate(t, v_info, sens_with_faults)

            # 8. Flight Control Execution
            # Supply current estimated state to controller
            controller_state = {
                "pos": control_feedback_state["pos"],
                "vel": control_feedback_state["vel"],
                "euler": control_feedback_state["euler"],
                "omega": self.uav.angular_velocity
            }
            pwm_cmds, uf, moments = self.controller.compute_control(
                controller_state, pos_ref, vel_ref, yaw_ref, self.dt
            )
            self.last_pwm = pwm_cmds

            # 9. Dynamic Wind Perturbation (Hamadi et al. Eq. 2, 3: Fw)
            # Steady wind component with sinusoidal gust spectrum and turbulence
            gust = 0.25 * self.wind_speed * np.sin(0.4 * np.pi * t) + 0.12 * np.cos(1.8 * t)
            eff_wind_speed = max(0.0, self.wind_speed + gust)
            v_wind = np.array([
                eff_wind_speed * np.cos(self.wind_heading),
                eff_wind_speed * np.sin(self.wind_heading),
                0.04 * np.sin(0.5 * t)
            ], dtype=float)
            v_rel = v_wind - self.uav.velocity
            v_rel_norm = float(np.linalg.norm(v_rel))
            # Aerodynamic quadratic drag model: 0.5 * rho * Cd * A * |v_rel| * v_rel
            wind_force = 0.5 * 1.225 * 1.05 * 0.05 * v_rel_norm * v_rel

            # Advance UAV True Physical Dynamics under actuator thrust and wind
            self.uav.step(pwm_cmds, self.dt, wind_force=wind_force)

            # 10. Record Time Step Signals
            pos_err = np.linalg.norm(gt["pos"] - control_feedback_state["pos"])
            tracking_err = np.linalg.norm(gt["pos"] - pos_ref)
            att_err = np.degrees(quaternion_angular_distance(gt["quaternion"], control_feedback_state["quaternion"]))

            rec = {
                "time": t,
                # Environmental wind forces
                "wind_fx": wind_force[0], "wind_fy": wind_force[1], "wind_fz": wind_force[2],
                "wind_speed": eff_wind_speed,
                # Ground truth
                "gt_x": gt["pos"][0], "gt_y": gt["pos"][1], "gt_z": gt["pos"][2],
                "gt_vx": gt["vel"][0], "gt_vy": gt["vel"][1], "gt_vz": gt["vel"][2],
                "gt_roll": np.degrees(gt["euler"][0]), "gt_pitch": np.degrees(gt["euler"][1]), "gt_yaw": np.degrees(gt["euler"][2]),
                # Trajectory Target
                "ref_x": pos_ref[0], "ref_y": pos_ref[1], "ref_z": pos_ref[2],
                "ref_yaw": np.degrees(yaw_ref),
                # Raw Sensors Branch 1
                "gps1_x": b1["gps_pos"][0], "gps1_y": b1["gps_pos"][1], "lidar1_z": b1["lidar"],
                "acc1_x": b1["acc"][0], "acc1_y": b1["acc"][1], "acc1_z": b1["acc"][2],
                # Raw Sensors Branch 2
                "gps2_x": b2["gps_pos"][0], "gps2_y": b2["gps_pos"][1], "lidar2_z": b2["lidar"],
                "acc2_x": b2["acc"][0], "acc2_y": b2["acc"][1], "acc2_z": b2["acc"][2],
                # EKF 1
                "ekf1_x": s_ekf1["pos"][0], "ekf1_y": s_ekf1["pos"][1], "ekf1_z": s_ekf1["pos"][2],
                "ekf1_roll": np.degrees(s_ekf1["euler"][0]), "ekf1_pitch": np.degrees(s_ekf1["euler"][1]), "ekf1_yaw": np.degrees(s_ekf1["euler"][2]),
                # EKF 2
                "ekf2_x": s_ekf2["pos"][0], "ekf2_y": s_ekf2["pos"][1], "ekf2_z": s_ekf2["pos"][2],
                "ekf2_roll": np.degrees(s_ekf2["euler"][0]), "ekf2_pitch": np.degrees(s_ekf2["euler"][1]), "ekf2_yaw": np.degrees(s_ekf2["euler"][2]),
                # DM
                "dm_x": s_dm["pos"][0], "dm_y": s_dm["pos"][1], "dm_z": s_dm["pos"][2],
                "dm_roll": np.degrees(s_dm["euler"][0]), "dm_pitch": np.degrees(s_dm["euler"][1]), "dm_yaw": np.degrees(s_dm["euler"][2]),
                # Fused / Voter Output
                "fused_x": fused_state["pos"][0], "fused_y": fused_state["pos"][1], "fused_z": fused_state["pos"][2],
                "fused_roll": np.degrees(fused_state["euler"][0]), "fused_pitch": np.degrees(fused_state["euler"][1]), "fused_yaw": np.degrees(fused_state["euler"][2]),
                # Voter Agreement Indicators
                "s12": diag.agreement_indicators.get("s12", 1.0),
                "s13": diag.agreement_indicators.get("s13", 1.0),
                "s23": diag.agreement_indicators.get("s23", 1.0),
                "s12_pos": diag.agreement_indicators.get("s12_pos", 1.0),
                "s13_pos": diag.agreement_indicators.get("s13_pos", 1.0),
                "s23_pos": diag.agreement_indicators.get("s23_pos", 1.0),
                "s12_z": diag.agreement_indicators.get("s12_z", 1.0),
                "s13_z": diag.agreement_indicators.get("s13_z", 1.0),
                "s23_z": diag.agreement_indicators.get("s23_z", 1.0),
                # Voter Weights
                "w1": v_info["weights_pos"][0] if len(v_info["weights_pos"]) > 0 else 0.0,
                "w2": v_info["weights_pos"][1] if len(v_info["weights_pos"]) > 1 else 0.0,
                "w3": v_info["weights_pos"][2] if len(v_info["weights_pos"]) > 2 else 0.0,
                # Residuals
                "res_gps": diag.residuals.get("res_gps", 0.0),
                "res_lidar": diag.residuals.get("res_lidar", 0.0),
                "res_acc": diag.residuals.get("res_acc", 0.0),
                "res_gyro": diag.residuals.get("res_gyro", 0.0),
                # Diagnostic Flags
                "fault_detected": 1 if diag.is_fault_detected else 0,
                "fault_type": diag.fault_type.value,
                "faulty_branch": diag.faulty_branch_id if diag.faulty_branch_id is not None else 0,
                "recovery_active": 1 if self.recovery.recovery_active else 0,
                "recovery_mode": self.recovery.mode.value,
                # Errors
                "pos_estimation_error": pos_err,
                "tracking_error": tracking_err,
                "attitude_error_deg": att_err,
                "thrust_uf": uf,
                "pwm1": pwm_cmds[0], "pwm2": pwm_cmds[1], "pwm3": pwm_cmds[2], "pwm4": pwm_cmds[3]
            }
            records.append(rec)

        df = pd.DataFrame(records)
        return df
