"""
Recovery Manager Module.
Implements the reconfiguration and recovery strategies described in Hamadi et al. (2022), Section 5.4.
Supports Solution 1 (component substitution), Solution 2 (isolation), and Solution 3 (virtual estimation branch KF3).
"""

from enum import Enum
import numpy as np
from .fault_detector_identifier import DiagnosticResult, FaultCategory


class RecoveryMode(Enum):
    NORMAL = "NORMAL"                                     # All 3 branches active (KF1, KF2, DM)
    ISOLATION_RECOVERY = "ISOLATION_RECOVERY"             # Sol 2: Exclude faulty branch, vote with healthy KF + DM
    VIRTUAL_BRANCH_RECOVERY = "VIRTUAL_BRANCH_RECOVERY"   # Sol 3: Replace faulty branch with KF3 = avg(KF_healthy, DM)
    SAFE_HOLD = "SAFE_HOLD"                               # Hold position if redundancy degraded
    CONTROLLED_LANDING = "CONTROLLED_LANDING"             # Safe failsafe landing if multiple simultaneous failures


class RecoveryManager:
    """
    Manages active estimator reconfiguration, branch switching, and flight safety states.
    """
    def __init__(self, preferred_solution: int = 3):
        # 2: Solution 2 (isolate), 3: Solution 3 (virtual branch KF3 as in paper Section 6.2/6.3)
        self.preferred_solution = preferred_solution
        self.mode = RecoveryMode.NORMAL
        self.isolated_branch: int | None = None
        self.recovery_timestamp: float | None = None
        self.recovery_active: bool = False
        self.detail: str = "Operating in 3-branch nominal mode."

    def process_diagnostics(self, current_time: float, diag: DiagnosticResult) -> None:
        """
        Evaluate diagnostic report and trigger reconfiguration if a fault is confirmed.
        """
        if not diag.is_fault_detected or diag.faulty_branch_id is None:
            return

        # If already recovered from this branch, do not repeat
        if self.recovery_active and self.isolated_branch == diag.faulty_branch_id:
            return

        self.isolated_branch = diag.faulty_branch_id
        self.recovery_timestamp = current_time
        self.recovery_active = True

        if self.preferred_solution == 3:
            self.mode = RecoveryMode.VIRTUAL_BRANCH_RECOVERY
            self.detail = f"Activated Solution 3: Replaced Branch {self.isolated_branch} with virtual branch KF3 = (KF_healthy + DM)/2. Reconfigured voter."
        else:
            self.mode = RecoveryMode.ISOLATION_RECOVERY
            self.detail = f"Activated Solution 2: Isolated Branch {self.isolated_branch}. Voting across remaining healthy branch and DM."

    def reconfigure_active_states(self, kf1_state: dict[str, np.ndarray],
                                 kf2_state: dict[str, np.ndarray],
                                 dm_state: dict[str, np.ndarray]) -> list[dict[str, np.ndarray]]:
        """
        Produce the list of valid branch states to feed into the weighted-average voter.
        In nominal mode: [KF1, KF2, DM]
        In Solution 3 mode: If Branch 1 faulty: [KF3=(KF2+DM)/2, KF2, DM]
        In Solution 2 mode: If Branch 1 faulty: [KF2, DM]
        """
        if not self.recovery_active or self.isolated_branch is None:
            return [kf1_state, kf2_state, dm_state]

        healthy_kf = kf2_state if self.isolated_branch == 1 else kf1_state

        if self.mode == RecoveryMode.VIRTUAL_BRANCH_RECOVERY:
            # Construct virtual estimation branch KF3 (Paper Section 5.4.1 Sol 3 and Section 6.2)
            # "where the weight of the KF2's output is greater than the DM's output"
            kf3_pos = 0.85 * healthy_kf["pos"] + 0.15 * dm_state["pos"]
            kf3_vel = 0.85 * healthy_kf["vel"] + 0.15 * dm_state["vel"]
            # Blend quaternions
            kf3_quat = 0.85 * healthy_kf["quaternion"] + 0.15 * dm_state["quaternion"]
            norm_q = np.linalg.norm(kf3_quat)
            if norm_q > 1e-12:
                kf3_quat /= norm_q
            else:
                kf3_quat = healthy_kf["quaternion"].copy()

            kf3_state = {
                "pos": kf3_pos,
                "vel": kf3_vel,
                "quaternion": kf3_quat,
                "euler": 0.85 * healthy_kf["euler"] + 0.15 * dm_state["euler"]
            }

            if self.isolated_branch == 1:
                return [kf3_state, kf2_state, dm_state]
            else:
                return [kf1_state, kf3_state, dm_state]

        elif self.mode == RecoveryMode.ISOLATION_RECOVERY:
            # Solution 2: isolate faulty branch entirely
            return [healthy_kf, dm_state]

        else:
            return [healthy_kf, dm_state]

    def reset(self) -> None:
        """Reset recovery manager."""
        self.mode = RecoveryMode.NORMAL
        self.isolated_branch = None
        self.recovery_timestamp = None
        self.recovery_active = False
        self.detail = "Operating in nominal mode."
