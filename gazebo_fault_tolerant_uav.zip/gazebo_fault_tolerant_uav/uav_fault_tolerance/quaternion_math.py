"""
Quaternion Mathematics and Coordinate Transformations Module.

Convention: Hamilton Unit Quaternion q = [q_w, q_x, q_y, q_z]^T
Coordinate Frame: ENU (East-North-Up) Inertial Frame, Forward-Left-Up (FLU) Body Frame.
Complies with quadrotor equations of motion from Hamadi et al., ISA Transactions (2022).
"""

import numpy as np


def quaternion_normalize(q: np.ndarray) -> np.ndarray:
    """Normalize quaternion to unit norm, handling zero norm safely."""
    norm = np.linalg.norm(q)
    if norm < 1e-12:
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=float)
    return q / norm


def quaternion_multiply(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    """Hamilton quaternion product q = q1 * q2."""
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return np.array([
        w1*w2 - x1*x2 - y1*y2 - z1*z2,
        w1*x2 + x1*w2 + y1*z2 - z1*y2,
        w1*y2 - x1*z2 + y1*w2 + z1*x2,
        w1*z2 + x1*y2 - y1*x2 + z1*w2
    ], dtype=float)


def quaternion_conjugate(q: np.ndarray) -> np.ndarray:
    """Return conjugate of quaternion q: [w, -x, -y, -z]."""
    return np.array([q[0], -q[1], -q[2], -q[3]], dtype=float)


def quaternion_to_rotation_matrix(q: np.ndarray) -> np.ndarray:
    """
    Convert unit quaternion to 3x3 direction cosine matrix R_B_to_E.
    Transforms vectors from Body Frame to Earth Frame: v_E = R_B_to_E * v_B.
    """
    q = quaternion_normalize(q)
    w, x, y, z = q
    return np.array([
        [1.0 - 2.0*(y*y + z*z), 2.0*(x*y - w*z),       2.0*(x*z + w*y)],
        [2.0*(x*y + w*z),       1.0 - 2.0*(x*x + z*z), 2.0*(y*z - w*x)],
        [2.0*(x*z - w*y),       2.0*(y*z + w*x),       1.0 - 2.0*(x*x + y*y)]
    ], dtype=float)


def euler_to_quaternion(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """
    Convert Z-Y-X Euler angles (radians) to Hamilton unit quaternion [w, x, y, z].
    roll: phi, pitch: theta, yaw: psi.
    """
    cr = np.cos(roll * 0.5)
    sr = np.sin(roll * 0.5)
    cp = np.cos(pitch * 0.5)
    sp = np.sin(pitch * 0.5)
    cy = np.cos(yaw * 0.5)
    sy = np.sin(yaw * 0.5)

    q = np.array([
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy
    ], dtype=float)
    return quaternion_normalize(q)


def quaternion_to_euler(q: np.ndarray) -> tuple[float, float, float]:
    """
    Convert unit quaternion [w, x, y, z] to Euler angles (roll, pitch, yaw) in radians.
    Returns: (phi, theta, psi)
    """
    q = quaternion_normalize(q)
    w, x, y, z = q

    # Roll (x-axis rotation)
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = np.arctan2(sinr_cosp, cosr_cosp)

    # Pitch (y-axis rotation)
    sinp = 2.0 * (w * y - z * x)
    if np.abs(sinp) >= 1.0:
        pitch = np.sign(sinp) * (np.pi / 2.0)
    else:
        pitch = np.arcsin(sinp)

    # Yaw (z-axis rotation)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = np.arctan2(siny_cosp, cosy_cosp)

    return roll, pitch, yaw


def quaternion_angular_distance(q1: np.ndarray, q2: np.ndarray) -> float:
    """
    Compute geodesic orientation distance (in radians) between two quaternions,
    accounting for antipodal symmetry q == -q.
    Range: [0, pi] radians.
    """
    q1 = quaternion_normalize(q1)
    q2 = quaternion_normalize(q2)
    inner_product = np.abs(np.clip(np.dot(q1, q2), -1.0, 1.0))
    angle = 2.0 * np.arccos(inner_product)
    return float(angle)


def quaternion_derivative(q: np.ndarray, omega: np.ndarray) -> np.ndarray:
    """
    Compute time derivative dq/dt given angular velocity omega = [p, q, r] in body frame.
    dq/dt = 0.5 * Omega(omega) * q
    """
    p, q_rate, r = omega
    omega_mat = np.array([
        [0.0, -p,   -q_rate, -r],
        [p,    0.0,  r,      -q_rate],
        [q_rate, -r, 0.0,     p],
        [r,    q_rate, -p,    0.0]
    ], dtype=float)
    return 0.5 * (omega_mat @ q)


def quaternion_propagate(q: np.ndarray, omega: np.ndarray, dt: float) -> np.ndarray:
    """
    Propagate quaternion by body angular velocity over time step dt using exact matrix exponential.
    """
    norm_w = np.linalg.norm(omega)
    if norm_w < 1e-12:
        return quaternion_normalize(q)
    
    half_angle = 0.5 * norm_w * dt
    axis = omega / norm_w
    dq = np.array([
        np.cos(half_angle),
        axis[0] * np.sin(half_angle),
        axis[1] * np.sin(half_angle),
        axis[2] * np.sin(half_angle)
    ], dtype=float)
    
    # Body-frame rotation update: q_next = q * dq
    q_next = quaternion_multiply(q, dq)
    return quaternion_normalize(q_next)
