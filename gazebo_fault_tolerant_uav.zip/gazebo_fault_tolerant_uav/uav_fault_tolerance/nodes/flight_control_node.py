"""
ROS 2 Node: Flight Control and Actuator Mixer Node.
Tracks position/attitude trajectories using sliding-mode control and feeds commands to motors.
"""

import sys
import os
import numpy as np

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import PoseStamped
    from std_msgs.msg import Float32MultiArray
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    class Node:
        def __init__(self, name): pass

from uav_fault_tolerance.flight_controller import FlightController


class FlightControlNode(Node):
    """
    ROS 2 Node executing the sliding mode trajectory tracking controller.
    """
    def __init__(self):
        super().__init__("flight_control_node")
        if not ROS2_AVAILABLE:
            return

        self.controller = FlightController()
        self.pub_pwm = self.create_publisher(Float32MultiArray, "/flight_controller/pwm_commands", 10)
        self.sub_pose = self.create_subscription(PoseStamped, "/estimator/voter/fused_pose", self._cb_pose, 10)

        # Target waypoint
        self.target_pos = np.array([0.0, 0.0, 3.0])
        self.get_logger().info("Flight Control Node active.")

    def _cb_pose(self, msg: PoseStamped):
        st = {
            "pos": np.array([msg.pose.position.x, msg.pose.position.y, msg.pose.position.z]),
            "vel": np.zeros(3),
            "euler": np.zeros(3),
            "omega": np.zeros(3)
        }
        pwms, uf, moments = self.controller.compute_control(
            st, self.target_pos, np.zeros(3), 0.0, dt=0.01
        )
        out_msg = Float32MultiArray()
        out_msg.data = [float(p) for p in pwms]
        self.pub_pwm.publish(out_msg)


def main(args=None):
    if not ROS2_AVAILABLE:
        return
    rclpy.init(args=args)
    node = FlightControlNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
