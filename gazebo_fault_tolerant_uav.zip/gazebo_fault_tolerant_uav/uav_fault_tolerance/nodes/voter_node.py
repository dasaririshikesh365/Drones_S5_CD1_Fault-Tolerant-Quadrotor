"""
ROS 2 Node: Weighted-Average Voter Node.
Implements the 3-input soft threshold weighted voter from Hamadi et al. (2022), Section 5.1.
"""

import sys
import os
import numpy as np

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import PoseStamped
    from std_msgs.msg import Float32MultiArray
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    class Node:
        def __init__(self, name): pass

from uav_fault_tolerance.weighted_voter import WeightedAverageVoter


class VoterNode(Node):
    """
    ROS 2 Node executing the Weighted-Average Voter on Branch 1, Branch 2, and Branch 3.
    """
    def __init__(self):
        super().__init__("voter_node")
        if not ROS2_AVAILABLE:
            return

        self.voter = WeightedAverageVoter()

        # States of each branch
        self.state_kf1 = None
        self.state_kf2 = None
        self.state_dm = None

        # Publishers
        self.pub_fused = self.create_publisher(PoseStamped, "/estimator/voter/fused_pose", 10)
        self.pub_weights = self.create_publisher(Float32MultiArray, "/diagnostics/voter_weights", 10)
        self.pub_agreements = self.create_publisher(Float32MultiArray, "/diagnostics/agreement_indicators", 10)

        # Subscriptions
        self.sub_kf1 = self.create_subscription(PoseStamped, "/estimator/ekf1/pose", self._cb_kf1, 10)
        self.sub_kf2 = self.create_subscription(PoseStamped, "/estimator/ekf2/pose", self._cb_kf2, 10)
        self.sub_dm = self.create_subscription(PoseStamped, "/estimator/dynamic_model/pose", self._cb_dm, 10)

        self.timer = self.create_timer(0.01, self._vote_cb)
        self.get_logger().info("Weighted Voter Node active.")

    def _extract_state(self, msg: PoseStamped) -> dict:
        return {
            "pos": np.array([msg.pose.position.x, msg.pose.position.y, msg.pose.position.z]),
            "vel": np.zeros(3),
            "quaternion": np.array([msg.pose.orientation.w, msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z]),
            "euler": np.zeros(3)
        }

    def _cb_kf1(self, msg: PoseStamped):
        self.state_kf1 = self._extract_state(msg)

    def _cb_kf2(self, msg: PoseStamped):
        self.state_kf2 = self._extract_state(msg)

    def _cb_dm(self, msg: PoseStamped):
        self.state_dm = self._extract_state(msg)

    def _vote_cb(self):
        if self.state_kf1 is None or self.state_kf2 is None or self.state_dm is None:
            return

        res = self.voter.vote_states([self.state_kf1, self.state_kf2, self.state_dm])
        fused = res["state"]
        info = res["info"]

        # Publish fused pose
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "map"
        msg.pose.position.x = fused["pos"][0]
        msg.pose.position.y = fused["pos"][1]
        msg.pose.position.z = fused["pos"][2]
        msg.pose.orientation.w = fused["quaternion"][0]
        msg.pose.orientation.x = fused["quaternion"][1]
        msg.pose.orientation.y = fused["quaternion"][2]
        msg.pose.orientation.z = fused["quaternion"][3]
        self.pub_fused.publish(msg)

        # Publish weights
        w_msg = Float32MultiArray()
        w_msg.data = [float(w) for w in info["weights_pos"]]
        self.pub_weights.publish(w_msg)

        # Publish agreement indicators s12, s13, s23
        s_msg = Float32MultiArray()
        s_msg.data = [
            float(info["S_xy"][0, 1]),
            float(info["S_xy"][0, 2]),
            float(info["S_xy"][1, 2])
        ]
        self.pub_agreements.publish(s_msg)


def main(args=None):
    if not ROS2_AVAILABLE:
        return
    rclpy.init(args=args)
    node = VoterNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
