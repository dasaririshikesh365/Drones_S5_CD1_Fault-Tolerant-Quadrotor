"""
ROS 2 Node: Manual Teleop Keyboard Controller for UAV Simulation.
Implements Section 5 of the specification:
- W/S: forward/backward (pitch)
- A/D: left/right (roll)
- Arrow Up/Down: climb/descend (throttle/altitude)
- Arrow Left/Right: yaw left/right
- Space: hover / zero velocity
- T: takeoff to 3.0m
- L: land
- R: reset confirmation
- P: pause / resume
"""

import sys
import select
import termios
import tty
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Bool


BANNER = """
==================================================================
           FAULT-TOLERANT UAV KEYBOARD TELEOPERATION
==================================================================
  Movement:
      W / S         : Forward / Backward  (Vx: +1.5 / -1.5 m/s)
      A / D         : Left / Right        (Vy: +1.5 / -1.5 m/s)
      UP / DOWN     : Climb / Descend     (Vz: +1.0 / -1.0 m/s)
      LEFT / RIGHT  : Yaw CCW / CW        (YawRate: +0.8 / -0.8 rad/s)
      SPACE         : Active Hover (Zero velocity hold)

  Flight Commands:
      T             : Auto Takeoff (to 3.0 m)
      L             : Auto Land
      P             : Pause / Resume Simulation
      R             : Reset Simulation (press 'Y' to confirm)
      CTRL-C        : Safe Exit / Stop

  Publishing to /uav/cmd_vel and /uav/flight_mode
==================================================================
"""


class ManualTeleopNode(Node):
    def __init__(self):
        super().__init__('manual_teleop_node')
        self.cmd_pub = self.create_publisher(Twist, '/uav/cmd_vel', 10)
        self.mode_pub = self.create_publisher(String, '/uav/flight_mode_cmd', 10)
        self.pause_pub = self.create_publisher(Bool, '/uav/sim_pause', 10)

        self.linear_speed = 1.5
        self.vertical_speed = 1.0
        self.yaw_speed = 0.8
        self.is_paused = False

        self.timer = self.create_timer(0.05, self.teleop_loop)
        self.get_logger().info("Manual Teleop Node initialized. Keyboard control active.")
        print(BANNER)

    def get_key(self):
        if not sys.stdin.isatty():
            return None
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            rlist, _, _ = select.select([sys.stdin], [], [], 0.02)
            if rlist:
                key = sys.stdin.read(1)
                if key == '\x1b':  # Arrow keys start with escape sequence
                    seq = sys.stdin.read(2)
                    if seq == '[A':
                        return 'UP'
                    elif seq == '[B':
                        return 'DOWN'
                    elif seq == '[C':
                        return 'RIGHT'
                    elif seq == '[D':
                        return 'LEFT'
                return key
            return None
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def teleop_loop(self):
        key = self.get_key()
        if key is None:
            return

        cmd = Twist()
        mode_msg = String()

        if key in ['w', 'W']:
            cmd.linear.x = self.linear_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: FORWARD")
        elif key in ['s', 'S']:
            cmd.linear.x = -self.linear_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: BACKWARD")
        elif key in ['a', 'A']:
            cmd.linear.y = self.linear_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: LEFT")
        elif key in ['d', 'D']:
            cmd.linear.y = -self.linear_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: RIGHT")
        elif key == 'UP':
            cmd.linear.z = self.vertical_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: CLIMB")
        elif key == 'DOWN':
            cmd.linear.z = -self.vertical_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: DESCEND")
        elif key == 'LEFT':
            cmd.angular.z = self.yaw_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: YAW LEFT")
        elif key == 'RIGHT':
            cmd.angular.z = -self.yaw_speed
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: YAW RIGHT")
        elif key == ' ':
            # Active hover
            cmd.linear.x = 0.0
            cmd.linear.y = 0.0
            cmd.linear.z = 0.0
            cmd.angular.z = 0.0
            self.cmd_pub.publish(cmd)
            self.get_logger().info("Command: ACTIVE HOVER (ZERO VELOCITY)")
        elif key in ['t', 'T']:
            mode_msg.data = "TAKEOFF"
            self.mode_pub.publish(mode_msg)
            self.get_logger().info("Command: TAKEOFF")
        elif key in ['l', 'L']:
            mode_msg.data = "LAND"
            self.mode_pub.publish(mode_msg)
            self.get_logger().info("Command: LAND")
        elif key in ['p', 'P']:
            self.is_paused = not self.is_paused
            pause_msg = Bool()
            pause_msg.data = self.is_paused
            self.pause_pub.publish(pause_msg)
            status_str = "PAUSED" if self.is_paused else "RESUMED"
            self.get_logger().info(f"Command: SIMULATION {status_str}")
        elif key in ['r', 'R']:
            mode_msg.data = "RESET"
            self.mode_pub.publish(mode_msg)
            self.get_logger().warn("Command: SIMULATION RESET TRIGGERED")


def main(args=None):
    rclpy.init(args=args)
    node = ManualTeleopNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
