"""
ROS 2 Node: Extended Kalman Filter (EKF) Estimator Node.
Can be instantiated as EKF1 (Branch A) or EKF2 (Branch B).
"""

import sys
import os
import numpy as np

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import PoseStamped, TwistStamped
    from sensor_msgs.msg import Imu, NavSatFix
    from std_msgs.msg import Float32
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    class Node:
        def __init__(self, name): pass

from uav_fault_tolerance.ekf_estimator import UAVExtendedKalmanFilter, EKFConfig


class EKFNode(Node):
    """
    ROS 2 Node running an independent Extended Kalman Filter.
    Subscribes to designated sensor blocks and publishes estimated pose and velocity.
    """
    def __init__(self):
        super().__init__("ekf_node")
        if not ROS2_AVAILABLE:
            print("[EKFNode] rclpy not installed. Node defined for ROS 2 deployment.")
            return

        self.declare_parameter("branch_id", 1)
        self.branch_id = self.get_parameter("branch_id").get_parameter_value().integer_value
        name = f"EKF{self.branch_id}"
        self.ekf = UAVExtendedKalmanFilter(name=name)

        # Publishers
        self.pub_pose = self.create_publisher(PoseStamped, f"/estimator/ekf{self.branch_id}/pose", 10)
        self.pub_twist = self.create_publisher(TwistStamped, f"/estimator/ekf{self.branch_id}/velocity", 10)

        # Subscriptions
        imu_topic = f"/sensor_block_{1 if self.branch_id == 1 else 3}/imu"
        gps_topic = f"/sensor_block_{2 if self.branch_id == 1 else 4}/gps"
        lidar_topic = f"/sensor_block_{2 if self.branch_id == 1 else 4}/lidar"

        self.sub_imu = self.create_subscription(Imu, imu_topic, self._cb_imu, 10)
        self.sub_gps = self.create_subscription(NavSatFix, gps_topic, self._cb_gps, 10)
        self.sub_lidar = self.create_subscription(Float32, lidar_topic, self._cb_lidar, 10)

        self.last_time = None
        self.get_logger().info(f"{name} Node active on {imu_topic}, {gps_topic}, {lidar_topic}")

    def _cb_imu(self, msg: Imu):
        now_t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if self.last_time is None:
            self.last_time = now_t
            return
        dt = max(0.001, min(0.05, now_t - self.last_time))
        self.last_time = now_t

        acc = np.array([msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z])
        gyro = np.array([msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z])
        self.ekf.predict(acc, gyro, dt)

        # Publish state
        st = self.ekf.get_state()
        p_msg = PoseStamped()
        p_msg.header.stamp = msg.header.stamp
        p_msg.header.frame_id = "map"
        p_msg.pose.position.x = st["pos"][0]
        p_msg.pose.position.y = st["pos"][1]
        p_msg.pose.position.z = st["pos"][2]
        p_msg.pose.orientation.w = st["quaternion"][0]
        p_msg.pose.orientation.x = st["quaternion"][1]
        p_msg.pose.orientation.y = st["quaternion"][2]
        p_msg.pose.orientation.z = st["quaternion"][3]
        self.pub_pose.publish(p_msg)

    def _cb_gps(self, msg: NavSatFix):
        pos_xy = np.array([msg.latitude, msg.longitude])  # In local ENU meters in practice
        self.ekf.update(gps_pos=pos_xy, gps_vel=None, lidar_z=None, mag_yaw=None)

    def _cb_lidar(self, msg: Float32):
        self.ekf.update(gps_pos=None, gps_vel=None, lidar_z=float(msg.data), mag_yaw=None)


def main(args=None):
    if not ROS2_AVAILABLE:
        return
    rclpy.init(args=args)
    node = EKFNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
