"""
ROS 2 Node: Sensor Bridge and Fault Injector Node.
Acquires raw sensor topics from Gazebo Harmonic / PX4 bridges, applies configurable
fault injection profiles, and publishes to redundant Sensor Blocks (SB1..SB4).
"""

import sys
import os
import numpy as np

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import PoseStamped, TwistStamped, Vector3
    from sensor_msgs.msg import Imu, NavSatFix
    from std_msgs.msg import Float32, String
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    # Fallback dummy class for non-ROS2 environments
    class Node:
        def __init__(self, name): pass

from uav_fault_tolerance.fault_injector import FaultInjector, FaultProfile, ScenarioType


class SensorBridgeNode(Node):
    """
    ROS 2 Node that receives physical/simulated Gazebo sensor feeds and produces
    the redundant Sensor Blocks:
    Branch 1: SB1 (IMU1), SB2 (GPS1, Lidar1, Mag1)
    Branch 2: SB3 (IMU2), SB4 (GPS2, Lidar2, Mag2)
    """
    def __init__(self):
        super().__init__("sensor_bridge_node")
        if not ROS2_AVAILABLE:
            print("[SensorBridgeNode] rclpy not installed. Node defined for ROS 2 deployment.")
            return

        # Parameters
        self.declare_parameter("scenario", "SCENARIO_B_GPS_BIAS")
        self.declare_parameter("fault_start_time", 7.0)
        self.declare_parameter("fault_end_time", 15.8)
        self.declare_parameter("fault_magnitude", 5.0)
        self.declare_parameter("target_branch", 1)

        scen_name = self.get_parameter("scenario").get_parameter_value().string_value
        t_start = self.get_parameter("fault_start_time").get_parameter_value().double_value
        t_end = self.get_parameter("fault_end_time").get_parameter_value().double_value
        mag = self.get_parameter("fault_magnitude").get_parameter_value().double_value
        branch = self.get_parameter("target_branch").get_parameter_value().integer_value

        self.profile = FaultProfile(
            scenario=ScenarioType(scen_name),
            t_start=t_start,
            t_end=t_end,
            magnitude=mag,
            target_branch=branch
        )
        self.injector = FaultInjector(self.profile)

        # Publishers for Sensor Blocks
        self.pub_sb1_imu = self.create_publisher(Imu, "/sensor_block_1/imu", 10)
        self.pub_sb2_gps = self.create_publisher(NavSatFix, "/sensor_block_2/gps", 10)
        self.pub_sb2_lidar = self.create_publisher(Float32, "/sensor_block_2/lidar", 10)
        self.pub_sb3_imu = self.create_publisher(Imu, "/sensor_block_3/imu", 10)
        self.pub_sb4_gps = self.create_publisher(NavSatFix, "/sensor_block_4/gps", 10)
        self.pub_sb4_lidar = self.create_publisher(Float32, "/sensor_block_4/lidar", 10)

        # Subscribers to simulated Gazebo / PX4 sensors
        self.sub_raw_imu1 = self.create_subscription(Imu, "/gazebo/imu1", self._cb_imu1, 10)
        self.sub_raw_gps1 = self.create_subscription(NavSatFix, "/gazebo/gps1", self._cb_gps1, 10)
        self.sub_raw_lidar1 = self.create_subscription(Float32, "/gazebo/lidar1", self._cb_lidar1, 10)

        self.get_logger().info("Sensor Bridge and Fault Injector Node started successfully.")

    def _cb_imu1(self, msg: Imu):
        self.pub_sb1_imu.publish(msg)

    def _cb_gps1(self, msg: NavSatFix):
        now_sec = self.get_clock().now().nanoseconds * 1e-9
        if self.profile.t_start <= now_sec <= self.profile.t_end:
            # Inject GPS bias
            msg.latitude += (self.profile.magnitude / 111319.5)
            msg.longitude += (self.profile.magnitude / (111319.5 * np.cos(np.radians(msg.latitude))))
        self.pub_sb2_gps.publish(msg)

    def _cb_lidar1(self, msg: Float32):
        now_sec = self.get_clock().now().nanoseconds * 1e-9
        if self.profile.t_start <= now_sec <= self.profile.t_end and self.profile.scenario == ScenarioType.SCENARIO_C_ALTITUDE_FAULT:
            msg.data -= self.profile.magnitude
        self.pub_sb2_lidar.publish(msg)


def main(args=None):
    if not ROS2_AVAILABLE:
        print("ROS 2 rclpy is not available in current environment.")
        return
    rclpy.init(args=args)
    node = SensorBridgeNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
