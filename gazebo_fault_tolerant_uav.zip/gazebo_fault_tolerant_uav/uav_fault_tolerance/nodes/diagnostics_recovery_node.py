"""
ROS 2 Node: Diagnostics and Recovery Manager Node.
Executes Algorithm 1 (Fault Detection & Identification) and commands recovery reconfigurations.
"""

import sys
import os
import numpy as np

try:
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import String, Float32MultiArray
    from sensor_msgs.msg import NavSatFix, Float32
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    class Node:
        def __init__(self, name): pass

from uav_fault_tolerance.fault_detector_identifier import FaultDetectorIdentifier, DiagnosticResult
from uav_fault_tolerance.recovery_manager import RecoveryManager


class DiagnosticsRecoveryNode(Node):
    """
    ROS 2 Node performing real-time fault detection, isolation, and recovery.
    """
    def __init__(self):
        super().__init__("diagnostics_recovery_node")
        if not ROS2_AVAILABLE:
            return

        self.fdi = FaultDetectorIdentifier()
        self.recovery = RecoveryManager(preferred_solution=3)

        # Publishers
        self.pub_status = self.create_publisher(String, "/diagnostics/fault_status", 10)
        self.pub_recovery = self.create_publisher(String, "/diagnostics/recovery_mode", 10)

        # Subscriptions
        self.sub_agreements = self.create_subscription(Float32MultiArray, "/diagnostics/agreement_indicators", self._cb_agreements, 10)

        self.get_logger().info("Diagnostics and Recovery Node running.")

    def _cb_agreements(self, msg: Float32MultiArray):
        if len(msg.data) >= 3:
            s12, s13, s23 = msg.data[:3]
            if s12 < 0.05:
                status_msg = String()
                status_msg.data = f"FAULT_DETECTED: s12={s12:.3f}, s13={s13:.3f}, s23={s23:.3f}"
                self.pub_status.publish(status_msg)


def main(args=None):
    if not ROS2_AVAILABLE:
        return
    rclpy.init(args=args)
    node = DiagnosticsRecoveryNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
