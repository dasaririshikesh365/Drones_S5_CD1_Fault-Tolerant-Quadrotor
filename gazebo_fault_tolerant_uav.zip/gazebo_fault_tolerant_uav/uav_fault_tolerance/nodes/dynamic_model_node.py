"""
ROS 2 Node: Analytical Dynamic Model Estimator Node (Branch C).
Integrates quadrotor equations of motion driven by actuator PWM commands.
"""

import sys
import os
import numpy as np

try:
    import rclpy
    from rclpy.node import Node
    from geometry_msgs.msg import PoseStamped
    from std_msgs.msg import Float32MultiArray
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False
    class Node:
        def __init__(self, name): pass

from uav_fault_tolerance.dynamic_model_estimator import DynamicModelEstimator


class DynamicModelNode(Node):
    """
    ROS 2 Node running Branch C Analytical Dynamic Model.
    """
    def __init__(self):
        super().__init__("dynamic_model_node")
        if not ROS2_AVAILABLE:
            return

        self.dm = DynamicModelEstimator()
        self.pub_pose = self.create_publisher(PoseStamped, "/estimator/dynamic_model/pose", 10)
        self.sub_pwm = self.create_subscription(Float32MultiArray, "/flight_controller/pwm_commands", self._cb_pwm, 10)
        self.timer = self.create_timer(0.01, self._timer_cb)  # 100 Hz

        self.last_pwm = np.full(4, 1740.0)
        self.get_logger().info("Dynamic Model Node initialized.")

    def _cb_pwm(self, msg: Float32MultiArray):
        if len(msg.data) >= 4:
            self.last_pwm = np.array(msg.data[:4])

    def _timer_cb(self):
        self.dm.step(self.last_pwm, 0.01)
        st = self.dm.get_state()
        p_msg = PoseStamped()
        p_msg.header.stamp = self.get_clock().now().to_msg()
        p_msg.header.frame_id = "map"
        p_msg.pose.position.x = st["pos"][0]
        p_msg.pose.position.y = st["pos"][1]
        p_msg.pose.position.z = st["pos"][2]
        p_msg.pose.orientation.w = st["quaternion"][0]
        p_msg.pose.orientation.x = st["quaternion"][1]
        p_msg.pose.orientation.y = st["quaternion"][2]
        p_msg.pose.orientation.z = st["quaternion"][3]
        self.pub_pose.publish(p_msg)


def main(args=None):
    if not ROS2_AVAILABLE:
        return
    rclpy.init(args=args)
    node = DynamicModelNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
