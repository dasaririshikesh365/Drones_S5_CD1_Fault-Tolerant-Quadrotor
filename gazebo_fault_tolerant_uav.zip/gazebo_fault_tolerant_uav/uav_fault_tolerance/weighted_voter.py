"""
Weighted-Average Voter Module.
Implements the soft-threshold weighted-average voter from Hamadi et al. (2022), Section 5.1,
Equations (22), (23), and (24), with Table 2 thresholds and quaternion safety.
"""

from dataclasses import dataclass
import numpy as np
from .quaternion_math import (
    quaternion_normalize,
    quaternion_angular_distance,
    quaternion_to_euler,
    euler_to_quaternion
)


@dataclass
class VoterThresholds:
    """Tunable voter thresholds from Table 2 of the paper."""
    a_x: float = 0.5
    n_x: float = 6.0    # na = 3.0 m

    a_y: float = 0.5
    n_y: float = 6.0    # na = 3.0 m

    a_z: float = 0.5
    n_z: float = 2.0    # na = 1.0 m

    # Angles in degrees in paper, converted to radians for internal math
    a_phi: float = np.radians(1.0)
    n_phi: float = 3.0  # na = 3.0 deg

    a_theta: float = np.radians(1.0)
    n_theta: float = 3.0  # na = 3.0 deg

    a_psi: float = np.radians(2.0)
    n_psi: float = 3.0    # na = 6.0 deg


def compute_soft_agreement(d_ij: float, a: float, n: float) -> float:
    """
    Compute soft agreement indicator s_ij between two outputs.
    Paper Equation (22):
        s_ij = 1.0                                      if d_ij <= a
        s_ij = (n / (n - 1)) * (1.0 - d_ij / (n * a))   if a < d_ij <= n * a
        s_ij = 0.0                                      if d_ij > n * a
    """
    if n <= 1.0:
        return 1.0 if d_ij <= a else 0.0

    na = n * a
    if d_ij <= a:
        return 1.0
    elif d_ij < na:
        val = (n / (n - 1.0)) * (1.0 - (d_ij / na))
        return float(np.clip(val, 0.0, 1.0))
    else:
        return 0.0


class WeightedAverageVoter:
    """
    Redundant Multi-Branch Voter with soft agreement weighting and safe fallback.
    Supports k >= 2 diversified modules (e.g. Branch 1: EKF1, Branch 2: EKF2, Branch 3: DM).
    """
    def __init__(self, thresholds: VoterThresholds | None = None):
        self.th = thresholds if thresholds is not None else VoterThresholds()

    def vote_scalar(self, values: list[float], a: float, n: float) -> tuple[float, list[float], np.ndarray]:
        """
        Vote on a single scalar state dimension among k branches.
        Returns: (fused_value, weights, agreement_matrix S)
        """
        k = len(values)
        if k == 1:
            return values[0], [1.0], np.array([[1.0]])

        # 1. Compute pairwise distances and agreement indicators S_ij (Eq. 22)
        S = np.zeros((k, k), dtype=float)
        for i in range(k):
            S[i, i] = 1.0
            for j in range(i + 1, k):
                d_ij = abs(values[i] - values[j])
                s_ij = compute_soft_agreement(d_ij, a, n)
                S[i, j] = s_ij
                S[j, i] = s_ij

        # 2. Compute branch weights (Eq. 23)
        weights = []
        for i in range(k):
            s_sum = sum(S[i, j] for j in range(k) if j != i)
            w_i = s_sum / (k - 1)
            weights.append(w_i)

        total_weight = sum(weights)
        # 3. Voter output (Eq. 24) with zero-division safety check
        if total_weight > 1e-6:
            y_v = sum(v * w for v, w in zip(values, weights)) / total_weight
        else:
            # Safe fallback: simple mean or middle value when all disagreement is extreme
            y_v = float(np.median(values))
            weights = [1.0 / k] * k

        return float(y_v), weights, S

    def vote_states(self, branch_states: list[dict[str, np.ndarray]]) -> dict[str, any]:
        """
        Perform complete 6-DOF voting across all branches.
        Each branch_state dict contains: 'pos', 'vel', 'quaternion', 'euler'
        Returns:
            fused_state: dict with 'pos', 'vel', 'quaternion', 'euler'
            voter_info: agreement matrices, weights, and pairwise distances
        """
        k = len(branch_states)
        positions = [s["pos"] for s in branch_states]
        velocities = [s["vel"] for s in branch_states]
        quaternions = [s["quaternion"] for s in branch_states]

        # 1. Vote on positions (x, y, z)
        fused_x, w_x, S_x = self.vote_scalar([p[0] for p in positions], self.th.a_x, self.th.n_x)
        fused_y, w_y, S_y = self.vote_scalar([p[1] for p in positions], self.th.a_y, self.th.n_y)
        fused_z, w_z, S_z = self.vote_scalar([p[2] for p in positions], self.th.a_z, self.th.n_z)
        fused_pos = np.array([fused_x, fused_y, fused_z], dtype=float)

        # 2. Horizontal Euclidean distance agreement (as in paper Section 6.2, Eq. 22 for d_xy)
        S_xy = np.zeros((k, k), dtype=float)
        for i in range(k):
            S_xy[i, i] = 1.0
            for j in range(i + 1, k):
                d_ij = float(np.linalg.norm(positions[i][:2] - positions[j][:2]))
                # Using x thresholds for 2D horizontal plane
                s_ij = compute_soft_agreement(d_ij, self.th.a_x, self.th.n_x)
                S_xy[i, j] = s_ij
                S_xy[j, i] = s_ij

        # 3. Vote on velocities (vx, vy, vz)
        fused_vx, _, _ = self.vote_scalar([v[0] for v in velocities], self.th.a_x, self.th.n_x)
        fused_vy, _, _ = self.vote_scalar([v[1] for v in velocities], self.th.a_y, self.th.n_y)
        fused_vz, _, _ = self.vote_scalar([v[2] for v in velocities], self.th.a_z, self.th.n_z)
        fused_vel = np.array([fused_vx, fused_vy, fused_vz], dtype=float)

        # 4. Vote on orientation (quaternions)
        # Compute pairwise geodesic angular distances
        S_q = np.zeros((k, k), dtype=float)
        # Mean threshold for attitude
        a_att = (self.th.a_phi + self.th.a_theta) * 0.5
        n_att = 3.0
        for i in range(k):
            S_q[i, i] = 1.0
            for j in range(i + 1, k):
                dist_q = quaternion_angular_distance(quaternions[i], quaternions[j])
                s_ij = compute_soft_agreement(dist_q, a_att, n_att)
                S_q[i, j] = s_ij
                S_q[j, i] = s_ij

        weights_q = []
        for i in range(k):
            s_sum = sum(S_q[i, j] for j in range(k) if j != i)
            weights_q.append(s_sum / (k - 1))

        # Align quaternion signs to branch 0 to prevent cancelation due to antipodal symmetry
        q_aligned = [quaternions[0].copy()]
        for i in range(1, k):
            q_i = quaternions[i].copy()
            if np.dot(q_aligned[0], q_i) < 0.0:
                q_i = -q_i
            q_aligned.append(q_i)

        total_wq = sum(weights_q)
        if total_wq > 1e-6:
            blended_q = np.zeros(4, dtype=float)
            for q_i, w_i in zip(q_aligned, weights_q):
                blended_q += (w_i / total_wq) * q_i
            fused_quat = quaternion_normalize(blended_q)
        else:
            fused_quat = quaternions[0].copy()

        roll, pitch, yaw = quaternion_to_euler(fused_quat)
        fused_euler = np.array([roll, pitch, yaw], dtype=float)

        # Summary branch weights for position
        mean_weights = [(w_x[i] + w_y[i] + w_z[i]) / 3.0 for i in range(k)]

        return {
            "state": {
                "pos": fused_pos,
                "vel": fused_vel,
                "quaternion": fused_quat,
                "euler": fused_euler
            },
            "info": {
                "weights_pos": mean_weights,
                "weights_x": w_x,
                "weights_y": w_y,
                "weights_z": w_z,
                "weights_q": weights_q,
                "S_xy": S_xy,
                "S_z": S_z,
                "S_q": S_q
            }
        }
