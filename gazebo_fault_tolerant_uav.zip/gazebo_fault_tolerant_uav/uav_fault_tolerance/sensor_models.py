"""
Sensor Models and Virtual Redundant Streams Module.
Implements redundant Sensor Blocks (SB1, SB2, SB3, SB4) with independent noise processes
as described in Hamadi et al. (2022), Section 5 and Section 6.1.
"""

from dataclasses import dataclass
import numpy as np
from .quaternion_math import quaternion_to_euler
from .quadrotor_dynamics import QuadrotorDynamics


@dataclass
class SensorNoiseParameters:
    """Noise and rate specifications matching paper parameters."""
    acc_noise_std: float = 0.05       # Accelerometer noise std (m/s^2)
    gyro_noise_std: float = 0.005     # Gyroscope noise std (rad/s)
    gps_pos_noise_std: float = 0.5    # GPS horizontal position noise std (m)
    gps_vel_noise_std: float = 0.1    # GPS velocity noise std (m/s)
    lidar_noise_std: float = 0.025    # Lidar Lite v3 range noise std (m)
    mag_noise_std: float = 0.015      # Magnetometer heading noise std (rad) ~ 0.8 deg


class SensorBlockGroup:
    """
    Simulates physical/software redundant sensor blocks:
    Branch 1: SB1 (IMU1) + SB2 (GPS1, Mag1, Lidar1)
    Branch 2: SB3 (IMU2) + SB4 (GPS2, Mag2, Lidar2)
    """
    def __init__(self, noise_params: SensorNoiseParameters | None = None, seed: int = 42):
        self.noise = noise_params if noise_params is not None else SensorNoiseParameters()
        self.rng1 = np.random.RandomState(seed)
        self.rng2 = np.random.RandomState(seed + 100)

        # Internal state for freeze faults
        self.frozen_imu1: np.ndarray | None = None
        self.frozen_imu2: np.ndarray | None = None

    def sample_sensors(self, uav: QuadrotorDynamics) -> dict[str, dict[str, np.ndarray | float]]:
        """
        Sample both redundant sensor branches from UAV ground truth state.
        Returns independent readings for SB1/SB2 and SB3/SB4.
        """
        true_acc_body = uav.get_specific_force_body()
        true_gyro_body = uav.angular_velocity.copy()
        roll, pitch, yaw = uav.get_euler_angles()
        true_pos = uav.position.copy()
        true_vel = uav.velocity.copy()

        # Branch 1 (SB1: IMU1, SB2: GPS1, Lidar1, Mag1)
        acc1 = true_acc_body + self.rng1.normal(0.0, self.noise.acc_noise_std, 3)
        gyro1 = true_gyro_body + self.rng1.normal(0.0, self.noise.gyro_noise_std, 3)
        gps1_pos = true_pos[:2] + self.rng1.normal(0.0, self.noise.gps_pos_noise_std, 2)
        gps1_vel = true_vel[:2] + self.rng1.normal(0.0, self.noise.gps_vel_noise_std, 2)
        lidar1 = float(true_pos[2] + self.rng1.normal(0.0, self.noise.lidar_noise_std))
        mag1 = float(yaw + self.rng1.normal(0.0, self.noise.mag_noise_std))

        # Branch 2 (SB3: IMU2, SB4: GPS2, Lidar2, Mag2)
        acc2 = true_acc_body + self.rng2.normal(0.0, self.noise.acc_noise_std, 3)
        gyro2 = true_gyro_body + self.rng2.normal(0.0, self.noise.gyro_noise_std, 3)
        gps2_pos = true_pos[:2] + self.rng2.normal(0.0, self.noise.gps_pos_noise_std, 2)
        gps2_vel = true_vel[:2] + self.rng2.normal(0.0, self.noise.gps_vel_noise_std, 2)
        lidar2 = float(true_pos[2] + self.rng2.normal(0.0, self.noise.lidar_noise_std))
        mag2 = float(yaw + self.rng2.normal(0.0, self.noise.mag_noise_std))

        return {
            "branch1": {
                "acc": acc1,
                "gyro": gyro1,
                "gps_pos": gps1_pos,
                "gps_vel": gps1_vel,
                "lidar": lidar1,
                "mag": mag1
            },
            "branch2": {
                "acc": acc2,
                "gyro": gyro2,
                "gps_pos": gps2_pos,
                "gps_vel": gps2_vel,
                "lidar": lidar2,
                "mag": mag2
            },
            "ground_truth": {
                "pos": true_pos,
                "vel": true_vel,
                "quaternion": uav.quaternion.copy(),
                "euler": np.array([roll, pitch, yaw]),
                "omega": true_gyro_body,
                "acc": true_acc_body
            }
        }
