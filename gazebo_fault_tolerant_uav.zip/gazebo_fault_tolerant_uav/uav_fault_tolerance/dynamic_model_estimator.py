"""
Branch C — Analytical Dynamic Model (DM) Estimator Module.
Implements the quadrotor dynamic model prediction branch using control inputs (PWM)
and Newton-Euler equations of motion from Hamadi et al. (2022), Section 3 & 6.1.
"""

from dataclasses import dataclass
import numpy as np
from .quaternion_math import (
    quaternion_normalize,
    quaternion_to_rotation_matrix,
    quaternion_to_euler,
    quaternion_propagate
)
from .quadrotor_dynamics import (
    QuadrotorParameters,
    pwm_to_motor_thrust,
    pwm_to_motor_torque,
    compute_virtual_inputs
)


class DynamicModelEstimator:
    """
    Branch C: Analytical Redundant Predictor.
    Integrates quadrotor equations of motion from applied motor commands (PWM).
    Does NOT depend on IMU or GPS readings directly, providing mathematical diversification.
    """
    def __init__(self, params: QuadrotorParameters | None = None, initial_pos: np.ndarray | None = None):
        self.params = params if params is not None else QuadrotorParameters()
        self.p = np.array(initial_pos if initial_pos is not None else [0.0, 0.0, 0.0], dtype=float)
        self.v = np.zeros(3, dtype=float)
        self.q = np.array([1.0, 0.0, 0.0, 0.0], dtype=float)
        self.omega = np.zeros(3, dtype=float)

        self.inertia_diag = np.array([self.params.Ixx, self.params.Iyy, self.params.Izz], dtype=float)
        self.inv_inertia_diag = 1.0 / self.inertia_diag

    def step(self, pwm_inputs: np.ndarray, dt: float) -> None:
        """
        Advance analytical prediction state using PWM commands and equations of motion.
        """
        # 1. Compute forces and moments from paper's motor polynomials
        f_motors = pwm_to_motor_thrust(pwm_inputs)
        tau_motors = pwm_to_motor_torque(pwm_inputs)
        uf, moments = compute_virtual_inputs(f_motors, tau_motors, self.params.arm_length)

        # 2. Translational dynamics in Earth frame (Paper Eq. 3, 6)
        R_B_to_E = quaternion_to_rotation_matrix(self.q)
        thrust_body = np.array([0.0, 0.0, uf], dtype=float)
        thrust_earth = R_B_to_E @ thrust_body

        drag_force = -self.params.drag_linear * self.v
        gravity_force = np.array([0.0, 0.0, -self.params.mass * self.params.gravity], dtype=float)

        total_force = thrust_earth + gravity_force + drag_force
        acceleration = total_force / self.params.mass

        # Ground plane constraint
        if self.p[2] <= 0.0 and acceleration[2] < 0.0:
            acceleration[2] = 0.0
            self.v[2] = max(0.0, self.v[2])
            self.p[2] = 0.0

        # Numerical integration
        self.v += acceleration * dt
        self.p += self.v * dt
        if self.p[2] < 0.0:
            self.p[2] = 0.0
            self.v[2] = 0.0

        # 3. Rotational dynamics (Paper Eq. 4, 5, 6)
        Iw = self.inertia_diag * self.omega
        gyroscopic = -np.cross(self.omega, Iw)
        rot_drag = -self.params.drag_angular * self.omega
        total_moment = moments + gyroscopic + rot_drag
        w_dot = self.inv_inertia_diag * total_moment

        self.omega += w_dot * dt
        self.q = quaternion_propagate(self.q, self.omega, dt)

    def soft_reset_from_consensus(self, consensus_pos: np.ndarray, consensus_vel: np.ndarray,
                                  consensus_quat: np.ndarray, consensus_omega: np.ndarray | None = None,
                                  alpha: float = 0.05) -> None:
        """
        Soft reinitialization / nudge towards healthy consensus as proposed in Section 7 of the paper,
        preventing open-loop numerical drift during long normal flights without suppressing fault detection.
        """
        self.p = (1.0 - alpha) * self.p + alpha * consensus_pos
        self.v = (1.0 - alpha) * self.v + alpha * consensus_vel
        if consensus_omega is not None:
            self.omega = (1.0 - alpha) * self.omega + alpha * consensus_omega
        # Check antipodal sign for quaternion blending
        q_target = consensus_quat.copy()
        if np.dot(self.q, q_target) < 0.0:
            q_target = -q_target
        blended_q = (1.0 - alpha) * self.q + alpha * q_target
        self.q = quaternion_normalize(blended_q)

    def reset_to_state(self, pos: np.ndarray, vel: np.ndarray, quat: np.ndarray) -> None:
        """Hard reset used in recovery when re-synchronizing after fault isolation."""
        self.p = pos.copy()
        self.v = vel.copy()
        self.q = quaternion_normalize(quat.copy())
        self.omega = np.zeros(3, dtype=float)

    def get_state(self) -> dict[str, np.ndarray]:
        """Return state dictionary."""
        roll, pitch, yaw = quaternion_to_euler(self.q)
        return {
            "pos": self.p.copy(),
            "vel": self.v.copy(),
            "quaternion": self.q.copy(),
            "euler": np.array([roll, pitch, yaw], dtype=float),
            "omega": self.omega.copy()
        }

    def get_euler_angles(self) -> tuple[float, float, float]:
        return quaternion_to_euler(self.q)
