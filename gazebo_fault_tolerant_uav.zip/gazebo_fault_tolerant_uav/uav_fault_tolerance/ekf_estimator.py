"""
Extended Kalman Filter (EKF) Estimator Module.
Implements nonlinear 6-DOF UAV state estimation with quaternion attitude representation
and innovation/covariance monitoring according to Hamadi et al. (2022), Section 4.
"""

from dataclasses import dataclass
import numpy as np
from .quaternion_math import (
    quaternion_normalize,
    quaternion_to_rotation_matrix,
    quaternion_to_euler,
    quaternion_propagate,
    euler_to_quaternion
)


@dataclass
class EKFConfig:
    """EKF process and measurement noise covariance configuration."""
    q_pos: float = 0.01        # Process noise position variance
    q_vel: float = 0.05        # Process noise velocity variance
    q_att: float = 0.001       # Process noise attitude variance
    q_bias: float = 0.0001     # Process noise gyro bias variance

    r_gps_pos: float = 0.25    # GPS position measurement variance (0.5m std)
    r_gps_vel: float = 0.04    # GPS velocity measurement variance (0.2m/s std)
    r_lidar: float = 0.000625  # Lidar range measurement variance (0.025m std)
    r_mag: float = 0.0004      # Magnetometer heading variance (0.02 rad std)

    gravity: float = 9.81


class UAVExtendedKalmanFilter:
    """
    13-state Extended Kalman Filter for UAV pose and velocity estimation:
    State: x = [px, py, pz, vx, vy, vz, qw, qx, qy, qz, bgx, bgy, bgz]^T
    """
    def __init__(self, name: str = "EKF1", config: EKFConfig | None = None, initial_pos: np.ndarray | None = None):
        self.name = name
        self.config = config if config is not None else EKFConfig()

        # State initialization
        self.p = np.array(initial_pos if initial_pos is not None else [0.0, 0.0, 0.0], dtype=float)
        self.v = np.zeros(3, dtype=float)
        self.q = np.array([1.0, 0.0, 0.0, 0.0], dtype=float)
        self.bg = np.zeros(3, dtype=float)

        # 13x13 Error Covariance Matrix P
        self.P = np.diag([
            0.1, 0.1, 0.1,           # pos
            0.1, 0.1, 0.1,           # vel
            0.01, 0.01, 0.01, 0.01,  # quat
            0.001, 0.001, 0.001      # bias
        ])

        # Diagonal Process Noise Matrix Q
        self.Q = np.diag([
            self.config.q_pos, self.config.q_pos, self.config.q_pos,
            self.config.q_vel, self.config.q_vel, self.config.q_vel,
            self.config.q_att, self.config.q_att, self.config.q_att, self.config.q_att,
            self.config.q_bias, self.config.q_bias, self.config.q_bias
        ])

        # Diagnostics and innovation tracking
        self.last_innovation = np.zeros(6, dtype=float)  # [dx_gps, dy_gps, dz_lidar, dvx, dvy, dyaw]
        self.last_S_diag = np.ones(6, dtype=float)
        self.is_healthy = True
        self.software_fault_active = False

    def predict(self, acc_meas: np.ndarray, gyro_meas: np.ndarray, dt: float) -> None:
        """
        EKF Prediction step using IMU specific force and angular velocity.
        """
        # 1. Correct gyro measurement with estimated bias
        omega_corr = gyro_meas - self.bg

        # 2. Transform specific force to Earth frame and subtract gravity
        R_B_to_E = quaternion_to_rotation_matrix(self.q)
        acc_earth = (R_B_to_E @ acc_meas) - np.array([0.0, 0.0, self.config.gravity])

        # 3. Propagate kinematic states
        self.p += self.v * dt + 0.5 * acc_earth * (dt**2)
        self.v += acc_earth * dt
        self.q = quaternion_propagate(self.q, omega_corr, dt)

        # Ensure height does not go below ground plane in simulation
        if self.p[2] < 0.0:
            self.p[2] = 0.0
            self.v[2] = max(0.0, self.v[2])

        # 4. State transition Jacobian F
        F = np.eye(13, dtype=float)
        F[0:3, 3:6] = np.eye(3) * dt
        # Simplified linearized coupling between attitude error and acceleration
        # In full EKF, small-angle approximation: delta_a = - [acc_earth x] delta_theta
        # Here we approximate with kinematic transition:
        self.P = F @ self.P @ F.T + self.Q * dt

        # Enforce symmetry
        self.P = 0.5 * (self.P + self.P.T)

    def update(self, gps_pos: np.ndarray | None, gps_vel: np.ndarray | None,
               lidar_z: float | None, mag_yaw: float | None) -> dict[str, float]:
        """
        EKF Correction step using GPS, Lidar, and Magnetometer observations.
        """
        innovations = {}

        # 1. GPS Position Update [px, py]
        if gps_pos is not None:
            z_gps = gps_pos[:2]
            h_gps = self.p[:2]
            innov_gps = z_gps - h_gps
            H_gps = np.zeros((2, 13), dtype=float)
            H_gps[0, 0] = 1.0
            H_gps[1, 1] = 1.0
            R_gps = np.eye(2) * self.config.r_gps_pos

            self._kalman_update(innov_gps, H_gps, R_gps)
            innovations["gps_x"] = float(innov_gps[0])
            innovations["gps_y"] = float(innov_gps[1])

        # 2. GPS Velocity Update [vx, vy]
        if gps_vel is not None:
            z_vel = gps_vel[:2]
            h_vel = self.v[:2]
            innov_vel = z_vel - h_vel
            H_vel = np.zeros((2, 13), dtype=float)
            H_vel[0, 3] = 1.0
            H_vel[1, 4] = 1.0
            R_vel = np.eye(2) * self.config.r_gps_vel

            self._kalman_update(innov_vel, H_vel, R_vel)
            innovations["vel_x"] = float(innov_vel[0])
            innovations["vel_y"] = float(innov_vel[1])

        # 3. Lidar Altitude Update [pz]
        if lidar_z is not None:
            innov_z = np.array([lidar_z - self.p[2]])
            H_z = np.zeros((1, 13), dtype=float)
            H_z[0, 2] = 1.0
            R_z = np.array([[self.config.r_lidar]])

            self._kalman_update(innov_z, H_z, R_z)
            innovations["lidar_z"] = float(innov_z[0])

        # 4. Magnetometer Heading Update [yaw]
        if mag_yaw is not None:
            _, _, est_yaw = self.get_euler_angles()
            diff_yaw = mag_yaw - est_yaw
            # Wrap to [-pi, pi]
            diff_yaw = (diff_yaw + np.pi) % (2.0 * np.pi) - np.pi
            innov_yaw = np.array([diff_yaw])

            # Linearized yaw sensitivity to quaternion:
            # yaw = atan2(2*(w*z + x*y), 1 - 2*(y^2 + z^2))
            w, x, y, z = self.q
            H_yaw = np.zeros((1, 13), dtype=float)
            H_yaw[0, 6] = 2.0 * z
            H_yaw[0, 7] = 2.0 * y
            H_yaw[0, 8] = 2.0 * x
            H_yaw[0, 9] = 2.0 * w
            R_mag = np.array([[self.config.r_mag]])

            self._kalman_update(innov_yaw, H_yaw, R_mag)
            innovations["mag_yaw"] = float(innov_yaw[0])

        # Re-normalize quaternion
        self.q = quaternion_normalize(self.q)

        return innovations

    def _kalman_update(self, y: np.ndarray, H: np.ndarray, R: np.ndarray) -> None:
        """Standard Joseph-form stable Kalman update step."""
        S = H @ self.P @ H.T + R
        try:
            K = self.P @ H.T @ np.linalg.inv(S)
        except np.linalg.LinAlgError:
            K = self.P @ H.T @ np.linalg.pinv(S)

        # State delta
        dx = K @ y

        # Apply state correction
        self.p += dx[0:3]
        self.v += dx[3:6]
        self.q += dx[6:10]
        self.bg += dx[10:13]

        # Joseph form covariance update for numerical stability: P = (I - KH)P(I - KH)^T + KRK^T
        I_KH = np.eye(13) - (K @ H)
        self.P = I_KH @ self.P @ I_KH.T + K @ R @ K.T
        self.P = 0.5 * (self.P + self.P.T)

    def inject_software_fault_covariance(self, axis: str = "z", value: float = -0.1) -> None:
        """
        Inject software fault into error covariance matrix P as studied in paper Section 6.4 / 6.5.
        For example: Pz = -0.1, or Px, Py = -0.01.
        """
        self.software_fault_active = True
        if axis == "z":
            self.P[2, 2] = value
        elif axis == "x":
            self.P[0, 0] = value
        elif axis == "y":
            self.P[1, 1] = value
        elif axis == "xy":
            self.P[0, 0] = value
            self.P[1, 1] = value

    def inject_software_bias(self, pos_bias: np.ndarray) -> None:
        """Inject direct state distortion simulating a bug in algorithmic computation."""
        self.software_fault_active = True
        self.p += pos_bias

    def get_state(self) -> dict[str, np.ndarray]:
        """Return estimated state dict."""
        roll, pitch, yaw = self.get_euler_angles()
        return {
            "pos": self.p.copy(),
            "vel": self.v.copy(),
            "quaternion": self.q.copy(),
            "euler": np.array([roll, pitch, yaw], dtype=float),
            "bias": self.bg.copy()
        }

    def get_euler_angles(self) -> tuple[float, float, float]:
        return quaternion_to_euler(self.q)
