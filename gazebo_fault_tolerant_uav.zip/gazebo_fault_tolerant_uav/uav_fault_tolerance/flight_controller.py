"""
Flight Controller Module.
Implements the robust trajectory tracking controller based on the sliding-mode / super-twisting
architecture described in Hamadi et al. (2022) Section 6 and Hamadi et al. (2019) [43].
Converts desired trajectory into thrust uf and moments tau, then maps to motor PWM inputs.
"""

from dataclasses import dataclass
import numpy as np
from .quaternion_math import (
    quaternion_to_euler,
    euler_to_quaternion,
    quaternion_to_rotation_matrix
)
from .quadrotor_dynamics import QuadrotorParameters, pwm_to_motor_thrust, pwm_to_motor_torque


@dataclass
class ControllerGains:
    """Position, altitude, and attitude controller gains."""
    # Horizontal position sliding mode gains
    kp_pos: float = 1.8
    kd_pos: float = 1.4
    ki_pos: float = 0.2

    # Altitude sliding mode gains
    kp_z: float = 3.5
    kd_z: float = 2.2
    ki_z: float = 0.5

    # Attitude sliding mode gains
    kp_att: float = 8.0
    kd_att: float = 1.2
    kp_yaw: float = 4.0
    kd_yaw: float = 0.8

    # Limits
    max_tilt_angle: float = np.radians(30.0)  # Max roll/pitch 30 deg
    max_vertical_vel: float = 2.0             # Max climb/descent rate (m/s)
    max_thrust: float = 35.0                  # Max total thrust (N)
    min_thrust: float = 2.0                   # Min thrust (N)


class FlightController:
    """
    Super-twisting / robust sliding mode position and attitude controller.
    """
    def __init__(self, params: QuadrotorParameters | None = None, gains: ControllerGains | None = None):
        self.params = params if params is not None else QuadrotorParameters()
        self.gains = gains if gains is not None else ControllerGains()

        # Integrator states
        self.int_ep = np.zeros(3, dtype=float)
        self.int_s_pos = np.zeros(2, dtype=float)
        self.int_s_z = 0.0

        # Hover equilibrium thrust
        self.hover_thrust = self.params.mass * self.params.gravity

    def compute_control(self, current_state: dict[str, np.ndarray],
                        pos_target: np.ndarray,
                        vel_target: np.ndarray,
                        yaw_target: float,
                        dt: float) -> tuple[np.ndarray, float, np.ndarray]:
        """
        Compute motor PWM commands from estimated current state and trajectory target.
        Returns:
            pwm_commands: 4-element array in [1000, 2000]
            uf: collective thrust in Newtons
            moments: [tau_phi, tau_theta, tau_psi] in N*m
        """
        p_est = current_state["pos"]
        v_est = current_state["vel"]
        roll, pitch, yaw = current_state["euler"]
        omega = current_state.get("omega", np.zeros(3))

        # 1. Position error and sliding surface
        ep = pos_target - p_est
        ev = vel_target - v_est
        self.int_ep += ep * dt
        # Anti-windup
        self.int_ep = np.clip(self.int_ep, -2.0, 2.0)

        # Horizontal acceleration command (Earth frame)
        ax_cmd = self.gains.kp_pos * ep[0] + self.gains.kd_pos * ev[0] + self.gains.ki_pos * self.int_ep[0]
        ay_cmd = self.gains.kp_pos * ep[1] + self.gains.kd_pos * ev[1] + self.gains.ki_pos * self.int_ep[1]

        # Vertical acceleration command (Earth frame)
        az_cmd = self.gains.kp_z * ep[2] + self.gains.kd_z * ev[2] + self.gains.ki_z * self.int_ep[2]

        # Total acceleration including gravity cancellation
        az_total = az_cmd + self.params.gravity
        az_total = max(az_total, 1.0)  # Avoid singularity

        # Total collective thrust uf
        uf = self.params.mass * np.sqrt(ax_cmd**2 + ay_cmd**2 + az_total**2)
        uf = np.clip(uf, self.gains.min_thrust, self.gains.max_thrust)

        # 2. Desired attitude angles from desired acceleration vector (Paper Section 3 / Eq. 3)
        # For small-to-moderate angles:
        # ax = (cos(phi)*sin(theta)*cos(psi) + sin(phi)*sin(psi)) * (uf / m)
        # ay = (cos(phi)*sin(theta)*sin(psi) - sin(phi)*cos(psi)) * (uf / m)
        # Heading reference rotation
        cy = np.cos(yaw)
        sy = np.sin(yaw)
        ax_body_approx = ax_cmd * cy + ay_cmd * sy
        ay_body_approx = -ax_cmd * sy + ay_cmd * cy

        theta_des = np.arctan2(ax_body_approx, az_total)
        phi_des = np.arctan2(-ay_body_approx, az_total)

        # Clamp tilt
        theta_des = np.clip(theta_des, -self.gains.max_tilt_angle, self.gains.max_tilt_angle)
        phi_des = np.clip(phi_des, -self.gains.max_tilt_angle, self.gains.max_tilt_angle)

        # 3. Attitude control: moments tau
        e_phi = phi_des - roll
        e_theta = theta_des - pitch
        e_psi = (yaw_target - yaw + np.pi) % (2.0 * np.pi) - np.pi

        # Moments (PD / Sliding Mode)
        tau_phi = self.gains.kp_att * e_phi - self.gains.kd_att * omega[0]
        tau_theta = self.gains.kp_att * e_theta - self.gains.kd_att * omega[1]
        tau_psi = self.gains.kp_yaw * e_psi - self.gains.kd_yaw * omega[2]

        moments = np.array([tau_phi, tau_theta, tau_psi], dtype=float)

        # 4. Motor mixer: solve for PWM commands
        pwm_commands = self._mix_actuators(uf, moments)

        return pwm_commands, float(uf), moments

    def _mix_actuators(self, uf: float, moments: np.ndarray) -> np.ndarray:
        """
        Mix collective thrust and moments to 4 motor PWM values in [1000, 2000].
        Solves:
            f1 + f2 + f3 + f4 = uf
            d*(f1 + f4 - f2 - f3)/sqrt(2) = tau_phi
            d*(f1 + f2 - f3 - f4)/sqrt(2) = tau_theta
            (t2 + t4) - (t1 + t3) = tau_psi
        """
        d = self.params.arm_length
        f_base = uf / 4.0
        delta_f_phi = (moments[0] * np.sqrt(2.0)) / (4.0 * d)
        delta_f_theta = (moments[1] * np.sqrt(2.0)) / (4.0 * d)
        delta_f_psi = moments[2] / (4.0 * 0.02)  # torque/thrust ratio approx

        f1 = f_base + delta_f_phi + delta_f_theta - delta_f_psi
        f2 = f_base - delta_f_phi + delta_f_theta + delta_f_psi
        f3 = f_base - delta_f_phi - delta_f_theta - delta_f_psi
        f4 = f_base + delta_f_phi - delta_f_theta + delta_f_psi

        f_des = np.array([f1, f2, f3, f4], dtype=float)
        f_des = np.clip(f_des, 0.1, 10.0)

        # Invert thrust polynomial (approximate via Newton-Raphson or quadratic fit)
        # In range [1.0, 2.0], thrust curve F(u) is monotonically increasing
        pwms = np.zeros(4, dtype=float)
        for i in range(4):
            pwms[i] = self._invert_thrust_to_pwm(f_des[i])

        return np.clip(pwms, 1000.0, 2000.0)

    def _invert_thrust_to_pwm(self, force_target: float) -> float:
        """Invert empirical motor thrust curve F(u) to find u_pwm."""
        # Initial guess near hover (PWM ~ 1740)
        u = 1.74
        for _ in range(8):
            f_val = (-1.4736*(u**3) + 11.0691*(u**2) - 16.7074*u + 7.3007)
            f_prime = (-4.4208*(u**2) + 22.1382*u - 16.7074)
            diff = f_val - force_target
            if abs(f_prime) < 1e-6:
                break
            u = u - diff / f_prime
            u = np.clip(u, 1.0, 2.0)
        return float(u * 1000.0)
