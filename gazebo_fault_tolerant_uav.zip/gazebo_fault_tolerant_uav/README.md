# 🛸 Fault-Tolerant Data Fusion Strategy for Quadrotor UAV in Gazebo Sim
### *Under Sensor Faults, Software Faults & Aerodynamic Wind Perturbations*

<div align="center">

[![Gazebo Sim Harmonic](https://img.shields.io/badge/Gazebo_Sim-Harmonic_8.15-orange.svg?logo=gazebo&logoColor=white)](https://gazebosim.org/)
[![ROS 2](https://img.shields.io/badge/ROS_2-Humble%20%7C%20Jazzy-22314E.svg?logo=ros&logoColor=white)](https://docs.ros.org/)
[![Paper Reference](https://img.shields.io/badge/ISA_Transactions-10.1016%2Fj.isatra.2022.01.007-brightgreen.svg)](https://doi.org/10.1016/j.isatra.2022.01.007)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg?logo=python&logoColor=white)](https://www.python.org/)
[![Status](https://img.shields.io/badge/Simulation-Validated-success.svg)]()
[![License](https://img.shields.io/badge/License-BSD--3--Clause-lightgrey.svg)]()

<p align="center">
  <b>A comprehensive 3D robotics simulation, real-time live telemetry dashboard, and fault-tolerant sensor fusion architecture reproducing and validating:</b><br>
  <i>"Data fusion fault tolerant strategy for a quadrotor UAV under sensors and software faults"</i><br>
  <b>ISA Transactions (Elsevier)</b>, Vol. 129, 2022, pp. 520–539.
</p>

[✨ Key Highlights](#-key-highlights) •
[🏛️ Architecture](#-system-architecture) •
[🌬️ 3D Wind Effects](#️-aerodynamic-wind-perturbations) •
[📊 Real-Time Graphs](#-live-real-time-oscilloscope-graphs) •
[🚀 Quick Start](#-quick-start--running-in-gazebo) •
[👥 Team](#-project-team)

</div>

---

## 📌 Slide 1: Executive Summary

Modern multirotor Unmanned Aerial Vehicles (UAVs) performing safety-critical missions (infrastructure inspection, search and rescue, hazardous terrain exploration) rely on multi-sensor data fusion to estimate position and attitude. However, multi-sensor systems are vulnerable to:
1. **Physical Sensor Failures**: GPS multipath jumps/jamming ($\Delta d > 2\text{ m}$), LiDAR dropouts/biases ($\Delta z = -1.0\text{ m}$), IMU drift/freezing, and magnetometer distortion.
2. **Software Estimator Divergence**: Numeric corruption of covariance matrices ($P_x, P_y < 0$ or $P_z < 0$), improper filter tuning, or rounding accumulation causing Kalman Filter crash.
3. **Severe Environmental Perturbations**: Dynamic outdoor wind turbulence and gusts challenging analytical dynamic predictors.

### The Solution:
This project delivers a **full-scale 3D Gazebo Harmonic & WebGL simulation** implementing an **extended duplication-comparison architecture with analytical redundancy and weighted soft-threshold voting**:
* **Triple Branch Redundancy**: Dual independent Extended Kalman Filters (EKF1, EKF2) paired with an analytical Newton-Euler Dynamic Model (DM) referee.
* **Weighted Average Soft-Threshold Voter**: Dynamically isolates faulty branches without sudden switching transients.
* **Algorithm 1 Fault Detection & Identification (FDI)**: Distinguishes between hardware sensor failure and software algorithm divergence.
* **Online Autonomous Recovery (Solution 3)**: Synthesizes a virtual healthy estimation branch ($KF_3 = 0.5 \cdot KF_2 + 0.5 \cdot DM$) to stabilize trajectory tracking without system shutdown.
* **Live 60 FPS Telemetry Dashboard**: Real-time oscilloscope curves depicting agreement indicators ($s_{ij}$), residuals, wind forces ($\mathbf{F}_w$), and branch weights.

---

## 🌟 Slide 2: Key Highlights

| Capability | Baseline UAV System | Our Fault-Tolerant Gazebo System |
| :--- | :--- | :--- |
| **3D Physics Platform** | Standard point-mass or kinematic sim | **Gazebo Sim Harmonic 8.15** + 3D WebGL Digital Twin |
| **Aerodynamic Wind Model** | Ignored or constant drag | **`gz-sim-wind-effects-system`** with spatial turbulence & gusts |
| **Sensor Redundancy** | Single IMU + Single GPS | **Dual Redundant Blocks**: SB1/SB2 (Branch 1) & SB3/SB4 (Branch 2) |
| **Analytical Redundancy** | None | **Branch 3 (DM)** with identified motor polynomial curves (Eq. 9, 10) |
| **Fault Coverage** | None (crashes on GPS jump or EKF bug) | **Hardware faults** (GPS, LiDAR, IMU) + **Software faults** (Covariance corruption) |
| **Voting Mechanism** | Hard threshold / Simple average | **Continuous Soft-Threshold Weighted Voter** ($a, n$ parameters) |
| **Live Telemetry** | Post-processed offline logs | **7-Channel Real-Time Oscilloscopes (60 FPS)** in interactive UI |

---

## 🏛️ Slide 3: System Architecture

The architecture builds upon the duplication-comparison principle, augmenting dual estimation branches with a physically diversified mathematical dynamic model:

```mermaid
flowchart TD
    subgraph SENSORS ["Hardware Sensor Layer"]
        SB1["Sensor Block 1 (IMU1: Acc1, Gyro1)"]
        SB2["Sensor Block 2 (GPS1, Mag1, Lidar1)"]
        SB3["Sensor Block 3 (IMU2: Acc2, Gyro2)"]
        SB4["Sensor Block 4 (GPS2, Mag2, Lidar2)"]
    end

    subgraph ACTUATORS ["Actuators & Commands"]
        PWM["Motor PWM Inputs u_pwm (1000 - 2000 µs)"]
    end

    subgraph ESTIMATORS ["Triple Redundant Estimation Branches"]
        B1["Branch 1: EKF 1\n(Prediction: SB1, Correction: SB2)"]
        B2["Branch 2: EKF 2\n(Prediction: SB3, Correction: SB4)"]
        B3["Branch 3: Dynamic Model (DM)\n6-DOF Newton-Euler + Motor Identification"]
    end

    subgraph VOTING_FDI ["Fault Tolerance Core (Hamadi et al. 2022)"]
        RES["Residual Generator\nΔSB1,SB3 & ΔSB2,SB4"]
        VOTER["Weighted Average Voter (Eq. 22-24)\nSoft Thresholds s12, s13, s23"]
        FDI["Algorithm 1: FDI Engine\nIsolate Branch & Discriminate HW vs SW"]
        REC["Recovery Manager (Sol. 1, 2, 3)\nVirtual Branch KF3 Synthesis"]
    end

    subgraph CONTROL ["Flight Control & Actuation"]
        SMC["Super-Twisting Sliding Mode Controller\nRobust to Wind Perturbations (Hamadi et al. 2019)"]
        UAV["Tarot 650 Quadrotor in Gazebo Sim"]
    end

    SB1 --> B1
    SB2 --> B1
    SB3 --> B2
    SB4 --> B2
    PWM --> B3

    SB1 & SB3 --> RES
    SB2 & SB4 --> RES

    B1 -->|State x1| VOTER
    B2 -->|State x2| VOTER
    B3 -->|State x3| VOTER

    VOTER -->|Agreement s_ij| FDI
    RES -->|Sensor Residuals| FDI
    FDI --> REC
    REC --> VOTER
    VOTER -->|Guaranteed Healthy State y_v| SMC
    SMC --> PWM
    PWM --> UAV
```

---

## 📐 Slide 4: Mathematical Modeling & Identification

### 1. 6-DOF Quadrotor Equations of Motion (Section 3.1)
The translational and rotational motions of the quadrotor in the Earth frame $\{X_E, Y_E, Z_E\}$ and Body frame $\{X_B, Y_B, Z_B\}$ are governed by Newton-Euler formalism:

$$m \ddot{\mathbf{p}} = \mathbf{R}_{B \to E} \begin{bmatrix} 0 \\ 0 \\ u_f \end{bmatrix} + \mathbf{F}_w - \begin{bmatrix} 0 \\ 0 \\ mG \end{bmatrix}$$

$$\begin{cases}
m \ddot{x} = (\cos\phi \sin\theta \cos\psi + \sin\phi \sin\psi) u_f + F_{wx} \\
m \ddot{y} = (\cos\phi \sin\theta \sin\psi - \sin\phi \cos\psi) u_f + F_{wy} \\
m \ddot{z} = (\cos\phi \cos\theta) u_f - mG + F_{wz}
\end{cases}$$

$$\mathbf{I} \dot{\boldsymbol{\omega}} = -\boldsymbol{\omega} \times (\mathbf{I} \boldsymbol{\omega}) + \boldsymbol{\tau}$$

where $\phi, \theta, \psi$ denote roll, pitch, and yaw angles, $u_f$ is total collective thrust, and $\mathbf{F}_w = [F_{wx}, F_{wy}, F_{wz}]^T$ is the external aerodynamic wind disturbance.

### 2. Experimental Motor Polynomial Identification (Section 3.2)
Due to standard ESCs lacking direct RPM telemetry, the paper identifies high-accuracy 3rd-order polynomial relationships between PWM signals ($u_{pwm} \in [1000, 2000]\,\mu\text{s}$) and generated forces/moments:

$$F_i(u_{pwm}) = \frac{-1.4736 u^3 + 11.0691 u^2 - 16.7074 u + 7.3007}{100} \quad [\text{N}]$$

$$\tau_i(u_{pwm}) = \frac{-0.0905 u^3 + 0.4771 u^2 - 0.6790 u + 0.3045}{100} \quad [\text{N}\cdot\text{m}]$$

*(with $u = u_{pwm} / 1000 \in [1.0, 2.0]$)*

### 3. Tarot 650 Quadrotor Physical Parameters (Table 1)
| Parameter | Symbol | Value | Units |
| :--- | :---: | :---: | :---: |
| Mass of the Vehicle | $m$ | $1.7$ | $\text{kg}$ |
| Arm Length | $l$ | $0.23$ | $\text{m}$ |
| Roll/Pitch Moment of Inertia | $I_{xx}, I_{yy}$ | $3.38 \times 10^{-2}$ | $\text{kg}\cdot\text{m}^2$ |
| Yaw Moment of Inertia | $I_{zz}$ | $2.25 \times 10^{-2}$ | $\text{kg}\cdot\text{m}^2$ |
| Gravity Acceleration | $G$ | $9.81$ | $\text{m/s}^2$ |

---

## 🗳️ Slide 5: Soft-Threshold Weighted Voter (Section 5.1)

Unlike naive voting schemes that use hard binary thresholding (causing sudden switching chatter), the weighted-average voter calculates smooth pairwise agreement indicators $s_{ij}$:

$$s_{ij} = \begin{cases} 
1, & \text{if } d_{ij} \le a \\
\left(\frac{n}{n-1}\right) \left(1 - \frac{d_{ij}}{na}\right), & \text{if } a < d_{ij} \le na \\
0, & \text{if } d_{ij} > na
\end{cases}$$

where $d_{ij} = |x_{mi} - x_{mj}|$ is numerical distance between branches $i$ and $j$, $a$ is the fixed threshold, and $n$ is the tuning multiplier (Table 2):

| Estimated State | Threshold $a$ | Multiplier $n$ | Cutoff $n \cdot a$ |
| :---: | :---: | :---: | :---: |
| Horizontal Position $x, y$ | $0.5\text{ m}$ | $6$ | $3.0\text{ m}$ |
| Altitude $z$ | $0.5\text{ m}$ | $2$ | $1.0\text{ m}$ |
| Attitude Angles $\phi, \theta$ | $1.0^\circ$ | $3$ | $3.0^\circ$ |
| Heading Angle $\psi$ | $2.0^\circ$ | $3$ | $6.0^\circ$ |

Individual branch weights $w_{mi}$ and final fused state $y_v$ are calculated dynamically:

$$w_{mi} = \frac{\sum_{j=1, j \ne i}^{k} s_{ij}}{k - 1}, \qquad y_v = \frac{\sum_{i=1}^{k} x_{mi} \cdot w_{mi}}{\sum_{i=1}^{k} w_{mi}}$$

When a branch diverges, its agreement indicators drop to $0$, causing its weight to gracefully collapse to zero without disturbing the flight trajectory!

---

## 🔍 Slide 6: Fault Detection, Identification & Recovery

### Algorithm 1: FDI Decision Logic (Section 5.3)
1. **Error Detection**: Triggered immediately when $s_{12} = 0$ (the two Kalman Filters disagree).
2. **Branch Isolation**: The Dynamic Model (DM, Branch 3) acts as an analytical referee:
   * If $|s_{13} - s_{23}| > \epsilon$ and $s_{13} = \min(s_{13}, s_{23})$ $\longrightarrow$ **Branch 1 is Faulty**.
   * If $|s_{13} - s_{23}| > \epsilon$ and $s_{23} = \min(s_{13}, s_{23})$ $\longrightarrow$ **Branch 2 is Faulty**.
3. **Hardware vs Software Discrimination**: Sensor residuals are evaluated against Table 3 limits:
   * $\Delta_{\text{GPS1, GPS2}} > 2.0\text{ m}$ $\longrightarrow$ **Hardware GPS Fault**.
   * $\Delta_{\text{Lidar1, Lidar2}} > 1.0\text{ m}$ $\longrightarrow$ **Hardware LiDAR Fault**.
   * $\Delta_{\text{IMU1, IMU2}} > 0.01\text{ m/s}^2$ $\longrightarrow$ **Hardware Accelerometer Fault**.
   * If all sensor residuals $< \text{Threshold}$ $\longrightarrow$ **Software Estimator Bug (EKF Covariance Distortion)**.

### Autonomous Recovery — Solution 3 (Section 5.4)
Once the faulty branch is isolated, the Recovery Manager instantiates a **virtual estimation branch** $KF_3$:

$$\mathbf{p}_{KF3} = 0.5 \cdot \mathbf{p}_{KF,\text{healthy}} + 0.5 \cdot \mathbf{p}_{DM}$$

This eliminates error propagation, keeps the voting ensemble triplex, and allows the UAV to continue its mission uninterrupted.

---

## 🌬️ Slide 7: Aerodynamic Wind Perturbations

In real outdoor environments, UAVs encounter unsteady winds that can destabilize trajectory tracking and cause analytical models to drift:

```mermaid
flowchart LR
    A["Atmospheric Mean Wind\nv_wind = [3.5, 1.5, 0.2] m/s"] --> D["Gazebo Wind Effects Plugin\ngz-sim-wind-effects-system"]
    B["Harmonic Gust Spectrum\nv_gust = A * sin(omega * t)"] --> D
    C["Dryden Wind Turbulence\nGaussian Stochastics"] --> D
    D --> E["Aerodynamic Force F_w\non Tarot 650 Airframe"]
    E --> F["Second-Order Sliding Mode\nSuper-Twisting Controller"]
    F --> G["Robust Flight Stability\n& Precise Trajectory Tracking"]
```

* **Gazebo Plugin**: Configured with `libgz-sim-wind-effects-system.so` applied to the Tarot 650 `base_link` and spinning rotors.
* **Controller Resilience**: Governed by the super-twisting sliding mode algorithm (Hamadi et al., 2019 [43]), which guarantees finite-time convergence of position errors despite persistent wind forces up to $16\text{ m/s}$.
* **Analytical DM Discipline**: Uses soft consensus reinitialization ($\alpha = 0.05$) during confirmed healthy flight to bound open-loop wind drift.

---

## 📊 Slide 8: Live Real-Time Oscilloscope Graphs

The built-in telemetry cockpit runs at a steady **60 FPS** in WebGL, featuring 7 live updating oscilloscope displays:

```text
┌───────────────────────────────────────┬───────────────────────────────────────┐
│ GRAPH 1: Altitude Z Tracking (m)      │ GRAPH 2: Horizontal Position (X, Y)   │
│ ■ Ground Truth   ■ Voter   ■ Ref      │ ■ Position X   ■ Position Y   ■ Target│
│ 3.0m ───-~-~-~-~-~-~-~-~-~-~-~-~-~-~- │ [──────/‾‾‾\──────/‾‾‾\──────]       │
├───────────────────────────────────────┼───────────────────────────────────────┤
│ GRAPH 3: Position & Alt Error (m)     │ GRAPH 4: Triple-Branch Estimations    │
│ ■ Pos Error: 0.04m  ■ Alt Err: 0.02m  │ ■ EKF 1 (Faulty Spike +5m)            │
│ [~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_~_]│ ■ EKF 2 (Healthy)  ■ DM  ■ Voter     │
├───────────────────────────────────────┼───────────────────────────────────────┤
│ GRAPH 5: Agreement Indicators s_ij    │ GRAPH 6: Wind Perturbation Force F_w  │
│ ■ s12 (drops to 0 on fault)           │ ■ Total |Fw|: 1.45 N  (Wind: 8.0 m/s) │
│ ■ s13 (EKF1-DM)   ■ s23 (EKF2-DM)     │ ■ Fwx (East)   ■ Fwy (North)          │
├───────────────────────────────────────┴───────────────────────────────────────┤
│ GRAPH 7: Sensor Residuals vs Paper Table 3 Thresholds                         │
│ ■ GPS Residual (d_GPS1-GPS2) vs Red Threshold Line (Th_GPS = 2.0 m)           │
│ ■ LiDAR Residual (dz_L1-L2)  vs Pink Threshold Line (Th_z   = 1.0 m)          │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## 🧪 Slide 9: Experimental Validation & Case Studies

Four benchmark scenarios from the research paper were reproduced and quantitatively evaluated:

### 1. Hardware GPS Fault (Section 6.2)
* **Injection**: $+5.0\text{ m}$ step bias on $x, y$ of GPS1 during a U-path flight at $t = 7.0\text{ s}$.
* **Detection**: $s_{12}$ drops from $1.0$ to $0.0$ in $0.5\text{ s}$ ($t_{det} = 7.5\text{ s}$).
* **Diagnosis**: $\Delta_{\text{GPS}} = 7.07\text{ m} > Th_{GPS} (2.0\text{ m})$; Accelerometer residual $< 0.01\text{ m/s}^2$ $\to$ Hardware GPS1 failure.
* **Recovery**: Branch 1 isolated; $KF_3$ engaged. Tracking error preserved within $< 0.12\text{ m}$ (Baseline drifted $> 5.2\text{ m}$).

### 2. Hardware LiDAR Fault (Section 6.3)
* **Injection**: $-1.0\text{ m}$ bias on LiDAR 1 during hover at $3.0\text{ m}$ altitude.
* **Detection**: $s_{z,12}$ drops to $0.0$ at $t = 19.5\text{ s}$.
* **Diagnosis**: $\Delta_{\text{LiDAR}} = 1.0\text{ m} \ge Th_{rg} (1.0\text{ m})$ $\to$ Hardware LiDAR 1 failure.
* **Recovery**: System reconfigured without altitude loss.

### 3. Software Altitude Fault (Section 6.4)
* **Injection**: Negative covariance corruption ($P_z = -0.1$) in EKF 1 software code.
* **Detection**: Estimator diverges after $15\text{ s}$; $s_{12}$ drops to $0.0$.
* **Diagnosis**: All sensor residuals remain below thresholds $\to$ Software EKF defect isolated.

### 4. Software Position Fault (Section 6.5)
* **Injection**: $P_x, P_y = -0.01$ covariance perturbation in EKF 1.
* **Detection & Isolation**: Algorithm 1 successfully isolates EKF 1; Dynamic Model maintains flight reference.

---

## 🚀 Slide 10: Quick Start & Running in Gazebo

### Prerequisites
* **Windows**: Python 3.10+, WSL2 with Ubuntu (for Gazebo Sim) or modern browser for 3D digital twin.
* **Linux / Ubuntu**: Gazebo Sim Harmonic 8+, ROS 2 Humble/Jazzy, Python 3.10+.

### Option A: One-Click Launch (Windows)
Double-click `run_gazebo.bat` in the repository root or run:
```powershell
.\run_gazebo.bat
```

### Option B: Python Orchestrator (Automatic WSL / Linux Bridge)
```powershell
# Launches Gazebo simulation with wind and opens the 3D real-time dashboard
python scripts/run_gazebo_simulation.py

# Optional: Run in Gazebo GUI mode
python scripts/run_gazebo_simulation.py --gui

# Optional: Run Gazebo headless (server only)
python scripts/run_gazebo_simulation.py --headless
```

### Option C: Launch 3D Real-Time Cockpit Standalone
```powershell
python scripts/launch_flight_simulator.py
```
*Directly opens `visualization/interactive_flight_simulator.html` in your default browser with live piloting, wind intensity presets, on-demand fault injection, and oscilloscope graphs.*

---

## 📂 Repository File Structure

```text
gazebo_fault_tolerant_uav/
├── run_gazebo.bat                        # One-click Windows runner
├── package.xml                           # ROS 2 package manifest
├── setup.py                              # Python installation setup
├── config/
│   ├── simulation_params.yaml            # Vehicle parameters & Table 2 voter thresholds
│   └── fault_scenarios.yaml              # Definition for Scenarios A through I
├── gazebo/
│   ├── models/
│   │   └── tarot650_redundant/           # Dual-sensor quadrotor SDF model with motor plugins
│   │       ├── model.config
│   │       └── model.sdf
│   └── worlds/
│       └── uav_fault_tolerance_world.sdf # World with takeoff pad, arena & Wind Effects plugin
├── launch/
│   ├── simulation.launch.py              # Gazebo Harmonic + ROS-Gz bridge launcher
│   └── fault_tolerant_system.launch.py   # Full ROS 2 node stack (dual EKF, DM, voter, FDI)
├── scripts/
│   ├── run_gazebo_simulation.py          # Unified Gazebo + WebGL orchestration script
│   ├── run_gazebo.sh                     # Linux/WSL bash runner
│   ├── launch_flight_simulator.py        # Browser cockpit launcher
│   ├── run_all_experiments.py            # Systematic test harness for Scenarios A-I
│   └── generate_plots.py                 # Generates publication-grade figures
├── uav_fault_tolerance/                  # Core Python algorithms
│   ├── quadrotor_dynamics.py             # 6-DOF Newton-Euler dynamics & motor polynomials
│   ├── dynamic_model_estimator.py        # Branch 3 analytical dynamic referee
│   ├── ekf_estimator.py                  # 13-state Extended Kalman Filter
│   ├── weighted_voter.py                 # Eq. 22-24 soft-threshold voter
│   ├── fault_detector_identifier.py      # Algorithm 1 FDI decision tree
│   ├── recovery_manager.py               # Recovery Solution 3 manager
│   ├── flight_controller.py              # Super-twisting sliding mode controller
│   └── simulation_engine.py              # Full closed-loop physics & wind pipeline
└── visualization/
    ├── interactive_flight_simulator.html # 3D WebGL simulator with 7 real-time graphs & wind
    ├── drone_3d_simulation.html          # Historical trajectory replay viewer
    └── OrbitControls.js                  # Three.js 3D camera controls
```

---

## 👥 Project Team

This project was developed and evaluated by:

| Name | Registration Number | Role & Focus |
| :--- | :---: | :--- |
| **Palaparthi Sathvik** | `CB.SC.U4AIE24240` | Dynamic Modeling, Gazebo Sim Integration & Flight Control |
| **Rishi** | `CB.SC.U4AIE24365` | Dual EKF Sensor Fusion & Software Fault Injection |
| **Saradhi** | `CB.SC.U4AIE24265` | Weighted-Average Voter & Algorithm 1 FDI Engine |
| **Aryan** | `CB.SC.U4AIE24341` | Aerodynamic Wind Simulation & Real-Time Telemetry Dashboard |

---

## 📚 Reference Citation

If you use this simulation or codebase in your academic research or projects, please cite the underlying research:

```bibtex
@article{hamadi2022data,
  title={Data fusion fault tolerant strategy for a quadrotor UAV under sensors and software faults},
  author={Hamadi, Hussein and Lussier, Benjamin and Fantoni, Isabelle and Francis, Clovis},
  journal={ISA Transactions},
  volume={129},
  pages={520--539},
  year={2022},
  publisher={Elsevier},
  doi={10.1016/j.isatra.2022.01.007}
}

@inproceedings{hamadi2019observer,
  title={Observer-based super twisting controller robust to wind perturbation for multirotor UAV},
  author={Hamadi, Hussein and Lussier, Benjamin and Fantoni, Isabelle and Francis, Clovis and Shraim, Hassan},
  booktitle={2019 International Conference on Unmanned Aircraft Systems (ICUAS)},
  pages={397--405},
  year={2019},
  organization={IEEE}
}
```

---

<div align="center">
  <b>Developed for Advanced Robotics & Fault-Tolerant Autonomous Systems</b><br>
  <sub>Released under the BSD-3-Clause License.</sub>
</div>
