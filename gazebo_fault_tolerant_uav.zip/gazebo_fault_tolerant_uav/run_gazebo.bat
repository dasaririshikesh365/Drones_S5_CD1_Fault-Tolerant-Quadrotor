@echo off
setlocal
echo ========================================================================
echo   Launching Fault-Tolerant Tarot 650 UAV Simulation in Gazebo Sim
echo   Hamadi et al., ISA Transactions 129 (2022) 520-539
echo ========================================================================

cd /d "%~dp0"
python scripts\run_gazebo_simulation.py %*
pause
