"""
ROS 2 Launch file: Fault-Tolerant Estimation and Recovery Stack.
Launches the Dual EKF estimators, Dynamic Model predictor, Weighted Average Voter,
FDI / Recovery modules, and optional Manual Teleop node.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    scenario_arg = DeclareLaunchArgument(
        "scenario",
        default_value="SCENARIO_B_GPS_BIAS",
        description="Fault injection scenario to execute"
    )

    teleop_arg = DeclareLaunchArgument(
        "teleop",
        default_value="false",
        description="Launch interactive keyboard teleoperation terminal node"
    )

    sensor_bridge = Node(
        package="uav_fault_tolerance",
        executable="sensor_bridge_node",
        parameters=[{
            "scenario": LaunchConfiguration("scenario"),
            "fault_start_time": 7.0,
            "fault_end_time": 15.8,
            "fault_magnitude": 5.0,
            "target_branch": 1
        }],
        output="screen"
    )

    ekf1_node = Node(
        package="uav_fault_tolerance",
        executable="ekf_node",
        name="ekf_branch_1",
        parameters=[{"branch_id": 1}],
        output="screen"
    )

    ekf2_node = Node(
        package="uav_fault_tolerance",
        executable="ekf_node",
        name="ekf_branch_2",
        parameters=[{"branch_id": 2}],
        output="screen"
    )

    dynamic_model = Node(
        package="uav_fault_tolerance",
        executable="dynamic_model_node",
        name="quadrotor_dynamic_model",
        output="screen"
    )

    voter_node = Node(
        package="uav_fault_tolerance",
        executable="voter_node",
        name="weighted_voter",
        output="screen"
    )

    diagnostics_recovery = Node(
        package="uav_fault_tolerance",
        executable="diagnostics_recovery_node",
        name="fault_detector_recovery",
        output="screen"
    )

    flight_control = Node(
        package="uav_fault_tolerance",
        executable="flight_control_node",
        name="flight_controller_interface",
        output="screen"
    )

    logger_node = Node(
        package="uav_fault_tolerance",
        executable="logger_node",
        name="state_logger",
        output="screen"
    )

    teleop_node = Node(
        package="uav_fault_tolerance",
        executable="manual_teleop_node",
        name="manual_teleop_node",
        output="screen",
        condition=IfCondition(LaunchConfiguration("teleop"))
    )

    return LaunchDescription([
        scenario_arg,
        teleop_arg,
        sensor_bridge,
        ekf1_node,
        ekf2_node,
        dynamic_model,
        voter_node,
        diagnostics_recovery,
        flight_control,
        logger_node,
        teleop_node
    ])
