"""
ROS 2 Launch file: Simulation Bringup in Gazebo Harmonic with PX4 / Bridge Integration.
Supports world selection: open_arena, obstacle_course, narrow_corridor, fault_tolerance.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os


def launch_setup(context, *args, **kwargs):
    world_arg = LaunchConfiguration('world').perform(context)
    pkg_share = FindPackageShare(package="uav_fault_tolerance").find("uav_fault_tolerance")

    world_map = {
        'open_arena': 'uav_open_arena.sdf',
        'obstacle_course': 'uav_obstacle_course.sdf',
        'narrow_corridor': 'uav_narrow_corridor.sdf',
        'fault_tolerance': 'uav_fault_tolerance_world.sdf',
    }

    world_filename = world_map.get(world_arg, 'uav_obstacle_course.sdf')
    world_path = os.path.join(pkg_share, "gazebo", "worlds", world_filename)

    # Gazebo Harmonic process
    gz_sim = ExecuteProcess(
        cmd=["gz", "sim", "-r", world_path],
        output="screen"
    )

    # ROS 2 - Gazebo Harmonic Bridge for dual redundant sensors
    gz_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=[
            "/gazebo/imu1@sensor_msgs/msg/Imu[gz.msgs.IMU",
            "/gazebo/imu2@sensor_msgs/msg/Imu[gz.msgs.IMU",
            "/gazebo/gps1@sensor_msgs/msg/NavSatFix[gz.msgs.NavSat",
            "/gazebo/gps2@sensor_msgs/msg/NavSatFix[gz.msgs.NavSat",
            "/gazebo/lidar1@std_msgs/msg/Float32[gz.msgs.Float",
            "/gazebo/lidar2@std_msgs/msg/Float32[gz.msgs.Float",
            "/gazebo/ground_truth@geometry_msgs/msg/PoseStamped[gz.msgs.Pose",
        ],
        output="screen"
    )

    return [gz_sim, gz_bridge]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'world',
            default_value='obstacle_course',
            description='World configuration: open_arena, obstacle_course, narrow_corridor, fault_tolerance'
        ),
        OpaqueFunction(function=launch_setup)
    ])
