"""
ROS 2 Launch file: Evaluation Suite Bringup.
Runs the complete stack with automated CSV logging for benchmarking.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg_share = FindPackageShare(package="uav_fault_tolerance")

    ft_stack = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([pkg_share, "launch", "fault_tolerant_system.launch.py"])
        )
    )

    return LaunchDescription([
        ft_stack
    ])
